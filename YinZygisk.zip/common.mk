ROOT_DIR ?= .
BUILD_TYPE ?= release
API_LEVEL ?= 29
ARCHS ?= arm64-v8a
ARCH ?= arm64-v8a

VER_NAME ?= v1.0.0
VER_CODE ?= 1
COMMIT_HASH ?= release

MIN_KSU_VERSION ?= 10940
MIN_KSUD_VERSION ?= 11425

MODULE_ID ?= yinzygisk
MODULE_NAME ?= YinZygisk

NDK_VERSION ?= 29.0.13113456
ANDROID_HOME ?= $(HOME)/Android/Sdk
NDK_PATH ?= $(ANDROID_HOME)/ndk/$(NDK_VERSION)
TOOLCHAIN = $(NDK_PATH)/toolchains/llvm/prebuilt/linux-x86_64

ifeq ($(TERMUX_VERSION),)
	CC = $(TOOLCHAIN)/bin/clang
	AR = $(TOOLCHAIN)/bin/llvm-ar
	STRIP = $(TOOLCHAIN)/bin/llvm-strip --strip-all
	SYSROOT = $(TOOLCHAIN)/sysroot
else
	CC = clang
	AR = llvm-ar
	STRIP = llvm-strip --strip-all
	SYSROOT =
endif

BUILD_DIR ?= $(ROOT_DIR)/build

TARGET_arm64-v8a = aarch64-linux-android$(API_LEVEL)

ifneq ($(SYSROOT),)
	CC_ARCH = $(CC) --target=$(TARGET_$(ARCH)) --sysroot=$(SYSROOT)
else
	CC_ARCH = $(CC) --target=$(TARGET_$(ARCH))
endif

NDK_CFLAGS = -DANDROID -DNDEBUG -O3 -flto=thin -fvisibility=hidden \
	-fdata-sections -ffunction-sections -fno-unwind-tables -fno-asynchronous-unwind-tables \
	-fno-ident -fomit-frame-pointer -no-canonical-prefixes -D_FORTIFY_SOURCE=2 \
	-Wformat -Werror=format-security

NDK_LDFLAGS = -flto=thin -Wl,--gc-sections -Wl,--strip-all -Wl,--icf=all
#!/system/bin/sh

set -e

MODDIR=/data/adb/modules/yinzygisk

if [ ! -f "$MODDIR/disable" ]; then
  exit 0
fi

cp -f "$MODDIR/module.prop.bak" "$MODDIR/module.prop"

exit 0
#!/system/bin/sh

set -e

rm -rf /data/adb/yinzygisk
rm -f /data/adb/service.d/yinzygisk.sh
rmdir /data/adb/service.d 2>/dev/null || true

exit 0
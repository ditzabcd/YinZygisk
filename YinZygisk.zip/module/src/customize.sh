# shellcheck disable=SC2034
SKIPUNZIP=1

MIN_KSU_VERSION=@MIN_KSU_VERSION@
MIN_KSUD_VERSION=@MIN_KSUD_VERSION@

if [ -z "$BOOTMODE" ] || [ -z "$KSU" ]; then
  abort "! Only KernelSU / KernelSU Next in app mode is supported"
fi

if [ -z "$KSU_KERNEL_VER_CODE" ] || [ "$KSU_KERNEL_VER_CODE" -lt "$MIN_KSU_VERSION" ]; then
  abort "! KernelSU kernel version is too old (min: $MIN_KSU_VERSION)"
fi

if [ -z "$KSU_VER_CODE" ] || [ "$KSU_VER_CODE" -lt "$MIN_KSUD_VERSION" ]; then
  abort "! KernelSU Manager (ksud) is too old (min: $MIN_KSUD_VERSION)"
fi

if [ "$ARCH" != "arm64" ]; then
  abort "! Unsupported architecture: $ARCH (arm64-v8a only)"
fi

if [ "$API" -lt 25 ]; then
  abort "! Unsupported Android SDK: $API"
fi

unzip -p "$ZIPFILE" "module.prop" > "$MODPATH/module.prop"
VERSION=$(grep_prop version "$MODPATH/module.prop")
ui_print "- Installing YinZygisk $VERSION (arm64-v8a / KSUN)"

unzip -p "$ZIPFILE" "sepolicy.rule" > "$MODPATH/sepolicy.rule"
if ! check_sepolicy "$MODPATH/sepolicy.rule"; then
  abort "! Failed to verify SELinux policy rules"
fi

mkdir -p "$MODPATH/bin" "$MODPATH/lib64" /data/adb/service.d

unzip -p "$ZIPFILE" "post-fs-data.sh" > "$MODPATH/post-fs-data.sh"
unzip -p "$ZIPFILE" "uninstall.sh" > "$MODPATH/uninstall.sh"
unzip -p "$ZIPFILE" "yinzygisk.sh" > "/data/adb/service.d/yinzygisk.sh"

unzip -p "$ZIPFILE" "bin/arm64-v8a/zygiskd" > "$MODPATH/bin/zygiskd64"
unzip -p "$ZIPFILE" "lib/arm64-v8a/libzygisk.so" > "$MODPATH/lib64/libzygisk.so"
unzip -p "$ZIPFILE" "lib/arm64-v8a/libzygisk_ptrace.so" > "$MODPATH/bin/zygisk-ptrace64"
unzip -p "$ZIPFILE" "machikado.arm64" > "$MODPATH/machikado.arm64"

cp -f "$MODPATH/module.prop" "$MODPATH/module.prop.bak"

set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
set_perm_recursive "$MODPATH/lib64" 0 0 0755 0644 u:object_r:system_lib_file:s0
chmod 0755 "$MODPATH/post-fs-data.sh" "$MODPATH/uninstall.sh" "/data/adb/service.d/yinzygisk.sh"
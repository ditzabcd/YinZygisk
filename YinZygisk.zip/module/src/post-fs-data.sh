#!/system/bin/sh

set -e

MODDIR=${0%/*}
cd "$MODDIR"

TMP_PATH=/data/adb/yinzygisk
rm -rf "$TMP_PATH"
mkdir -p "$TMP_PATH"
chmod 555 "$TMP_PATH"
chcon u:object_r:system_file:s0 "$TMP_PATH"

cp -f "$MODDIR/module.prop.bak" "$MODDIR/module.prop"

./bin/zygisk-ptrace64 monitor &

exit 0
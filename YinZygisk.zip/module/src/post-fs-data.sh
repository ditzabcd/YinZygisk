#!/system/bin/sh

set -e

MODDIR=${0%/*}
cd "$MODDIR"

# Izinkan proses non-root melintasi /data/adb menuju cp64.sock tanpa bisa melihat isi folder /data/adb
chmod 0711 /data/adb

TMP_PATH=/data/adb/yinzygisk
rm -rf "$TMP_PATH"
mkdir -p "$TMP_PATH"
chmod 0555 "$TMP_PATH"
chcon u:object_r:system_file:s0 "$TMP_PATH"

cp -f "$MODDIR/module.prop.bak" "$MODDIR/module.prop"

chmod 0755 "$MODDIR/bin/"*
chcon -R u:object_r:system_file:s0 "$MODDIR/bin"

./bin/zygisk-ptrace64 monitor &

exit 0
#ifndef UTILS_H
#define UTILS_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

#include "constants.h"
#include "root_impl/common.h"

#define CONCAT_(x, y) x##y
#define CONCAT(x, y) CONCAT_(x, y)

#ifdef __LP64__
  #define LP_SELECT(a, b) b
#else
  #define LP_SELECT(a, b) a
#endif

#define ASSURE_SIZE_WRITE(sent_size, expected_size, return_type) \
  do {                                                           \
    if ((sent_size) != (ssize_t)(expected_size)) {               \
      return_type;                                               \
    }                                                            \
  } while (0)

#define ASSURE_SIZE_READ(sent_size, expected_size, return_type)  \
  do {                                                           \
    if ((sent_size) != (ssize_t)(expected_size)) {               \
      return_type;                                               \
    }                                                            \
  } while (0)

#define APP_ID(uid) ((uid) % 100000)

#define IS_ISOLATED_SERVICE(uid) \
  ((APP_ID(uid)) >= 90000)

#define write_func_def(type) \
  ssize_t write_##type(int fd, type val)

#define read_func_def(type) \
  ssize_t read_##type(int fd, type *val)

bool switch_mount_namespace(pid_t pid);

void get_property(const char *name, char *restrict output);

void set_socket_create_context(const char *restrict context);

void unix_datagram_sendto(const char *restrict path, const void *restrict buf, size_t len);

int chcon(const char *path, const char *restrict context);

int unix_listener_from_path(const char *path);

ssize_t write_fd(int fd, int sendfd);
int read_fd(int fd);

write_func_def(size_t);
read_func_def(size_t);

write_func_def(uint32_t);
read_func_def(uint32_t);

write_func_def(uint8_t);
read_func_def(uint8_t);

ssize_t write_string(int fd, const char *restrict str);
ssize_t read_string(int fd, char *restrict buf, size_t buf_size);

bool exec_command(char *restrict buf, size_t len, const char *restrict file, const char *const argv[]);

bool check_unix_socket(int fd, bool block);

int non_blocking_execv(const char *restrict file, char *const argv[]);

void stringify_root_impl_name(struct root_impl impl, char *restrict output);

int save_mns_fd(int pid, enum MountNamespaceState mns_state, struct root_impl impl);

#endif /* UTILS_H */
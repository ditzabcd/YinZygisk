#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <sched.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <linux/limits.h>
#include <sys/mount.h>
#include <sys/socket.h>
#include <sys/sysmacros.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <sys/xattr.h>

#include "root_impl/common.h"
#include "root_impl/kernelsu.h"
#include "utils.h"

bool switch_mount_namespace(pid_t pid) {
  char path[64];
  snprintf(path, sizeof(path), "/proc/%d/ns/mnt", pid);

  int nsfd = open(path, O_RDONLY | O_CLOEXEC);
  if (nsfd == -1) return false;

  bool ok = (setns(nsfd, CLONE_NEWNS) == 0);
  close(nsfd);

  return ok;
}

int __system_property_get(const char *, char *);

void get_property(const char *restrict name, char *restrict output) {
  __system_property_get(name, output);
}

void set_socket_create_context(const char *restrict context) {
  size_t len = strlen(context);

  FILE *sockcreate = fopen("/proc/thread-self/attr/sockcreate", "w");
  if (sockcreate != NULL) {
    size_t written = fwrite(context, 1, len, sockcreate);
    fclose(sockcreate);
    if (written == len) return;
  }

  char path[64];
  snprintf(path, sizeof(path), "/proc/self/task/%d/attr/sockcreate", gettid());

  sockcreate = fopen(path, "w");
  if (sockcreate == NULL) return;

  fwrite(context, 1, len, sockcreate);
  fclose(sockcreate);
}

static bool get_current_attr(char *restrict output, size_t size) {
  if (size == 0) return false;

  FILE *current = fopen("/proc/self/attr/current", "r");
  if (current == NULL) return false;

  size_t ret = fread(output, 1, size - 1, current);
  bool err = ferror(current) != 0;
  fclose(current);

  if (err) return false;

  output[ret] = '\0';
  return true;
}

void unix_datagram_sendto(const char *restrict path, const void *restrict buf, size_t len) {
  char current_attr[256];
  if (!get_current_attr(current_attr, sizeof(current_attr))) return;

  set_socket_create_context(current_attr);

  struct sockaddr_un addr = {
    .sun_family = AF_UNIX
  };
  snprintf(addr.sun_path, sizeof(addr.sun_path), "%s", path);

  int socket_fd = socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
  if (socket_fd == -1) {
    set_socket_create_context("u:r:zygote:s0");
    return;
  }

  if (connect(socket_fd, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
    sendto(socket_fd, buf, len, 0, (struct sockaddr *)&addr, sizeof(addr));
  }

  close(socket_fd);
  set_socket_create_context("u:r:zygote:s0");
}

int chcon(const char *restrict path, const char *context) {
  return lsetxattr(path, "security.selinux", context, strlen(context) + 1, 0);
}

int unix_listener_from_path(const char *restrict path) {
  if (remove(path) == -1 && errno != ENOENT) return -1;

  int socket_fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
  if (socket_fd == -1) return -1;

  struct sockaddr_un addr = {
    .sun_family = AF_UNIX
  };
  snprintf(addr.sun_path, sizeof(addr.sun_path), "%s", path);

  if (bind(socket_fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) == -1) {
    close(socket_fd);
    return -1;
  }

  if (listen(socket_fd, 2) == -1) {
    close(socket_fd);
    return -1;
  }

  chcon(path, "u:object_r:zygisk_file:s0");

  return socket_fd;
}

ssize_t write_fd(int fd, int sendfd) {
  char cmsgbuf[CMSG_SPACE(sizeof(int))];
  char buf[1] = { 0 };

  struct iovec iov = {
    .iov_base = buf,
    .iov_len = sizeof(buf)
  };

  struct msghdr msg = {
    .msg_iov = &iov,
    .msg_iovlen = 1,
    .msg_control = cmsgbuf,
    .msg_controllen = sizeof(cmsgbuf)
  };

  struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg);
  cmsg->cmsg_len = CMSG_LEN(sizeof(int));
  cmsg->cmsg_level = SOL_SOCKET;
  cmsg->cmsg_type = SCM_RIGHTS;

  memcpy(CMSG_DATA(cmsg), &sendfd, sizeof(int));

  return sendmsg(fd, &msg, 0);
}

int read_fd(int fd) {
  char cmsgbuf[CMSG_SPACE(sizeof(int))];

  int cnt = 1;
  struct iovec iov = {
    .iov_base = &cnt,
    .iov_len = sizeof(cnt)
  };

  struct msghdr msg = {
    .msg_iov = &iov,
    .msg_iovlen = 1,
    .msg_control = cmsgbuf,
    .msg_controllen = sizeof(cmsgbuf)
  };

  if (recvmsg(fd, &msg, MSG_WAITALL) <= 0) return -1;

  int sendfd = -1;
  for (struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg); cmsg != NULL; cmsg = CMSG_NXTHDR(&msg, cmsg)) {
    if (cmsg->cmsg_level != SOL_SOCKET || cmsg->cmsg_type != SCM_RIGHTS || cmsg->cmsg_len < CMSG_LEN(sizeof(int))) {
      continue;
    }

    memcpy(&sendfd, CMSG_DATA(cmsg), sizeof(int));
    break;
  }

  return sendfd;
}

#define write_func(type)                    \
  ssize_t write_##type(int fd, type val) {  \
    return write(fd, &val, sizeof(type));   \
  }

#define read_func(type)                     \
  ssize_t read_##type(int fd, type *val) {  \
    return read(fd, val, sizeof(type));     \
  }

write_func(size_t)
read_func(size_t)

write_func(uint32_t)
read_func(uint32_t)

write_func(uint8_t)
read_func(uint8_t)

ssize_t write_string(int fd, const char *restrict str) {
  size_t str_len = strlen(str);
  ssize_t written_bytes = write(fd, &str_len, sizeof(size_t));
  if (written_bytes != (ssize_t)sizeof(size_t)) return -1;

  written_bytes = write(fd, str, str_len);
  if (written_bytes != (ssize_t)str_len) return -1;

  return written_bytes;
}

ssize_t read_string(int fd, char *restrict buf, size_t buf_size) {
  if (buf_size == 0) return -1;

  size_t str_len = 0;
  ssize_t read_bytes = read(fd, &str_len, sizeof(size_t));
  if (read_bytes != (ssize_t)sizeof(size_t)) return -1;

  if (str_len > buf_size - 1) return -1;

  if (str_len > 0) {
    read_bytes = read(fd, buf, str_len);
    if (read_bytes != (ssize_t)str_len) return -1;
  }

  buf[str_len] = '\0';
  return (ssize_t)str_len;
}

bool exec_command(char *restrict buf, size_t len, const char *restrict file, const char *const argv[]) {
  if (len == 0) return false;

  int link[2];
  if (pipe(link) == -1) return false;

  pid_t pid = fork();
  if (pid == -1) {
    close(link[0]);
    close(link[1]);
    return false;
  }

  if (pid == 0) {
    dup2(link[1], STDOUT_FILENO);
    close(link[0]);
    close(link[1]);

    execv(file, (char *const *)argv);
    _exit(1);
  }

  close(link[1]);

  ssize_t nbytes = read(link[0], buf, len - 1);
  if (nbytes > 0) {
    while (nbytes > 0 && (buf[nbytes - 1] == '\n' || buf[nbytes - 1] == '\r')) {
      nbytes--;
    }
    buf[nbytes] = '\0';
  } else {
    buf[0] = '\0';
  }

  waitpid(pid, NULL, 0);
  close(link[0]);

  return true;
}

bool check_unix_socket(int fd, bool block) {
  struct pollfd pfd = {
    .fd = fd,
    .events = POLLIN,
    .revents = 0
  };

  int timeout = block ? -1 : 0;
  if (poll(&pfd, 1, timeout) == -1) return false;

  return (pfd.revents & ~POLLIN) == 0;
}

int non_blocking_execv(const char *restrict file, char *const argv[]) {
  pid_t pid = fork();
  if (pid == -1) return -1;

  if (pid == 0) {
    int devnull = open("/dev/null", O_WRONLY);
    if (devnull >= 0) {
      dup2(devnull, STDOUT_FILENO);
      dup2(devnull, STDERR_FILENO);
      if (devnull > STDERR_FILENO) close(devnull);
    }

    execv(file, argv);
    _exit(1);
  }

  return 0;
}

void stringify_root_impl_name(struct root_impl impl, char *restrict output) {
  switch (impl.impl) {
    case KernelSU:
      strcpy(output, (impl.variant == KOfficial) ? "KernelSU" : "KernelSU Next");
      break;
    case Multiple:
      strcpy(output, "Multiple");
      break;
    default:
      strcpy(output, "None");
      break;
  }
}

struct mountinfo {
  unsigned int id;
  unsigned int parent;
  dev_t device;
  char *root;
  char *target;
  char *vfs_option;
  struct {
    unsigned int shared;
    unsigned int master;
    unsigned int propagate_from;
  } optional;
  char *type;
  char *source;
  char *fs_option;
};

struct mountinfos {
  struct mountinfo *mounts;
  size_t length;
};

static char *dup_substr(const char *restrict str, size_t length) {
  char *copy = malloc(length + 1);
  if (copy == NULL) return NULL;

  memcpy(copy, str, length);
  copy[length] = '\0';

  return copy;
}

static void free_mounts(struct mountinfos *restrict mounts) {
  for (size_t i = 0; i < mounts->length; i++) {
    free(mounts->mounts[i].root);
    free(mounts->mounts[i].target);
    free(mounts->mounts[i].vfs_option);
    free(mounts->mounts[i].type);
    free(mounts->mounts[i].source);
    free(mounts->mounts[i].fs_option);
  }

  free(mounts->mounts);
}

static bool parse_mountinfo(const char *restrict pid, struct mountinfos *restrict mounts) {
  char path[64];
  snprintf(path, sizeof(path), "/proc/%s/mountinfo", pid);

  FILE *mountinfo = fopen(path, "r");
  if (mountinfo == NULL) return false;

  char line[PATH_MAX];
  size_t i = 0;

  mounts->mounts = NULL;
  mounts->length = 0;

  while (fgets(line, sizeof(line), mountinfo) != NULL) {
    int root_start = 0, root_end = 0;
    int target_start = 0, target_end = 0;
    int vfs_option_start = 0, vfs_option_end = 0;
    int type_start = 0, type_end = 0;
    int source_start = 0, source_end = 0;
    int fs_option_start = 0, fs_option_end = 0;
    int optional_start = 0, optional_end = 0;
    unsigned int id = 0, parent = 0, maj = 0, min = 0;

    if (sscanf(line,
               "%u %u %u:%u %n%*s%n %n%*s%n %n%*s%n %n%*[^-]%n - %n%*s%n %n%*s%n %n%*s%n",
               &id, &parent, &maj, &min,
               &root_start, &root_end,
               &target_start, &target_end,
               &vfs_option_start, &vfs_option_end,
               &optional_start, &optional_end,
               &type_start, &type_end,
               &source_start, &source_end,
               &fs_option_start, &fs_option_end) < 4) {
      continue;
    }

    if (root_end < root_start || target_end < target_start || vfs_option_end < vfs_option_start ||
        type_end < type_start || source_end < source_start || fs_option_end < fs_option_start) {
      continue;
    }

    struct mountinfo *tmp_mounts = realloc(mounts->mounts, (i + 1) * sizeof(struct mountinfo));
    if (!tmp_mounts) goto cleanup_mount_allocs;
    mounts->mounts = tmp_mounts;

    unsigned int shared = 0;
    unsigned int master = 0;
    unsigned int propagate_from = 0;
    const char *opt_ptr = line + optional_start;

    const char *p = strstr(opt_ptr, "shared:");
    if (p) shared = (unsigned int)atoi(p + 7);

    p = strstr(opt_ptr, "master:");
    if (p) master = (unsigned int)atoi(p + 7);

    p = strstr(opt_ptr, "propagate_from:");
    if (p) propagate_from = (unsigned int)atoi(p + 15);

    mounts->mounts[i].id = id;
    mounts->mounts[i].parent = parent;
    mounts->mounts[i].device = (dev_t)(makedev(maj, min));
    mounts->mounts[i].optional.shared = shared;
    mounts->mounts[i].optional.master = master;
    mounts->mounts[i].optional.propagate_from = propagate_from;

    mounts->mounts[i].root = dup_substr(line + root_start, (size_t)(root_end - root_start));
    if (mounts->mounts[i].root == NULL) goto cleanup_mount_allocs;

    mounts->mounts[i].target = dup_substr(line + target_start, (size_t)(target_end - target_start));
    if (mounts->mounts[i].target == NULL) goto cleanup_root;

    mounts->mounts[i].vfs_option = dup_substr(line + vfs_option_start, (size_t)(vfs_option_end - vfs_option_start));
    if (mounts->mounts[i].vfs_option == NULL) goto cleanup_target;

    mounts->mounts[i].type = dup_substr(line + type_start, (size_t)(type_end - type_start));
    if (mounts->mounts[i].type == NULL) goto cleanup_vfs_option;

    mounts->mounts[i].source = dup_substr(line + source_start, (size_t)(source_end - source_start));
    if (mounts->mounts[i].source == NULL) goto cleanup_type;

    mounts->mounts[i].fs_option = dup_substr(line + fs_option_start, (size_t)(fs_option_end - fs_option_start));
    if (mounts->mounts[i].fs_option == NULL) goto cleanup_source;

    i++;
    continue;

  cleanup_source:
    free(mounts->mounts[i].source);
  cleanup_type:
    free(mounts->mounts[i].type);
  cleanup_vfs_option:
    free(mounts->mounts[i].vfs_option);
  cleanup_target:
    free(mounts->mounts[i].target);
  cleanup_root:
    free(mounts->mounts[i].root);
  cleanup_mount_allocs:
    fclose(mountinfo);
    mounts->length = i;
    free_mounts(mounts);
    return false;
  }

  fclose(mountinfo);
  mounts->length = i;

  return true;
}

static bool umount_root(struct root_impl impl) {
  struct mountinfos mounts;
  if (!parse_mountinfo("self", &mounts)) return false;

  bool is_ksu = (impl.impl == KernelSU);
  char **targets_to_unmount = NULL;
  size_t num_targets = 0;

  for (size_t i = 0; i < mounts.length; i++) {
    struct mountinfo *mount = &mounts.mounts[i];

    bool should_unmount = false;
    if (is_ksu && strcmp(mount->source, "KSU") == 0) should_unmount = true;
    if (strncmp(mount->target, "/data/adb/modules", sizeof("/data/adb/modules") - 1) == 0) should_unmount = true;
    if (strncmp(mount->root, "/adb/modules/", sizeof("/adb/modules/") - 1) == 0) should_unmount = true;

    if (!should_unmount) continue;

    char **tmp_targets = realloc(targets_to_unmount, (num_targets + 1) * sizeof(char *));
    if (tmp_targets == NULL) {
      free(targets_to_unmount);
      free_mounts(&mounts);
      return false;
    }

    targets_to_unmount = tmp_targets;
    targets_to_unmount[num_targets++] = mount->target;
  }

  for (size_t i = num_targets; i > 0; i--) {
    umount2(targets_to_unmount[i - 1], MNT_DETACH);
  }

  free(targets_to_unmount);
  free_mounts(&mounts);

  return true;
}

int save_mns_fd(int pid, enum MountNamespaceState mns_state, struct root_impl impl) {
  static int clean_namespace_fd = -1;
  static int mounted_namespace_fd = -1;

  if (mns_state == Clean && clean_namespace_fd != -1) return clean_namespace_fd;
  if (mns_state == Mounted && mounted_namespace_fd != -1) return mounted_namespace_fd;

  int sockets[2];
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, sockets) == -1) return -1;

  int socket_parent = sockets[0];
  int socket_child = sockets[1];

  pid_t fork_pid = fork();
  if (fork_pid < 0) {
    close(socket_parent);
    close(socket_child);
    return -1;
  }

  if (fork_pid == 0) {
    close(socket_parent);

    if (!switch_mount_namespace(pid)) {
      write_uint8_t(socket_child, 0);
      goto finalize_mns_fork;
    }

    if (mns_state == Clean) {
      unshare(CLONE_NEWNS);

      if (!umount_root(impl)) {
        write_uint8_t(socket_child, 0);
        goto finalize_mns_fork;
      }
    }

    if (write_uint8_t(socket_child, 1) == -1) {
      close(socket_child);
      _exit(1);
    }

    uint8_t has_opened = 0;
    read_uint8_t(socket_child, &has_opened);

  finalize_mns_fork:
    close(socket_child);
    _exit(0);
  }

  close(socket_child);

  uint8_t has_succeeded = 0;
  if (read_uint8_t(socket_parent, &has_succeeded) <= 0 || !has_succeeded) {
    close(socket_parent);
    waitpid(fork_pid, NULL, 0);
    return -1;
  }

  char ns_path[64];
  snprintf(ns_path, sizeof(ns_path), "/proc/%d/ns/mnt", fork_pid);

  int ns_fd = open(ns_path, O_RDONLY);
  if (ns_fd == -1) {
    close(socket_parent);
    waitpid(fork_pid, NULL, 0);
    return -1;
  }

  if (write_uint8_t(socket_parent, 1) == -1) {
    close(ns_fd);
    close(socket_parent);
    waitpid(fork_pid, NULL, 0);
    return -1;
  }

  close(socket_parent);
  waitpid(fork_pid, NULL, 0);

  if (mns_state == Clean) clean_namespace_fd = ns_fd;
  else if (mns_state == Mounted) mounted_namespace_fd = ns_fd;

  return ns_fd;
}
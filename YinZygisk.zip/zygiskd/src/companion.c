#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <dlfcn.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "utils.h"

typedef void (*zygisk_companion_entry)(int);

struct companion_module_thread_args {
  int fd;
  zygisk_companion_entry entry;
};

static zygisk_companion_entry load_module(int fd) {
  char path[64];
  snprintf(path, sizeof(path), "/proc/self/fd/%d", fd);

  void *handle = dlopen(path, RTLD_NOW);
  if (!handle) return NULL;

  void *entry = dlsym(handle, "zygisk_companion_entry");
  if (!entry) {
    dlclose(handle);
    return NULL;
  }

  return (zygisk_companion_entry)entry;
}

static void *entry_thread(void *arg) {
  struct companion_module_thread_args *args = (struct companion_module_thread_args *)arg;

  int fd = args->fd;
  zygisk_companion_entry module_entry = args->entry;
  free(args);

  struct stat st0 = { 0 };
  if (fstat(fd, &st0) == -1) return NULL;

  module_entry(fd);

  struct stat st1;
  if (fstat(fd, &st1) != -1 && st0.st_dev == st1.st_dev && st0.st_ino == st1.st_ino) {
    close(fd);
  }

  return NULL;
}

void companion_entry(int fd) {
  char name[256 + 1];
  ssize_t ret = read_string(fd, name, sizeof(name));
  if (ret == -1) goto cleanup;

  int library_fd = read_fd(fd);
  if (library_fd == -1) goto cleanup;

  zygisk_companion_entry module_entry = load_module(library_fd);
  close(library_fd);

  if (module_entry == NULL) {
    write_uint8_t(fd, 0);
    goto cleanup;
  }

  ret = write_uint8_t(fd, 1);
  if (ret != (ssize_t)sizeof(uint8_t)) goto cleanup;

  struct sigaction sa = { .sa_handler = SIG_IGN };
  sigaction(SIGPIPE, &sa, NULL);

  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

  while (1) {
    if (!check_unix_socket(fd, true)) break;

    int client_fd = read_fd(fd);
    if (client_fd == -1) break;

    struct companion_module_thread_args *args = malloc(sizeof(struct companion_module_thread_args));
    if (args == NULL) {
      close(client_fd);
      break;
    }

    args->fd = client_fd;
    args->entry = module_entry;

    ret = write_uint8_t(client_fd, 1);
    if (ret != (ssize_t)sizeof(uint8_t)) {
      free(args);
      close(client_fd);
      break;
    }

    pthread_t thread;
    if (pthread_create(&thread, &attr, entry_thread, args) != 0) {
      free(args);
      close(client_fd);
      break;
    }
  }

  pthread_attr_destroy(&attr);

cleanup:
  close(fd);
  _exit(0);
}
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

#include <sys/ioctl.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/system_properties.h>

#include "../utils.h"
#include "common.h"
#include "kernelsu.h"

static const char *const ksu_manager_pkgs[] = {
  "me.weishu.kernelsu",
  "com.rifsxd.ksunext",
};

#define KSU_INSTALL_MAGIC1 (int)0xDEADBEEF
#define KSU_INSTALL_MAGIC2 (int)0xCAFEBABE

#define CMD_GET_VERSION 2
#define CMD_UID_GRANTED_ROOT 12
#define CMD_UID_SHOULD_UMOUNT 13
#define CMD_GET_MANAGER_UID 16
#define CMD_HOOK_MODE 0xC0DEAD1A

struct ksu_uid_granted_root_cmd {
  uint32_t uid;
  uint8_t granted;
};

struct ksu_uid_should_umount_cmd {
  uint32_t uid;
  uint8_t should_umount;
};

struct ksu_get_manager_uid_cmd {
  uint32_t uid;
};

struct ksu_set_feature_cmd {
  uint32_t feature_id;
  uint64_t value;
};

struct ksu_get_hook_mode_cmd {
  char mode[16];
};

#define KSU_IOCTL_UID_GRANTED_ROOT  _IOC(_IOC_READ | _IOC_WRITE, 'K', 8, 0)
#define KSU_IOCTL_UID_SHOULD_UMOUNT _IOC(_IOC_READ | _IOC_WRITE, 'K', 9, 0)
#define KSU_IOCTL_GET_MANAGER_UID   _IOC(_IOC_READ, 'K', 10, 0)
#define KSU_IOCTL_SET_FEATURE       _IOC(_IOC_WRITE, 'K', 14, 0)
#define KSU_IOCTL_GET_HOOK_MODE     _IOC(_IOC_READ, 'K', 98, 0)

static enum kernelsu_variants variant = KOfficial;
static int ksu_fd = -1;
static bool supports_manager_uid_retrieval = false;
static bool ksu_uses_new_ksuctl = false;

void ksu_get_existence(struct root_impl_state *state) {
  char platform[PROP_VALUE_MAX] = { 0 };
  get_property("ro.board.platform", platform);

  if (strcmp(platform, "waydroid") == 0) {
    goto try_prctl;
  }

  syscall(SYS_reboot, KSU_INSTALL_MAGIC1, KSU_INSTALL_MAGIC2, 0, (void *)&ksu_fd);
  if (ksu_fd == -1) {
  try_prctl:;
    int reply_ok = 0;
    int version = 0;
    prctl(KSU_INSTALL_MAGIC1, CMD_GET_VERSION, &version, 0L, &reply_ok);

    if (version == 0) {
      state->state = Abnormal;
    } else if (version >= MIN_KSU_VERSION) {
      if (access("/data/adb/ksu/bin/ksud", F_OK) == -1) {
        state->state = Inexistent;
        return;
      }

      state->state = Supported;

      char mode[16] = { 0 };
      prctl(KSU_INSTALL_MAGIC1, CMD_HOOK_MODE, mode, 0L, &reply_ok);

      variant = (mode[0] != '\0') ? KNext : KOfficial;
      state->variant = (uint8_t)variant;

      prctl(KSU_INSTALL_MAGIC1, CMD_GET_MANAGER_UID, 0L, 0L, &reply_ok);
      if (reply_ok == KSU_INSTALL_MAGIC1) {
        supports_manager_uid_retrieval = true;
      }
    } else if (version >= 1 && version < MIN_KSU_VERSION) {
      state->state = TooOld;
    } else {
      state->state = Abnormal;
    }

    return;
  }

  if (access("/data/adb/ksu/bin/ksud", F_OK) == -1) {
    close(ksu_fd);
    ksu_fd = -1;
    state->state = Inexistent;
    return;
  }

  ksu_uses_new_ksuctl = true;

  struct ksu_set_feature_cmd cmd = {
    .feature_id = 1,
    .value = 0
  };
  ioctl(ksu_fd, KSU_IOCTL_SET_FEATURE, &cmd);

  struct ksu_get_hook_mode_cmd hook_mode_cmd = { 0 };
  ioctl(ksu_fd, KSU_IOCTL_GET_HOOK_MODE, &hook_mode_cmd);

  variant = (hook_mode_cmd.mode[0] != '\0') ? KNext : KOfficial;
  state->variant = (uint8_t)variant;
  state->state = Supported;
}

bool ksu_uid_granted_root(uid_t uid) {
  if (!ksu_uses_new_ksuctl) {
    bool granted = false;
    uint32_t result = 0;
    prctl(KSU_INSTALL_MAGIC1, CMD_UID_GRANTED_ROOT, uid, &granted, &result);

    if ((int)result != KSU_INSTALL_MAGIC1) return false;
    return granted;
  }

  struct ksu_uid_granted_root_cmd cmd = {
    .uid = uid,
    .granted = 0
  };

  if (ioctl(ksu_fd, KSU_IOCTL_UID_GRANTED_ROOT, &cmd) == -1) {
    return false;
  }

  return cmd.granted != 0;
}

bool ksu_uid_should_umount(uid_t uid) {
  if (!ksu_uses_new_ksuctl) {
    bool should_umount = false;
    uint32_t result = 0;
    prctl(KSU_INSTALL_MAGIC1, CMD_UID_SHOULD_UMOUNT, uid, &should_umount, &result);

    if ((int)result != KSU_INSTALL_MAGIC1) return false;
    return should_umount;
  }

  struct ksu_uid_should_umount_cmd cmd = {
    .uid = uid,
    .should_umount = 0
  };

  if (ioctl(ksu_fd, KSU_IOCTL_UID_SHOULD_UMOUNT, &cmd) == -1) {
    return false;
  }

  return cmd.should_umount != 0;
}

bool ksu_uid_is_manager(uid_t uid) {
  if (!ksu_uses_new_ksuctl) {
    if (supports_manager_uid_retrieval) {
      int reply_ok = 0;
      uid_t manager_uid = 0;
      prctl(KSU_INSTALL_MAGIC1, CMD_GET_MANAGER_UID, &manager_uid, 0L, &reply_ok);

      return APP_ID(uid) == APP_ID(manager_uid);
    }

    size_t idx = (variant == KNext) ? 1 : 0;
    uid_t manager_uid = uid_from_pkg(ksu_manager_pkgs[idx]);
    if (!manager_uid) return false;

    return APP_ID(uid) == manager_uid;
  }

  struct ksu_get_manager_uid_cmd cmd = { 0 };
  if (ioctl(ksu_fd, KSU_IOCTL_GET_MANAGER_UID, &cmd) == -1) {
    return false;
  }

  return APP_ID(uid) == cmd.uid;
}

void ksu_cleanup(void) {
  if (ksu_fd != -1) {
    close(ksu_fd);
    ksu_fd = -1;
  }
}
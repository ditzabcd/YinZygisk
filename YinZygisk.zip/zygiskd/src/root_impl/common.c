#include "common.h"

#include <dirent.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "../utils.h"
#include "kernelsu.h"

static struct root_impl impl;

void root_impls_setup(void) {
  struct root_impl_state state_ksu = { 0 };
  ksu_get_existence(&state_ksu);

  if (state_ksu.state == Supported) {
    impl.impl = KernelSU;
    impl.variant = state_ksu.variant;
  } else {
    impl.impl = None;
    impl.variant = 0;
  }
}

void get_impl(struct root_impl *uimpl) {
  *uimpl = impl;
}

bool uid_granted_root(uid_t uid) {
  if (impl.impl == KernelSU) {
    return ksu_uid_granted_root(uid);
  }
  return false;
}

bool uid_should_umount(uid_t uid, const char *const process) {
  (void)process;
  if (impl.impl == KernelSU) {
    return ksu_uid_should_umount(uid);
  }
  return false;
}

uid_t uid_from_pkg(const char *restrict pkg) {
  DIR *dir = opendir("/data/user");
  if (!dir) return 0;

  uid_t found_uid = 0;
  struct dirent *entry;
  struct stat st;

  while ((entry = readdir(dir)) != NULL) {
    if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
      continue;
    }

    char stat_path[256];
    snprintf(stat_path, sizeof(stat_path), "/data/user_de/%s/%s", entry->d_name, pkg);

    if (stat(stat_path, &st) == 0) {
      found_uid = APP_ID(st.st_uid);
      break;
    }
  }

  closedir(dir);
  return found_uid;
}

bool uid_is_manager(uid_t uid) {
  if (impl.impl == KernelSU) {
    return ksu_uid_is_manager(uid);
  }
  return false;
}

void root_impl_cleanup(void) {
  if (impl.impl == KernelSU) {
    ksu_cleanup();
  }
}
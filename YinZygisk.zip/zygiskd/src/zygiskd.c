#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <linux/limits.h>
#include <sys/socket.h>
#include <sys/wait.h>

#include "constants.h"
#include "root_impl/common.h"
#include "utils.h"

struct Module {
  char *name;
  int lib_fd;
  int companion;
};

struct Context {
  struct Module *modules;
  size_t len;
};

struct yzd_msg_header {
  uint8_t cmd;
  uint32_t len;
  char data[0];
} __attribute__((packed));

struct yzd_info_payload {
  char impl[LONGEST_ROOT_IMPL_NAME];
  uint32_t modules_count;
  char data[0];
} __attribute__((packed));

#define PATH_MODULES_DIR "/data/adb/modules"
#define TMP_PATH "/data/adb/yinzygisk"
#define CONTROLLER_SOCKET TMP_PATH "/init_monitor"
#define PATH_CP_NAME TMP_PATH "/" LP_SELECT("cp32.sock", "cp64.sock")
#define ZYGISKD_PATH PATH_MODULES_DIR "/yinzygisk/bin/zygiskd" LP_SELECT("32", "64")

#ifdef __aarch64__
  #define ARCH_STR "arm64-v8a"
#elif __arm__
  #define ARCH_STR "armeabi-v7a"
#elif __x86_64__
  #define ARCH_STR "x86_64"
#elif __i386__
  #define ARCH_STR "x86"
#else
  #error "Unsupported architecture"
#endif

static void free_modules(struct Context *restrict context) {
  for (size_t i = 0; i < context->len; i++) {
    free(context->modules[i].name);
    if (context->modules[i].companion >= 0) close(context->modules[i].companion);
    if (context->modules[i].lib_fd >= 0) close(context->modules[i].lib_fd);
  }

  free(context->modules);
  context->modules = NULL;
  context->len = 0;
}

static void load_modules(struct Context *restrict context) {
  context->len = 0;
  context->modules = NULL;

  DIR *dir = opendir(PATH_MODULES_DIR);
  if (dir == NULL) return;

  struct dirent *entry;
  while ((entry = readdir(dir)) != NULL) {
    if (entry->d_type != DT_DIR) continue;
    if (strcmp(entry->d_name, ".") == 0 ||
        strcmp(entry->d_name, "..") == 0 ||
        strcmp(entry->d_name, "yinzygisk") == 0) {
      continue;
    }

    const char *name = entry->d_name;
    char path_buf[PATH_MAX];

    snprintf(path_buf, sizeof(path_buf), PATH_MODULES_DIR "/%s/zygisk/" ARCH_STR ".so", name);
    if (access(path_buf, R_OK) == -1) continue;

    snprintf(path_buf, sizeof(path_buf), PATH_MODULES_DIR "/%s/disable", name);
    if (access(path_buf, F_OK) == 0) continue;

    snprintf(path_buf, sizeof(path_buf), PATH_MODULES_DIR "/%s/zygisk/" ARCH_STR ".so", name);
    int lib_fd = open(path_buf, O_RDONLY | O_CLOEXEC);
    if (lib_fd == -1) continue;

    struct Module *tmp_modules = realloc(context->modules, (context->len + 1) * sizeof(struct Module));
    if (tmp_modules == NULL) {
      close(lib_fd);
      free_modules(context);
      closedir(dir);
      return;
    }
    context->modules = tmp_modules;

    context->modules[context->len].name = strdup(name);
    if (context->modules[context->len].name == NULL) {
      close(lib_fd);
      free_modules(context);
      closedir(dir);
      return;
    }

    context->modules[context->len].lib_fd = lib_fd;
    context->modules[context->len].companion = -1;
    context->len++;
  }

  closedir(dir);
}

static int create_daemon_socket(void) {
  set_socket_create_context("u:r:zygote:s0");
  return unix_listener_from_path(PATH_CP_NAME);
}

static int spawn_companion(char *restrict argv[], const char *restrict name, int lib_fd) {
  int sockets[2];
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, sockets) == -1) return -1;

  int daemon_fd = sockets[0];
  int companion_fd = sockets[1];

  pid_t pid = fork();
  if (pid < 0) {
    close(companion_fd);
    close(daemon_fd);
    return -1;
  }

  if (pid > 0) {
    close(companion_fd);

    int status = 0;
    waitpid(pid, &status, 0);

    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
      close(daemon_fd);
      return -1;
    }

    if (write_string(daemon_fd, name) == -1 || write_fd(daemon_fd, lib_fd) == -1) {
      close(daemon_fd);
      return -1;
    }

    uint8_t response = 0;
    if (read_uint8_t(daemon_fd, &response) <= 0) {
      close(daemon_fd);
      return -1;
    }

    if (response == 1) return daemon_fd;

    close(daemon_fd);
    return (response == 0) ? -2 : -1;
  }

  close(daemon_fd);

  if (fcntl(companion_fd, F_SETFD, 0) == -1) {
    close(companion_fd);
    _exit(1);
  }

  const char *process = argv[0];
  const char *last = strrchr(process, '/');
  const char *nice_name = last ? (last + 1) : process;

  char process_name[256];
  snprintf(process_name, sizeof(process_name), "%s-%s", nice_name, name);

  char companion_fd_str[32];
  snprintf(companion_fd_str, sizeof(companion_fd_str), "%d", companion_fd);

  char companion[] = "companion";
  char *eargv[] = { process_name, companion, companion_fd_str, NULL };
  if (non_blocking_execv(ZYGISKD_PATH, eargv) == -1) {
    close(companion_fd);
    _exit(1);
  }

  _exit(0);
}

void zygiskd_start(char *restrict argv[]) {
  struct Context context = { 0 };

  struct root_impl impl;
  get_impl(&impl);
  if (impl.impl == None || impl.impl == Multiple) {
    const char *msg = (impl.impl == None)
                          ? "Unsupported environment: Unknown root implementation"
                          : "Unsupported environment: Multiple root implementations found";

    size_t err_len = strlen(msg) + 1;
    struct yzd_msg_header *message = malloc(sizeof(struct yzd_msg_header) + err_len);
    if (message == NULL) exit(EXIT_FAILURE);

    message->cmd = DAEMON_SET_ERROR_INFO;
    message->len = (uint32_t)err_len;
    memcpy(message->data, msg, err_len);

    unix_datagram_sendto(CONTROLLER_SOCKET, message, sizeof(struct yzd_msg_header) + err_len);
    free(message);

    exit(EXIT_FAILURE);
  }

  load_modules(&context);

  size_t info_len = sizeof(struct yzd_info_payload);
  for (size_t i = 0; i < context.len; i++) {
    info_len += strlen(context.modules[i].name) + 1;
  }

  struct yzd_msg_header *message = malloc(sizeof(struct yzd_msg_header) + info_len);
  if (message == NULL) {
    free_modules(&context);
    root_impl_cleanup();
    return;
  }

  message->cmd = DAEMON_SET_INFO;
  message->len = (uint32_t)info_len;

  struct yzd_info_payload *info = (void *)message->data;
  stringify_root_impl_name(impl, info->impl);
  info->modules_count = (uint32_t)context.len;

  char *raw_payload = info->data;
  for (size_t i = 0; i < context.len; i++) {
    size_t module_name_len = strlen(context.modules[i].name);
    memcpy(raw_payload, context.modules[i].name, module_name_len + 1);
    raw_payload += module_name_len + 1;
  }

  unix_datagram_sendto(CONTROLLER_SOCKET, message, sizeof(struct yzd_msg_header) + info_len);
  free(message);

  int socket_fd = create_daemon_socket();
  if (socket_fd == -1) {
    free_modules(&context);
    root_impl_cleanup();
    return;
  }

  struct sigaction sa = { .sa_handler = SIG_IGN };
  sigaction(SIGPIPE, &sa, NULL);

  bool first_process = true;
  while (1) {
    int client_fd = accept(socket_fd, NULL, NULL);
    if (client_fd == -1) break;

    uint8_t action8 = 0;
    ssize_t len = read_uint8_t(client_fd, &action8);
    if (len <= 0) {
      close(client_fd);
      break;
    }

    enum DaemonSocketAction action = (enum DaemonSocketAction)action8;

    switch (action) {
      case ZygoteInjected: {
        struct yzd_msg_header hdr = {
          .cmd = ZYGOTE_INJECTED,
          .len = 0
        };
        unix_datagram_sendto(CONTROLLER_SOCKET, &hdr, sizeof(hdr));
        break;
      }

      case ZygoteRestart: {
        for (size_t i = 0; i < context.len; i++) {
          if (context.modules[i].companion >= 0) {
            close(context.modules[i].companion);
            context.modules[i].companion = -1;
          }
        }
        break;
      }

      case GetProcessFlags: {
        uint32_t uid = 0;
        ssize_t ret = read_uint32_t(client_fd, &uid);
        ASSURE_SIZE_READ(ret, sizeof(uid), break);

        char process[PROCESS_NAME_MAX_LEN];
        if (read_string(client_fd, process, sizeof(process)) == -1) break;

        uint32_t flags = 0;
        if (first_process) {
          flags |= PROCESS_IS_FIRST_STARTED;
          first_process = false;
        }

        if (uid_is_manager(uid)) {
          flags |= PROCESS_IS_MANAGER;
        } else {
          if (uid_granted_root(uid)) flags |= PROCESS_GRANTED_ROOT;
          if (uid_should_umount(uid, process)) flags |= PROCESS_ON_DENYLIST;
        }

        if (impl.impl == KernelSU) {
          flags |= PROCESS_ROOT_IS_KSU;
        }

        ret = write_uint32_t(client_fd, flags);
        ASSURE_SIZE_WRITE(ret, sizeof(flags), break);
        break;
      }

      case GetInfo: {
        uint32_t flags = (impl.impl == KernelSU) ? PROCESS_ROOT_IS_KSU : 0;

        ssize_t ret = write_uint32_t(client_fd, flags);
        ASSURE_SIZE_WRITE(ret, sizeof(flags), break);

        uint32_t pid = (uint32_t)getpid();
        ret = write_uint32_t(client_fd, pid);
        ASSURE_SIZE_WRITE(ret, sizeof(pid), break);

        size_t modules_len = context.len;
        ret = write_size_t(client_fd, modules_len);
        ASSURE_SIZE_WRITE(ret, sizeof(modules_len), break);

        for (size_t i = 0; i < modules_len; i++) {
          if (write_string(client_fd, context.modules[i].name) == -1) break;
        }
        break;
      }

      case ReadModules: {
        size_t clen = context.len;
        ssize_t ret = write_size_t(client_fd, clen);
        ASSURE_SIZE_WRITE(ret, sizeof(clen), break);

        for (size_t i = 0; i < clen; i++) {
          char lib_path[PATH_MAX];
          snprintf(lib_path, sizeof(lib_path), PATH_MODULES_DIR "/%s/zygisk/" ARCH_STR ".so", context.modules[i].name);
          if (write_string(client_fd, lib_path) == -1) break;
        }
        break;
      }

      case RequestCompanionSocket: {
        size_t index = 0;
        ssize_t ret = read_size_t(client_fd, &index);
        ASSURE_SIZE_READ(ret, sizeof(index), break);

        if (index >= context.len) {
          ret = write_uint8_t(client_fd, 0);
          ASSURE_SIZE_WRITE(ret, sizeof(uint8_t), break);
          break;
        }

        struct Module *module = &context.modules[index];
        if (module->companion >= 0 && !check_unix_socket(module->companion, false)) {
          close(module->companion);
          module->companion = -1;
        }

        if (module->companion <= -1) {
          module->companion = spawn_companion(argv, module->name, module->lib_fd);
        }

        if (module->companion >= 0) {
          if (write_fd(module->companion, client_fd) == -1) {
            ret = write_uint8_t(client_fd, 0);
            ASSURE_SIZE_WRITE(ret, sizeof(uint8_t), break);

            close(module->companion);
            module->companion = -1;
          }
        } else {
          ret = write_uint8_t(client_fd, 0);
          ASSURE_SIZE_WRITE(ret, sizeof(uint8_t), break);
        }
        break;
      }

      case GetModuleDir: {
        size_t index = 0;
        ssize_t ret = read_size_t(client_fd, &index);
        ASSURE_SIZE_READ(ret, sizeof(index), break);

        if (index >= context.len) {
          ret = write_uint8_t(client_fd, 0);
          ASSURE_SIZE_WRITE(ret, sizeof(uint8_t), break);
          break;
        }

        char module_dir[PATH_MAX];
        snprintf(module_dir, sizeof(module_dir), "%s/%s", PATH_MODULES_DIR, context.modules[index].name);

        int fd = open(module_dir, O_RDONLY | O_CLOEXEC);
        if (fd == -1) break;

        write_fd(client_fd, fd);
        close(fd);
        break;
      }

      case UpdateMountNamespace: {
        uint32_t pid_u32 = 0;
        ssize_t ret = read_uint32_t(client_fd, &pid_u32);
        ASSURE_SIZE_READ(ret, sizeof(pid_u32), break);
        pid_t pid = (pid_t)pid_u32;

        uint8_t mns_state = 0;
        ret = read_uint8_t(client_fd, &mns_state);
        ASSURE_SIZE_READ(ret, sizeof(mns_state), break);

        uint32_t our_pid = (uint32_t)getpid();
        ret = write_uint32_t(client_fd, our_pid);
        ASSURE_SIZE_WRITE(ret, sizeof(our_pid), break);

        if ((enum MountNamespaceState)mns_state == Clean) {
          save_mns_fd(pid, Mounted, impl);
        }

        int ns_fd = save_mns_fd(pid, (enum MountNamespaceState)mns_state, impl);
        if (ns_fd == -1) {
          ret = write_uint32_t(client_fd, 0u);
          ASSURE_SIZE_WRITE(ret, sizeof(uint32_t), break);
          break;
        }

        ret = write_uint32_t(client_fd, (uint32_t)ns_fd);
        ASSURE_SIZE_WRITE(ret, sizeof(uint32_t), break);
        break;
      }

      case RemoveModule: {
        size_t index = 0;
        ssize_t ret = read_size_t(client_fd, &index);
        ASSURE_SIZE_READ(ret, sizeof(index), break);

        if (index >= context.len) {
          ret = write_uint8_t(client_fd, 0);
          ASSURE_SIZE_WRITE(ret, sizeof(uint8_t), break);
          break;
        }

        struct Module *module = &context.modules[index];
        if (module->companion >= 0) {
          close(module->companion);
          module->companion = -1;
        }

        free(module->name);
        module->name = NULL;

        if (module->lib_fd >= 0) {
          close(module->lib_fd);
          module->lib_fd = -1;
        }

        memmove(&context.modules[index],
                &context.modules[index + 1],
                (context.len - index - 1) * sizeof(struct Module));
        context.len--;

        ret = write_uint8_t(client_fd, 1);
        ASSURE_SIZE_WRITE(ret, sizeof(uint8_t), break);
        break;
      }
    }

    close(client_fd);
  }

  close(socket_fd);
  free_modules(&context);
  root_impl_cleanup();
}
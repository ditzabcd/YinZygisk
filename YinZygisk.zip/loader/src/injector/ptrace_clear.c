#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include <fcntl.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <unistd.h>

#include "ptrace_clear.h"

static bool seccomp_filters_visible(void) {
  int fd = open("/proc/self/status", O_RDONLY | O_CLOEXEC);
  if (fd == -1) return true;

  char buf[4096];
  ssize_t n = read(fd, buf, sizeof(buf) - 1);
  close(fd);
  if (n <= 0) return true;

  buf[n] = '\0';
  return strstr(buf, "\nSeccomp_filters:") != NULL;
}

void perform_ptrace_message_clear(void) {
  if (seccomp_filters_visible()) return;

  uint32_t args[4] = { 0 };
  if (syscall(__NR_getrandom, args, sizeof(args), 0) != (ssize_t)sizeof(args)) {
    int rnd_fd = open("/dev/urandom", O_RDONLY | O_CLOEXEC);
    if (rnd_fd == -1) return;

    if (read(rnd_fd, args, sizeof(args)) != (ssize_t)sizeof(args)) {
      close(rnd_fd);
      return;
    }
    close(rnd_fd);
  }

  args[0] |= 0x10000U;

  struct sock_filter filter[] = {
    BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, nr)),
    BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_exit_group, 0, 9),

    BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, args[0])),
    BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, args[0], 0, 7),

    BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, args[1])),
    BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, args[1], 0, 5),

    BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, args[2])),
    BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, args[2], 0, 3),

    BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, args[3])),
    BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, args[3], 0, 1),

    BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_TRACE),
    BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
  };

  struct sock_fprog prog = {
    .len = (unsigned short)(sizeof(filter) / sizeof(filter[0])),
    .filter = filter,
  };

  if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &prog)) return;

  syscall(__NR_exit_group, args[0], args[1], args[2], args[3]);
}
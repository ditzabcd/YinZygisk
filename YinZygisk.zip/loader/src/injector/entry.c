#include <sys/stat.h>

#include "daemon.h"
#include "misc.h"
#include "hook.h"
#include "ptrace_clear.h"

__attribute__((visibility("default")))
void entry(void *addr, size_t size, int tango_flag) {
  (void)tango_flag;

  start_addr = addr;
  block_size = size;

  struct stat self_stat;
  if (stat("/data/adb/modules/yinzygisk/lib" LP_SELECT("", "64") "/libzygisk.so", &self_stat) != 0) {
    return;
  }

  self_dev = self_stat.st_dev;
  self_ino = self_stat.st_ino;

  hook_functions();

  struct kernel_version version = parse_kversion();
  if (version.major > 3 || (version.major == 3 && version.minor >= 8)) {
    perform_ptrace_message_clear();
  }

  if (!yinzygiskd_zygote_injected()) {
    return;
  }
}
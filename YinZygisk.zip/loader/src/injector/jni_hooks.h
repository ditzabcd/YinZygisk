#ifndef JNI_HOOKS_H
#define JNI_HOOKS_H

static void *nativeForkAndSpecialize_orig = NULL;
typedef jint (*nativeForkAndSpecialize_fn)(JNIEnv *, jclass, ...);

__attribute__((no_stack_protector)) static jint nativeForkAndSpecialize_l(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jintArray fds_to_close, jstring instruction_set, jstring app_data_dir) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeForkAndSpecialize_pre(&ctx);
  ((nativeForkAndSpecialize_fn)nativeForkAndSpecialize_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, fds_to_close, instruction_set, app_data_dir
  );
  yz_nativeForkAndSpecialize_post(&ctx);
  yz_cleanup(&ctx);
  return ctx.pid;
}

__attribute__((no_stack_protector)) static jint nativeForkAndSpecialize_o(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jintArray fds_to_close, jintArray fds_to_ignore, jstring instruction_set, jstring app_data_dir) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.fds_to_ignore = &fds_to_ignore;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeForkAndSpecialize_pre(&ctx);
  ((nativeForkAndSpecialize_fn)nativeForkAndSpecialize_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, fds_to_close, fds_to_ignore, instruction_set, app_data_dir
  );
  yz_nativeForkAndSpecialize_post(&ctx);
  yz_cleanup(&ctx);
  return ctx.pid;
}

__attribute__((no_stack_protector)) static jint nativeForkAndSpecialize_p(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jintArray fds_to_close, jintArray fds_to_ignore, jboolean is_child_zygote, jstring instruction_set, jstring app_data_dir) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.fds_to_ignore = &fds_to_ignore;
  args.is_child_zygote = &is_child_zygote;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeForkAndSpecialize_pre(&ctx);
  ((nativeForkAndSpecialize_fn)nativeForkAndSpecialize_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir
  );
  yz_nativeForkAndSpecialize_post(&ctx);
  yz_cleanup(&ctx);
  return ctx.pid;
}

__attribute__((no_stack_protector)) static jint nativeForkAndSpecialize_q_alt(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jintArray fds_to_close, jintArray fds_to_ignore, jboolean is_child_zygote, jstring instruction_set, jstring app_data_dir, jboolean is_top_app) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.fds_to_ignore = &fds_to_ignore;
  args.is_child_zygote = &is_child_zygote;
  args.is_top_app = &is_top_app;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeForkAndSpecialize_pre(&ctx);
  ((nativeForkAndSpecialize_fn)nativeForkAndSpecialize_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir, is_top_app
  );
  yz_nativeForkAndSpecialize_post(&ctx);
  yz_cleanup(&ctx);
  return ctx.pid;
}

__attribute__((no_stack_protector)) static jint nativeForkAndSpecialize_r(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jintArray fds_to_close, jintArray fds_to_ignore, jboolean is_child_zygote, jstring instruction_set, jstring app_data_dir, jboolean is_top_app, jobjectArray pkg_data_info_list, jobjectArray whitelisted_data_info_list, jboolean mount_data_dirs, jboolean mount_storage_dirs) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.fds_to_ignore = &fds_to_ignore;
  args.is_child_zygote = &is_child_zygote;
  args.is_top_app = &is_top_app;
  args.pkg_data_info_list = &pkg_data_info_list;
  args.whitelisted_data_info_list = &whitelisted_data_info_list;
  args.mount_data_dirs = &mount_data_dirs;
  args.mount_storage_dirs = &mount_storage_dirs;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeForkAndSpecialize_pre(&ctx);
  ((nativeForkAndSpecialize_fn)nativeForkAndSpecialize_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir, is_top_app, pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs
  );
  yz_nativeForkAndSpecialize_post(&ctx);
  yz_cleanup(&ctx);
  return ctx.pid;
}

__attribute__((no_stack_protector)) static jint nativeForkAndSpecialize_u(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jintArray fds_to_close, jintArray fds_to_ignore, jboolean is_child_zygote, jstring instruction_set, jstring app_data_dir, jboolean is_top_app, jobjectArray pkg_data_info_list, jobjectArray whitelisted_data_info_list, jboolean mount_data_dirs, jboolean mount_storage_dirs, jboolean mount_sysprop_overrides) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.fds_to_ignore = &fds_to_ignore;
  args.is_child_zygote = &is_child_zygote;
  args.is_top_app = &is_top_app;
  args.pkg_data_info_list = &pkg_data_info_list;
  args.whitelisted_data_info_list = &whitelisted_data_info_list;
  args.mount_data_dirs = &mount_data_dirs;
  args.mount_storage_dirs = &mount_storage_dirs;
  args.mount_sysprop_overrides = &mount_sysprop_overrides;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeForkAndSpecialize_pre(&ctx);
  ((nativeForkAndSpecialize_fn)nativeForkAndSpecialize_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir, is_top_app, pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs, mount_sysprop_overrides
  );
  yz_nativeForkAndSpecialize_post(&ctx);
  yz_cleanup(&ctx);
  return ctx.pid;
}

__attribute__((no_stack_protector)) static jint nativeForkAndSpecialize_c(JNIEnv *env, jclass clazz, jint uid, jint _0, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jintArray fds_to_close, jintArray fds_to_ignore, jboolean is_child_zygote, jstring instruction_set, jstring app_data_dir, jboolean _1, jboolean is_top_app, jobjectArray pkg_data_info_list, jobjectArray whitelisted_data_info_list, jboolean mount_data_dirs, jboolean mount_storage_dirs, jboolean mount_sysprop_overrides) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.fds_to_ignore = &fds_to_ignore;
  args.is_child_zygote = &is_child_zygote;
  args.is_top_app = &is_top_app;
  args.pkg_data_info_list = &pkg_data_info_list;
  args.whitelisted_data_info_list = &whitelisted_data_info_list;
  args.mount_data_dirs = &mount_data_dirs;
  args.mount_storage_dirs = &mount_storage_dirs;
  args.mount_sysprop_overrides = &mount_sysprop_overrides;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeForkAndSpecialize_pre(&ctx);
  ((nativeForkAndSpecialize_fn)nativeForkAndSpecialize_orig)(
    env, clazz, uid, _0, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir, _1, is_top_app, pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs, mount_sysprop_overrides
  );
  yz_nativeForkAndSpecialize_post(&ctx);
  yz_cleanup(&ctx);
  return ctx.pid;
}

static JNINativeMethod nativeForkAndSpecialize_methods[] = {
  {
    "nativeForkAndSpecialize",
    "(II[II[[IILjava/lang/String;Ljava/lang/String;[ILjava/lang/String;Ljava/lang/String;)I",
    (void *)&nativeForkAndSpecialize_l
  },
  {
    "nativeForkAndSpecialize",
    "(II[II[[IILjava/lang/String;Ljava/lang/String;[I[ILjava/lang/String;Ljava/lang/String;)I",
    (void *)&nativeForkAndSpecialize_o
  },
  {
    "nativeForkAndSpecialize",
    "(II[II[[IILjava/lang/String;Ljava/lang/String;[I[IZLjava/lang/String;Ljava/lang/String;)I",
    (void *)&nativeForkAndSpecialize_p
  },
  {
    "nativeForkAndSpecialize",
    "(II[II[[IILjava/lang/String;Ljava/lang/String;[I[IZLjava/lang/String;Ljava/lang/String;Z)I",
    (void *)&nativeForkAndSpecialize_q_alt
  },
  {
    "nativeForkAndSpecialize",
    "(II[II[[IILjava/lang/String;Ljava/lang/String;[I[IZLjava/lang/String;Ljava/lang/String;Z[Ljava/lang/String;[Ljava/lang/String;ZZ)I",
    (void *)&nativeForkAndSpecialize_r
  },
  {
    "nativeForkAndSpecialize",
    "(II[II[[IILjava/lang/String;Ljava/lang/String;[I[IZLjava/lang/String;Ljava/lang/String;Z[Ljava/lang/String;[Ljava/lang/String;ZZZ)I",
    (void *)&nativeForkAndSpecialize_u
  },
  {
    "nativeForkAndSpecialize",
    "(III[II[[IILjava/lang/String;Ljava/lang/String;[I[IZLjava/lang/String;Ljava/lang/String;ZZ[Ljava/lang/String;[Ljava/lang/String;ZZZ)I",
    (void *)&nativeForkAndSpecialize_c
  },
};

static void *nativeSpecializeAppProcess_orig = NULL;
typedef void (*nativeSpecializeAppProcess_fn)(JNIEnv *, jclass, ...);

__attribute__((no_stack_protector)) static void nativeSpecializeAppProcess_q(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jboolean is_child_zygote, jstring instruction_set, jstring app_data_dir) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.is_child_zygote = &is_child_zygote;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeSpecializeAppProcess_pre(&ctx);
  ((nativeSpecializeAppProcess_fn)nativeSpecializeAppProcess_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, is_child_zygote, instruction_set, app_data_dir
  );
  yz_nativeSpecializeAppProcess_post(&ctx);
  yz_cleanup(&ctx);
}

__attribute__((no_stack_protector)) static void nativeSpecializeAppProcess_q_alt(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jboolean is_child_zygote, jstring instruction_set, jstring app_data_dir, jboolean is_top_app) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.is_child_zygote = &is_child_zygote;
  args.is_top_app = &is_top_app;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeSpecializeAppProcess_pre(&ctx);
  ((nativeSpecializeAppProcess_fn)nativeSpecializeAppProcess_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, is_child_zygote, instruction_set, app_data_dir, is_top_app
  );
  yz_nativeSpecializeAppProcess_post(&ctx);
  yz_cleanup(&ctx);
}

__attribute__((no_stack_protector)) static void nativeSpecializeAppProcess_r(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jboolean is_child_zygote, jstring instruction_set, jstring app_data_dir, jboolean is_top_app, jobjectArray pkg_data_info_list, jobjectArray whitelisted_data_info_list, jboolean mount_data_dirs, jboolean mount_storage_dirs) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.is_child_zygote = &is_child_zygote;
  args.is_top_app = &is_top_app;
  args.pkg_data_info_list = &pkg_data_info_list;
  args.whitelisted_data_info_list = &whitelisted_data_info_list;
  args.mount_data_dirs = &mount_data_dirs;
  args.mount_storage_dirs = &mount_storage_dirs;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeSpecializeAppProcess_pre(&ctx);
  ((nativeSpecializeAppProcess_fn)nativeSpecializeAppProcess_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, is_child_zygote, instruction_set, app_data_dir, is_top_app, pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs
  );
  yz_nativeSpecializeAppProcess_post(&ctx);
  yz_cleanup(&ctx);
}

__attribute__((no_stack_protector)) static void nativeSpecializeAppProcess_u(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jboolean is_child_zygote, jstring instruction_set, jstring app_data_dir, jboolean is_top_app, jobjectArray pkg_data_info_list, jobjectArray whitelisted_data_info_list, jboolean mount_data_dirs, jboolean mount_storage_dirs, jboolean mount_sysprop_overrides) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.is_child_zygote = &is_child_zygote;
  args.is_top_app = &is_top_app;
  args.pkg_data_info_list = &pkg_data_info_list;
  args.whitelisted_data_info_list = &whitelisted_data_info_list;
  args.mount_data_dirs = &mount_data_dirs;
  args.mount_storage_dirs = &mount_storage_dirs;
  args.mount_sysprop_overrides = &mount_sysprop_overrides;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeSpecializeAppProcess_pre(&ctx);
  ((nativeSpecializeAppProcess_fn)nativeSpecializeAppProcess_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, is_child_zygote, instruction_set, app_data_dir, is_top_app, pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs, mount_sysprop_overrides
  );
  yz_nativeSpecializeAppProcess_post(&ctx);
  yz_cleanup(&ctx);
}

__attribute__((no_stack_protector)) static void nativeSpecializeAppProcess_c(JNIEnv *env, jclass clazz, jint uid, jint _15, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jint mount_external, jstring se_info, jstring nice_name, jboolean is_child_zygote, jstring instruction_set, jstring app_data_dir, jboolean is_top_app, jobjectArray pkg_data_info_list, jobjectArray whitelisted_data_info_list, jboolean mount_data_dirs, jboolean mount_storage_dirs, jboolean mount_sysprop_overrides) {
  struct app_specialize_args_v5 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, .nice_name = &nice_name, .instruction_set = &instruction_set, .app_data_dir = &app_data_dir };
  args.is_child_zygote = &is_child_zygote;
  args.is_top_app = &is_top_app;
  args.pkg_data_info_list = &pkg_data_info_list;
  args.whitelisted_data_info_list = &whitelisted_data_info_list;
  args.mount_data_dirs = &mount_data_dirs;
  args.mount_storage_dirs = &mount_storage_dirs;
  args.mount_sysprop_overrides = &mount_sysprop_overrides;
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeSpecializeAppProcess_pre(&ctx);
  ((nativeSpecializeAppProcess_fn)nativeSpecializeAppProcess_orig)(
    env, clazz, uid, _15, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name, is_child_zygote, instruction_set, app_data_dir, is_top_app, pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs, mount_sysprop_overrides
  );
  yz_nativeSpecializeAppProcess_post(&ctx);
  yz_cleanup(&ctx);
}

static JNINativeMethod nativeSpecializeAppProcess_methods[] = {
  {
    "nativeSpecializeAppProcess",
    "(II[II[[IILjava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)V",
    (void *)&nativeSpecializeAppProcess_q
  },
  {
    "nativeSpecializeAppProcess",
    "(II[II[[IILjava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Z)V",
    (void *)&nativeSpecializeAppProcess_q_alt
  },
  {
    "nativeSpecializeAppProcess",
    "(II[II[[IILjava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Z[Ljava/lang/String;[Ljava/lang/String;ZZ)V",
    (void *)&nativeSpecializeAppProcess_r
  },
  {
    "nativeSpecializeAppProcess",
    "(II[II[[IILjava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Z[Ljava/lang/String;[Ljava/lang/String;ZZZ)V",
    (void *)&nativeSpecializeAppProcess_u
  },
  {
    "nativeSpecializeAppProcess",
    "(III[II[[IILjava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Z[Ljava/lang/String;[Ljava/lang/String;ZZZ)V",
    (void *)&nativeSpecializeAppProcess_c
  },
};

static void *nativeForkSystemServer_orig = NULL;
typedef jint (*nativeForkSystemServer_fn)(JNIEnv *, jclass, ...);

__attribute__((no_stack_protector)) static jint nativeForkSystemServer_l(JNIEnv *env, jclass clazz, jint uid, jint gid, jintArray gids, jint runtime_flags, jobjectArray rlimits, jlong permitted_capabilities, jlong effective_capabilities) {
  struct server_specialize_args_v1 args = { .uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, .permitted_capabilities = &permitted_capabilities, .effective_capabilities = &effective_capabilities };
  struct zygisk_context ctx;
  yz_init(&ctx, env, &args);
  yz_nativeForkSystemServer_pre(&ctx);
  ((nativeForkSystemServer_fn)nativeForkSystemServer_orig)(
    env, clazz, uid, gid, gids, runtime_flags, rlimits, permitted_capabilities, effective_capabilities
  );
  yz_nativeForkSystemServer_post(&ctx);
  yz_cleanup(&ctx);
  return ctx.pid;
}

static JNINativeMethod nativeForkSystemServer_methods[] = {
  {
    "nativeForkSystemServer",
    "(II[II[[IJJ)I",
    (void *)&nativeForkSystemServer_l
  },
};

static inline void resolve_and_push_hook(
    JNIEnv *env, const char *clz,
    JNINativeMethod *methods, size_t count,
    void **orig_out, JNINativeMethod *hooks, int *hooks_count) {
  hook_jni_methods(env, clz, methods, (int)count);
  for (size_t i = 0; i < count; i++) {
    if (!methods[i].fnPtr) continue;
    *orig_out = methods[i].fnPtr;
    hooks[(*hooks_count)++] = methods[i];
    break;
  }
}

static void do_hook_zygote(JNIEnv *env) {
  const char *clz = "com/android/internal/os/Zygote";

  JNINativeMethod hooks[3];
  int hooks_count = 0;

  resolve_and_push_hook(
      env, clz, nativeForkAndSpecialize_methods,
      sizeof(nativeForkAndSpecialize_methods) / sizeof(nativeForkAndSpecialize_methods[0]),
      &nativeForkAndSpecialize_orig, hooks, &hooks_count);

  resolve_and_push_hook(
      env, clz, nativeSpecializeAppProcess_methods,
      sizeof(nativeSpecializeAppProcess_methods) / sizeof(nativeSpecializeAppProcess_methods[0]),
      &nativeSpecializeAppProcess_orig, hooks, &hooks_count);

  resolve_and_push_hook(
      env, clz, nativeForkSystemServer_methods,
      sizeof(nativeForkSystemServer_methods) / sizeof(nativeForkSystemServer_methods[0]),
      &nativeForkSystemServer_orig, hooks, &hooks_count);

  jni_hook_list_add(clz, hooks, hooks_count);
}

#endif /* JNI_HOOKS_H */
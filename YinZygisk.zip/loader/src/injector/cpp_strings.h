#ifndef CPP_STRINGS_H
#define CPP_STRINGS_H

#include <stdbool.h>
#include <stddef.h>

const char *read_std_string(const void *std_string_ptr);
size_t get_std_string_length(const void *std_string_ptr);

#endif /* CPP_STRINGS_H */
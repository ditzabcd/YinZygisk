#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include <dlfcn.h>
#include <link.h>
#include <regex.h>

#include <dirent.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include <csoloader.h>
#include <plti.h>

#include "daemon.h"
#include "hook.h"
#include "misc.h"
#include "module.h"

#include "art_method.h"
#include "cpp_strings.h"
#include "registers.h"

void *start_addr = NULL;
size_t block_size = 0;

dev_t self_dev;
ino_t self_ino;

enum {
  POST_SPECIALIZE,
  APP_FORK_AND_SPECIALIZE,
  APP_SPECIALIZE,
  SERVER_FORK_AND_SPECIALIZE,
  DO_REVERT_UNMOUNT,
  SKIP_FD_SANITIZATION,

  FLAG_MAX
};

#define MAX_FD_SIZE 1024
#define MAX_REGISTER_INFO 64
#define MAX_IGNORE_INFO 64
#define MAX_EXEMPTED_FDS 128

struct register_info {
  regex_t regex;
  char *symbol;
  void *callback;
  void **backup;
};

struct ignore_info {
  regex_t regex;
  char *symbol;
};

struct zygisk_context {
  JNIEnv *env;
  union {
    void *ptr;
    struct app_specialize_args_v5 *app;
    struct server_specialize_args_v1 *server;
  } args;

  const char *process;

  int pid;
  uint32_t flags;
  uint32_t info_flags;
  uint8_t allowed_fds[MAX_FD_SIZE];
  int exempted_fds[MAX_EXEMPTED_FDS];
  size_t exempted_fds_count;

  pthread_mutex_t hook_info_lock;
  struct register_info register_info[MAX_REGISTER_INFO];
  size_t register_info_count;
  struct ignore_info ignore_info[MAX_IGNORE_INFO];
  size_t ignore_info_count;
};

static struct zygisk_context *g_ctx = NULL;

#define FLAG_SET(ctx, f) ((ctx)->flags |= (1u << (f)))
#define FLAG_GET(ctx, f) (((ctx)->flags & (1u << (f))) != 0)

#define DCL_PRE_POST(name)                                   \
  static void yz_## name ##_pre(struct zygisk_context *ctx); \
  static void yz_## name ##_post(struct zygisk_context *ctx)

static void yz_init(struct zygisk_context *ctx, JNIEnv *env, void *args);
static void yz_cleanup(struct zygisk_context *ctx);

DCL_PRE_POST(run_modules);
DCL_PRE_POST(fork);
DCL_PRE_POST(app_specialize);
DCL_PRE_POST(nativeForkAndSpecialize);
DCL_PRE_POST(nativeSpecializeAppProcess);
DCL_PRE_POST(nativeForkSystemServer);

#undef DCL_PRE_POST

static inline bool is_zygote_child(struct zygisk_context *ctx) {
  return ctx->pid <= 0;
}

struct plt_hook_entry {
  const char *lib_path;
  const char *symbol;
  void *new_func;
  void **backup;
};

struct jni_hook_entry {
  char *class_name;
  JNINativeMethod *methods;
  size_t methods_count;
};

struct plti plti_ctx;

static struct plt_hook_entry *plt_hook_list = NULL;
static size_t plt_hook_list_count = 0;

static struct jni_hook_entry *jni_hook_list = NULL;
static size_t jni_hook_list_count = 0;

struct yinzygisk_module *zygisk_modules = NULL;
size_t zygisk_module_length = 0;

static bool should_unmap_zygisk = false;
static bool enable_unloader = false;
static bool jni_hook_initialized = false;

static bool plt_hook_list_add(const char *lib_path, const char *symbol, void *new_func, void **backup) {
  struct plt_hook_entry *new_list = realloc(plt_hook_list, (plt_hook_list_count + 1) * sizeof(struct plt_hook_entry));
  if (!new_list) return false;

  plt_hook_list = new_list;
  plt_hook_list[plt_hook_list_count].lib_path = lib_path;
  plt_hook_list[plt_hook_list_count].symbol = symbol;
  plt_hook_list[plt_hook_list_count].new_func = new_func;
  plt_hook_list[plt_hook_list_count].backup = backup;
  plt_hook_list_count++;

  return true;
}

static void jni_hook_list_add(const char *class_name, JNINativeMethod *methods, size_t count) {
  struct jni_hook_entry *new_list = realloc(jni_hook_list, (jni_hook_list_count + 1) * sizeof(struct jni_hook_entry));
  if (!new_list) return;

  jni_hook_list = new_list;

  char *cls_copy = strdup(class_name);
  if (!cls_copy) return;

  JNINativeMethod *methods_copy = malloc(count * sizeof(JNINativeMethod));
  if (!methods_copy) {
    free(cls_copy);
    return;
  }

  memcpy(methods_copy, methods, count * sizeof(JNINativeMethod));

  jni_hook_list[jni_hook_list_count].class_name = cls_copy;
  jni_hook_list[jni_hook_list_count].methods = methods_copy;
  jni_hook_list[jni_hook_list_count].methods_count = count;
  jni_hook_list_count++;
}

static bool update_mnt_ns(enum mount_namespace_state mns_state, bool dry_run) {
  char ns_path[PATH_MAX];
  if (!yinzygiskd_update_mns(mns_state, ns_path, sizeof(ns_path))) {
    return false;
  }

  if (dry_run) return true;

  int updated_ns = open(ns_path, O_RDONLY | O_CLOEXEC);
  if (updated_ns == -1) return false;

  bool ok = (setns(updated_ns, CLONE_NEWNS) == 0);
  close(updated_ns);

  return ok;
}

#define DCL_HOOK_FUNC(ret, func, ...) \
  ret (*old_##func)(__VA_ARGS__);     \
  ret new_##func(__VA_ARGS__)

DCL_HOOK_FUNC(int, fork) {
  return (g_ctx && g_ctx->pid >= 0) ? g_ctx->pid : old_fork();
}

#ifdef __LP64__
  #define STD_STRING_SIZE 24
#else
  #define STD_STRING_SIZE 12
#endif

struct FileDescriptorInfo {
  const int fd;
  const struct stat stat;
  char file_path_storage[STD_STRING_SIZE];
  const int open_flags;
  const int fd_flags;
  const int fs_flags;
  const off_t offset;
  const bool is_sock;
};

#define BOOT_IMAGE_MEMFD "/memfd:/boot-image-methods.art"

DCL_HOOK_FUNC(void, _ZNK18FileDescriptorInfo14ReopenOrDetach, void *_this, void *fail_fn) {
  const bool is_sock = *(const bool *)((uintptr_t)_this + offsetof(struct FileDescriptorInfo, is_sock));
  if (is_sock) goto bypass_fd_check;

  const void *file_path_std_string = (const void *)((uintptr_t)_this + offsetof(struct FileDescriptorInfo, file_path_storage));
  const char *file_path = read_std_string(file_path_std_string);
  if (!file_path) goto bypass_fd_check;

  if (strncmp(file_path, BOOT_IMAGE_MEMFD, sizeof(BOOT_IMAGE_MEMFD) - 1) == 0) {
    goto bypass_fd_check;
  }

  if (access(file_path, F_OK) == -1) {
    const int fd = *(const int *)((uintptr_t)_this + offsetof(struct FileDescriptorInfo, fd));
    close(fd);
    return;
  }

bypass_fd_check:
  old__ZNK18FileDescriptorInfo14ReopenOrDetach(_this, fail_fn);
}

static void unhook_functions(void);

DCL_HOOK_FUNC(int, pthread_attr_setstacksize, void *target, size_t size) {
  int res = old_pthread_attr_setstacksize((pthread_attr_t *)target, size);

  if (!enable_unloader || gettid() != getpid()) return res;

  if (should_unmap_zygisk) {
    unhook_functions();
    csoloader_deinit();

    free(zygisk_modules);
    zygisk_modules = NULL;
    plti_deinit(&plti_ctx);

    if (!should_unmap_zygisk) {
      enable_unloader = false;
      return res;
    }

    [[clang::musttail]] return munmap(start_addr, block_size);
  }

  return res;
}

static void initialize_jni_hook(void);

DCL_HOOK_FUNC(char *, strdup, const char *str) {
  if (!jni_hook_initialized && str && strcmp(str, "com.android.internal.os.ZygoteInit") == 0) {
    jni_hook_initialized = true;
    initialize_jni_hook();
  }

  return old_strdup(str);
}

static void hook_unloader(void);

DCL_HOOK_FUNC(int, property_get, const char *key, char *value, const char *default_value) {
  hook_unloader();
  return old_property_get(key, value, default_value);
}

#undef DCL_HOOK_FUNC

static bool can_hook_jni = false;
static jint MODIFIER_NATIVE = 0;
static jmethodID member_getModifiers = NULL;

void hook_jni_methods(JNIEnv *env, const char *clz, JNINativeMethod *methods, int numMethods) {
  if (!can_hook_jni) return;

  jclass clazz = (*env)->FindClass(env, clz);
  if (!clazz) {
    (*env)->ExceptionClear(env);
    memset(methods, 0, (size_t)numMethods * sizeof(JNINativeMethod));
    return;
  }

  JNINativeMethod hooks[32];
  size_t hooks_count = 0;

  for (int i = 0; i < numMethods; i++) {
    bool is_static = false;
    JNINativeMethod *nm = &methods[i];

    jmethodID mid = (*env)->GetMethodID(env, clazz, nm->name, nm->signature);
    if (!mid) {
      (*env)->ExceptionClear(env);
      mid = (*env)->GetStaticMethodID(env, clazz, nm->name, nm->signature);
      is_static = true;
    }

    if (!mid) {
      (*env)->ExceptionClear(env);
      nm->fnPtr = NULL;
      continue;
    }

    jobject method = (*env)->ToReflectedMethod(env, clazz, mid, is_static);
    jint modifier = (*env)->CallIntMethod(env, method, member_getModifiers);
    if ((*env)->ExceptionCheck(env) || (modifier & MODIFIER_NATIVE) == 0) {
      (*env)->ExceptionClear(env);
      nm->fnPtr = NULL;
      (*env)->DeleteLocalRef(env, method);
      continue;
    }

    void *art_method = amethod_from_reflected_method(env, method);
    if (hooks_count < 32) {
      hooks[hooks_count++] = *nm;
    }

    nm->fnPtr = amethod_get_data((uintptr_t)art_method);
    (*env)->DeleteLocalRef(env, method);
  }

  if (hooks_count > 0) {
    (*env)->RegisterNatives(env, clazz, hooks, (jint)hooks_count);
  }

  (*env)->DeleteLocalRef(env, clazz);
}

#include "jni_hooks.h"

struct dl_collect_ctx {
  struct maps_info *maps;
  size_t capacity;
};

static bool maps_push_entry(struct dl_collect_ctx *ctx, struct map_entry entry) {
  if (!entry.path) return false;

  if (ctx->maps->length >= ctx->capacity) {
    size_t new_cap = ctx->capacity ? (ctx->capacity * 2) : 256;
    struct map_entry *new_maps = realloc(ctx->maps->maps, new_cap * sizeof(struct map_entry));
    if (!new_maps) {
      free(entry.path);
      return false;
    }
    ctx->maps->maps = new_maps;
    ctx->capacity = new_cap;
  }

  ctx->maps->maps[ctx->maps->length++] = entry;
  return true;
}

static int collect_dl_libs(struct dl_phdr_info *info, size_t size, void *data) {
  (void)size;

  if (!info->dlpi_name || info->dlpi_name[0] == '\0') return 0;

  struct dl_collect_ctx *ctx = (struct dl_collect_ctx *)data;

  for (ElfW(Half) i = 0; i < info->dlpi_phnum; i++) {
    const ElfW(Phdr) *phdr = &info->dlpi_phdr[i];
    if (phdr->p_type != PT_LOAD || phdr->p_offset != 0 || !(phdr->p_flags & PF_R)) continue;

    struct stat st;
    dev_t dev = 0;
    ino_t ino = 0;
    const char *zip = strstr(info->dlpi_name, "!/");

    if (zip) {
      char *container = strndup(info->dlpi_name, (size_t)(zip - info->dlpi_name));
      if (container) {
        if (stat(container, &st) == 0) {
          dev = st.st_dev;
          ino = st.st_ino;
        }
        free(container);
      }
    } else if (stat(info->dlpi_name, &st) == 0) {
      dev = st.st_dev;
      ino = st.st_ino;
    }

    maps_push_entry(ctx, (struct map_entry) {
      .start = (uintptr_t)info->dlpi_addr + phdr->p_vaddr,
      .end = (uintptr_t)info->dlpi_addr + phdr->p_vaddr + phdr->p_memsz,
      .offset = 0,
      .dev = dev,
      .inode = ino,
      .perms = PROT_READ,
      .is_private = true,
      .path = strdup(info->dlpi_name)
    });

    break;
  }

  return 0;
}

static struct maps_info *get_loaded_libraries(void) {
  struct maps_info *maps = calloc(1, sizeof(struct maps_info));
  if (!maps) return NULL;

  struct dl_collect_ctx ctx = {
    .maps = maps,
    .capacity = 256
  };

  maps->maps = malloc(ctx.capacity * sizeof(struct map_entry));
  if (!maps->maps) {
    free(maps);
    return NULL;
  }

  dl_iterate_phdr(collect_dl_libs, &ctx);

  if (start_addr && block_size > 0 && self_dev) {
    if (!maps_push_entry(&ctx, (struct map_entry) {
      .start = (uintptr_t)start_addr,
      .end = (uintptr_t)start_addr + block_size,
      .offset = 0,
      .dev = self_dev,
      .inode = self_ino,
      .perms = PROT_READ,
      .is_private = true,
      .path = strdup("/data/adb/modules/yinzygisk/lib" LP_SELECT("", "64") "/libzygisk.so")
    })) {
      free_maps(maps);
      return NULL;
    }
  }

  for (size_t i = 0; i < zygisk_module_length; i++) {
    struct yinzygisk_module *map = &zygisk_modules[i];
    if (!map->lib.lib_path || !map->lib.img || !map->lib.img->header) continue;

    maps_push_entry(&ctx, (struct map_entry) {
      .start = (uintptr_t)map->lib.img->header,
      .end = (uintptr_t)map->lib.img->header + map->lib.img->size,
      .offset = 0,
      .dev = map->dev,
      .inode = map->ino,
      .perms = PROT_READ,
      .is_private = true,
      .path = strdup(map->lib.lib_path)
    });
  }

  if (maps->length == 0) {
    free_maps(maps);
    return NULL;
  }

  return maps;
}

static void initialize_jni_hook(void) {
  jint (*get_created_java_vms)(JavaVM **, jsize, jsize *) =
      (jint (*)(JavaVM **, jsize, jsize *))dlsym(RTLD_DEFAULT, "JNI_GetCreatedJavaVMs");

  if (!get_created_java_vms) {
    struct maps_info *maps = get_loaded_libraries();
    if (!maps) return;

    for (size_t i = 0; i < maps->length; i++) {
      struct map_entry *map = &maps->maps[i];
      if (!map->path || !strstr(map->path, "/libnativehelper.so")) continue;

      void *handle = dlopen(map->path, RTLD_LAZY | RTLD_NOLOAD);
      if (!handle) handle = dlopen(map->path, RTLD_LAZY);
      if (!handle) break;

      get_created_java_vms = (jint (*)(JavaVM **, jsize, jsize *))dlsym(handle, "JNI_GetCreatedJavaVMs");
      dlclose(handle);
      break;
    }

    free_maps(maps);
    if (!get_created_java_vms) return;
  }

  JavaVM *vm = NULL;
  jsize num = 0;
  if (get_created_java_vms(&vm, 1, &num) != JNI_OK || !vm) return;

  JNIEnv *env = NULL;
  if ((*vm)->GetEnv(vm, (void **)&env, JNI_VERSION_1_6) != JNI_OK || !env) return;

  jclass classMember = (*env)->FindClass(env, "java/lang/reflect/Member");
  if (classMember) {
    member_getModifiers = (*env)->GetMethodID(env, classMember, "getModifiers", "()I");
    (*env)->DeleteLocalRef(env, classMember);
  }

  jclass classModifier = (*env)->FindClass(env, "java/lang/reflect/Modifier");
  if (classModifier) {
    jfieldID fieldId = (*env)->GetStaticFieldID(env, classModifier, "NATIVE", "I");
    if (fieldId) MODIFIER_NATIVE = (*env)->GetStaticIntField(env, classModifier, fieldId);
    (*env)->DeleteLocalRef(env, classModifier);
  }

  if (!member_getModifiers || MODIFIER_NATIVE == 0) return;
  if (!amethod_init(env)) return;

  can_hook_jni = true;
  do_hook_zygote(env);
  registers_clear();
}

static void api_plt_hook_register(const char *regex, const char *symbol, void *fn, void **backup) {
  if (!g_ctx || !regex || !symbol || !fn || g_ctx->register_info_count >= MAX_REGISTER_INFO) return;

  regex_t re;
  if (regcomp(&re, regex, REG_NOSUB) != 0) return;

  pthread_mutex_lock(&g_ctx->hook_info_lock);

  char *sym_copy = strdup(symbol);
  if (!sym_copy) {
    regfree(&re);
    pthread_mutex_unlock(&g_ctx->hook_info_lock);
    return;
  }

  g_ctx->register_info[g_ctx->register_info_count].regex = re;
  g_ctx->register_info[g_ctx->register_info_count].symbol = sym_copy;
  g_ctx->register_info[g_ctx->register_info_count].callback = fn;
  g_ctx->register_info[g_ctx->register_info_count].backup = backup;
  g_ctx->register_info_count++;

  pthread_mutex_unlock(&g_ctx->hook_info_lock);
}

static void api_plt_hook_exclude(const char *regex, const char *symbol) {
  if (!g_ctx || !regex || g_ctx->ignore_info_count >= MAX_IGNORE_INFO) return;

  regex_t re;
  if (regcomp(&re, regex, REG_NOSUB) != 0) return;

  pthread_mutex_lock(&g_ctx->hook_info_lock);

  g_ctx->ignore_info[g_ctx->ignore_info_count].regex = re;
  g_ctx->ignore_info[g_ctx->ignore_info_count].symbol = symbol ? strdup(symbol) : NULL;
  g_ctx->ignore_info_count++;

  pthread_mutex_unlock(&g_ctx->hook_info_lock);
}

static bool api_plt_hook_commit(void) {
  if (!g_ctx || g_ctx->register_info_count == 0) return false;

  pthread_mutex_lock(&g_ctx->hook_info_lock);

  struct maps_info *map_infos = get_loaded_libraries();
  if (!map_infos) {
    pthread_mutex_unlock(&g_ctx->hook_info_lock);
    return false;
  }

  bool any_failed = false;
  for (size_t i = 0; i < map_infos->length; i++) {
    struct map_entry *map = &map_infos->maps[i];
    if (map->offset != 0 || !map->is_private || !(map->perms & PROT_READ)) continue;

    for (size_t r = 0; r < g_ctx->register_info_count; r++) {
      struct register_info *reg = &g_ctx->register_info[r];
      if (regexec(&reg->regex, map->path, 0, NULL, 0) != 0) continue;

      bool ignored = false;
      for (size_t ig = 0; ig < g_ctx->ignore_info_count; ig++) {
        struct ignore_info *ign = &g_ctx->ignore_info[ig];
        if (regexec(&ign->regex, map->path, 0, NULL, 0) != 0) continue;
        if (ign->symbol && strcmp(ign->symbol, reg->symbol) != 0) continue;

        ignored = true;
        break;
      }

      if (!ignored && !plti_add_hook(&plti_ctx, map->path, reg->symbol, reg->callback, reg->backup)) {
        any_failed = true;
      }
    }
  }

  free_maps(map_infos);

  for (size_t i = 0; i < g_ctx->register_info_count; i++) {
    regfree(&g_ctx->register_info[i].regex);
    free(g_ctx->register_info[i].symbol);
  }
  g_ctx->register_info_count = 0;

  for (size_t i = 0; i < g_ctx->ignore_info_count; i++) {
    regfree(&g_ctx->ignore_info[i].regex);
    free(g_ctx->ignore_info[i].symbol);
  }
  g_ctx->ignore_info_count = 0;

  pthread_mutex_unlock(&g_ctx->hook_info_lock);

  return !any_failed;
}

static void api_plt_hook_register_v4(dev_t dev, ino_t inode, const char *symbol, void *fn, void **backup) {
  if (!g_ctx || !symbol || !fn) return;

  struct maps_info *maps = get_loaded_libraries();
  if (!maps) return;

  uintptr_t lib_start = 0;
  const char *lib_path = NULL;
  for (size_t i = 0; i < maps->length; i++) {
    struct map_entry *entry = &maps->maps[i];
    if (entry->dev != dev || entry->inode != inode) continue;

    lib_start = entry->start;
    lib_path = entry->path;
    break;
  }

  if (!lib_path) {
    free_maps(maps);
    return;
  }

  char *lib_path_copy = strdup(lib_path);
  free_maps(maps);
  if (!lib_path_copy) return;

  if (!plti_add_manual_lib(&plti_ctx, lib_path_copy, lib_start)) {
    free(lib_path_copy);
    return;
  }

  char *symbol_copy = strdup(symbol);
  if (!symbol_copy) {
    free(lib_path_copy);
    return;
  }

  if (!plt_hook_list_add(lib_path_copy, symbol_copy, fn, backup)) {
    free(lib_path_copy);
    free(symbol_copy);
  }
}

static void api_exempt_fd(int fd) {
  if (!g_ctx) return;
  if (FLAG_GET(g_ctx, POST_SPECIALIZE) || FLAG_GET(g_ctx, SKIP_FD_SANITIZATION)) return;
  if (!FLAG_GET(g_ctx, APP_FORK_AND_SPECIALIZE)) return;
  if (g_ctx->exempted_fds_count >= MAX_EXEMPTED_FDS) return;

  g_ctx->exempted_fds[g_ctx->exempted_fds_count++] = fd;
}

static bool api_plt_hook_commit_v4(void) {
  if (!g_ctx) return false;

  bool any_failed = false;
  for (size_t i = 0; i < plt_hook_list_count; i++) {
    struct plt_hook_entry *entry = &plt_hook_list[i];
    if (!plti_add_hook(&plti_ctx, entry->lib_path, entry->symbol, entry->new_func, entry->backup)) {
      any_failed = true;
    }
  }

  if (plt_hook_list) {
    for (size_t i = 0; i < plt_hook_list_count; i++) {
      free((void *)plt_hook_list[i].lib_path);
      free((void *)plt_hook_list[i].symbol);
    }
    free(plt_hook_list);
    plt_hook_list = NULL;
    plt_hook_list_count = 0;
  }

  return !any_failed;
}

#define YZID_MAGIC ('Y' + 'Z' + 'I' + 'D')
#define ENCODE_ID(id) ((void *)((size_t)(id) + YZID_MAGIC))
#define DECODE_ID(ptr) ((size_t)(ptr) - YZID_MAGIC)

static int api_connect_companion(void *id) {
  if (!g_ctx) return -1;
  if ((size_t)id < YZID_MAGIC || (size_t)id >= YZID_MAGIC + zygisk_module_length) return -1;

  return yinzygiskd_connect_companion(DECODE_ID(id));
}

static void api_set_option(void *id, enum yinzygisk_options opt) {
  if (!g_ctx) return;
  if ((size_t)id < YZID_MAGIC || (size_t)id >= YZID_MAGIC + zygisk_module_length) return;

  switch (opt) {
    case FORCE_DENYLIST_UNMOUNT:
      FLAG_SET(g_ctx, DO_REVERT_UNMOUNT);
      break;
    case DLCLOSE_MODULE_LIBRARY:
      zygisk_modules[DECODE_ID(id)].unload = true;
      break;
  }
}

static int api_get_module_dir(void *id) {
  if (!g_ctx) return -1;
  if ((size_t)id < YZID_MAGIC || (size_t)id >= YZID_MAGIC + zygisk_module_length) return -1;

  return yinzygiskd_get_module_dir(DECODE_ID(id));
}

static uint32_t api_get_flags(void) {
  if (!g_ctx) return 0;
  return (g_ctx->info_flags & ~PRIVATE_MASK);
}

bool yinzygisk_module_register(struct yinzygisk_api *api, struct yinzygisk_abi const *target_module) {
  if (!g_ctx || !api || !target_module || target_module->api_version > YINZYGISK_API_VERSION) return false;

  struct yinzygisk_module *m = &zygisk_modules[DECODE_ID(api->impl)];
  m->abi = *target_module;
  m->api = *api;

  api->hook_jni_native_methods = hook_jni_methods;
  if (target_module->api_version >= 4) {
    api->plt_hook_register_v4 = api_plt_hook_register_v4;
    api->exempt_fd = api_exempt_fd;
    api->plt_hook_commit = api_plt_hook_commit_v4;
  } else {
    api->plt_hook_register = api_plt_hook_register;
    api->plt_hook_exclude = api_plt_hook_exclude;
    api->plt_hook_commit = api_plt_hook_commit;
  }

  api->connect_companion = api_connect_companion;
  api->set_option = api_set_option;

  if (target_module->api_version >= 2) {
    api->get_module_dir = api_get_module_dir;
    api->get_flags = api_get_flags;
  }

  return true;
}

static int sigmask(int how, int signum) {
  sigset_t set;
  sigemptyset(&set);
  sigaddset(&set, signum);
  return sigprocmask(how, &set, NULL);
}

static bool load_modules_only(void);

static void yz_fork_pre(struct zygisk_context *ctx) {
  sigmask(SIG_BLOCK, SIGCHLD);
  ctx->pid = old_fork();
  if (ctx->pid != 0 || FLAG_GET(ctx, SKIP_FD_SANITIZATION)) return;

  DIR *dir = opendir("/proc/self/fd");
  if (!dir) return;

  struct dirent *entry;
  while ((entry = readdir(dir))) {
    int fd = parse_int(entry->d_name);
    if (fd == -1) continue;

    if (fd >= MAX_FD_SIZE) {
      close(fd);
      continue;
    }

    ctx->allowed_fds[fd] = 1;
  }

  int dfd = dirfd(dir);
  if (dfd >= 0 && dfd < MAX_FD_SIZE) ctx->allowed_fds[dfd] = 0;

  closedir(dir);
}

static void mark_fds_allowed(struct zygisk_context *ctx, JNIEnv *env, jintArray fdsArray) {
  if (!fdsArray) return;

  jint *arr = (*env)->GetIntArrayElements(env, fdsArray, NULL);
  jint len = (*env)->GetArrayLength(env, fdsArray);

  for (jint i = 0; i < len; ++i) {
    int fd = arr[i];
    if (fd >= 0 && fd < MAX_FD_SIZE) ctx->allowed_fds[fd] = 1;
  }

  (*env)->ReleaseIntArrayElements(env, fdsArray, arr, JNI_ABORT);
}

static void yz_sanitize_fds(struct zygisk_context *ctx) {
  if (FLAG_GET(ctx, SKIP_FD_SANITIZATION)) return;

  if (FLAG_GET(ctx, APP_FORK_AND_SPECIALIZE)) {
    jintArray fdsToIgnore = ctx->args.app->fds_to_ignore ? *ctx->args.app->fds_to_ignore : NULL;
    mark_fds_allowed(ctx, ctx->env, fdsToIgnore);

    if (ctx->exempted_fds_count > 0) {
      jint len = fdsToIgnore ? (*ctx->env)->GetArrayLength(ctx->env, fdsToIgnore) : 0;
      jintArray newArray = (*ctx->env)->NewIntArray(ctx->env, (jsize)(len + ctx->exempted_fds_count));
      if (newArray) {
        if (fdsToIgnore && len > 0) {
          jint *arr = (*ctx->env)->GetIntArrayElements(ctx->env, fdsToIgnore, NULL);
          (*ctx->env)->SetIntArrayRegion(ctx->env, newArray, 0, len, arr);
          (*ctx->env)->ReleaseIntArrayElements(ctx->env, fdsToIgnore, arr, JNI_ABORT);
          (*ctx->env)->DeleteLocalRef(ctx->env, fdsToIgnore);
        }

        (*ctx->env)->SetIntArrayRegion(ctx->env, newArray, len, (jsize)ctx->exempted_fds_count, ctx->exempted_fds);
        for (size_t i = 0; i < ctx->exempted_fds_count; i++) {
          int fd = ctx->exempted_fds[i];
          if (fd >= 0 && fd < MAX_FD_SIZE) ctx->allowed_fds[fd] = 1;
        }

        *ctx->args.app->fds_to_ignore = newArray;
        FLAG_SET(ctx, SKIP_FD_SANITIZATION);
      }
    }
  }

  if (ctx->pid != 0) return;

  DIR *dir = opendir("/proc/self/fd");
  if (!dir) return;

  int dfd = dirfd(dir);
  struct dirent *entry;
  while ((entry = readdir(dir))) {
    int fd = parse_int(entry->d_name);
    if (fd < 0 || fd >= MAX_FD_SIZE || fd == dfd || ctx->allowed_fds[fd]) continue;

    close(fd);
  }

  closedir(dir);
}

static void yz_fork_post(struct zygisk_context *ctx __attribute__((unused))) {
  sigmask(SIG_UNBLOCK, SIGCHLD);
  g_ctx = NULL;
}

static bool load_modules_only(void) {
  struct zygisk_modules ms;
  if (!yinzygiskd_read_modules(&ms)) return false;

  if (ms.modules_count == 0) {
    free_modules(&ms);
    return true;
  }

  zygisk_modules = (struct yinzygisk_module *)malloc(ms.modules_count * sizeof(struct yinzygisk_module));
  if (!zygisk_modules) {
    free_modules(&ms);
    return false;
  }

  for (size_t i = 0; i < ms.modules_count; i++) {
    const char *lib_path = ms.modules[i];

    if (!csoloader_load(&zygisk_modules[zygisk_module_length].lib, lib_path)) {
      yinzygiskd_remove_module(i);
      continue;
    }

    struct stat st;
    if (stat(lib_path, &st) != 0) {
      csoloader_unload(&zygisk_modules[zygisk_module_length].lib);
      yinzygiskd_remove_module(i);
      continue;
    }

    zygisk_modules[zygisk_module_length].dev = st.st_dev;
    zygisk_modules[zygisk_module_length].ino = st.st_ino;

    void *entry = csoloader_get_symbol(&zygisk_modules[zygisk_module_length].lib, "zygisk_module_entry");
    if (!entry) {
      csoloader_unload(&zygisk_modules[zygisk_module_length].lib);
      yinzygiskd_remove_module(i);
      continue;
    }

    zygisk_modules[zygisk_module_length].api.register_module = yinzygisk_module_register;
    zygisk_modules[zygisk_module_length].api.impl = ENCODE_ID((void *)zygisk_module_length);
    zygisk_modules[zygisk_module_length].zygisk_module_entry = (void (*)(void *, void *))entry;
    zygisk_modules[zygisk_module_length].unload = false;
    zygisk_module_length++;
  }

  free_modules(&ms);
  return true;
}

static void yz_run_modules_pre(struct zygisk_context *ctx) {
  for (size_t i = 0; i < zygisk_module_length; i++) {
    yz_module_call_on_load(&zygisk_modules[i], ctx->env);

    if (FLAG_GET(ctx, APP_SPECIALIZE)) {
      yz_module_call_pre_app_specialize(&zygisk_modules[i], ctx->args.app);
    } else if (FLAG_GET(ctx, SERVER_FORK_AND_SPECIALIZE)) {
      yz_module_call_pre_server_specialize(&zygisk_modules[i], ctx->args.server);
    }
  }
}

static void yz_run_modules_post(struct zygisk_context *ctx) {
  FLAG_SET(ctx, POST_SPECIALIZE);

  for (size_t i = 0; i < zygisk_module_length; i++) {
    struct yinzygisk_module *m = &zygisk_modules[i];

    if (FLAG_GET(ctx, APP_SPECIALIZE)) {
      yz_module_call_post_app_specialize(m, ctx->args.app);
    } else if (FLAG_GET(ctx, SERVER_FORK_AND_SPECIALIZE)) {
      yz_module_call_post_server_specialize(m, ctx->args.server);
    }

    if (!m->unload) {
      csoloader_abandon(&m->lib);
      continue;
    }

    csoloader_unload(&m->lib);
  }
}

static void yz_app_specialize_pre(struct zygisk_context *ctx) {
  FLAG_SET(ctx, APP_SPECIALIZE);

  uid_t uid = *ctx->args.app->uid;
  if (IS_ISOLATED_SERVICE(uid) && ctx->args.app->app_data_dir) {
    const char *data_dir = (*ctx->env)->GetStringUTFChars(ctx->env, *ctx->args.app->app_data_dir, NULL);
    if (!data_dir) return;

    struct stat st;
    if (stat(data_dir, &st) == -1) {
      (*ctx->env)->ReleaseStringUTFChars(ctx->env, *ctx->args.app->app_data_dir, data_dir);
      return;
    }

    uid = st.st_uid;
    (*ctx->env)->ReleaseStringUTFChars(ctx->env, *ctx->args.app->app_data_dir, data_dir);
  }

  ctx->info_flags = yinzygiskd_get_process_flags(uid, ctx->process);

  if ((ctx->info_flags & PROCESS_IS_FIRST_STARTED) == PROCESS_IS_FIRST_STARTED &&
      (ctx->info_flags & PROCESS_ON_DENYLIST) == 0 &&
      (ctx->info_flags & PROCESS_IS_MANAGER) == 0) {
    update_mnt_ns(Clean, true);
  }

  if ((ctx->info_flags & PROCESS_IS_MANAGER) == PROCESS_IS_MANAGER) {
    setenv("ZYGISK_ENABLED", "1", 1);
  }

  bool in_denylist = (ctx->info_flags & PROCESS_ON_DENYLIST) == PROCESS_ON_DENYLIST;
  if (in_denylist) {
    FLAG_SET(ctx, DO_REVERT_UNMOUNT);
    update_mnt_ns(Clean, false);
  }

  yz_run_modules_pre(ctx);

  if (!in_denylist && FLAG_GET(ctx, DO_REVERT_UNMOUNT)) {
    update_mnt_ns(Clean, false);
  }
}

static void yz_app_specialize_post(struct zygisk_context *ctx) {
  yz_run_modules_post(ctx);
  (*ctx->env)->ReleaseStringUTFChars(ctx->env, *ctx->args.app->nice_name, ctx->process);
  g_ctx = NULL;
}

static void yz_nativeSpecializeAppProcess_pre(struct zygisk_context *ctx) {
  ctx->process = (*ctx->env)->GetStringUTFChars(ctx->env, *ctx->args.app->nice_name, NULL);
  FLAG_SET(ctx, SKIP_FD_SANITIZATION);
  yz_app_specialize_pre(ctx);
}

static void yz_nativeSpecializeAppProcess_post(struct zygisk_context *ctx) {
  yz_app_specialize_post(ctx);
}

static void yz_nativeForkSystemServer_pre(struct zygisk_context *ctx) {
  FLAG_SET(ctx, SERVER_FORK_AND_SPECIALIZE);

  yz_fork_pre(ctx);
  if (!is_zygote_child(ctx)) return;

  yz_run_modules_pre(ctx);
  yz_sanitize_fds(ctx);
}

static void yz_nativeForkSystemServer_post(struct zygisk_context *ctx) {
  if (ctx->pid == 0) {
    yz_run_modules_post(ctx);
  }

  yz_fork_post(ctx);
}

static void yz_nativeForkAndSpecialize_pre(struct zygisk_context *ctx) {
  ctx->process = (*ctx->env)->GetStringUTFChars(ctx->env, *ctx->args.app->nice_name, NULL);
  FLAG_SET(ctx, APP_FORK_AND_SPECIALIZE);

  yz_fork_pre(ctx);
  if (!is_zygote_child(ctx)) return;

  yz_app_specialize_pre(ctx);
  yz_sanitize_fds(ctx);
}

static void yz_nativeForkAndSpecialize_post(struct zygisk_context *ctx) {
  if (ctx->pid == 0) {
    yz_app_specialize_post(ctx);
  }

  yz_fork_post(ctx);
}

static void yz_init(struct zygisk_context *ctx, JNIEnv *env, void *args) {
  memset(ctx, 0, sizeof(struct zygisk_context));
  ctx->env = env;
  ctx->args.ptr = args;
  ctx->pid = -1;
  pthread_mutex_init(&ctx->hook_info_lock, NULL);
  g_ctx = ctx;
}

static void yz_cleanup(struct zygisk_context *ctx) {
  g_ctx = NULL;

  if (!is_zygote_child(ctx)) return;

  should_unmap_zygisk = true;

  for (size_t i = 0; i < jni_hook_list_count; i++) {
    struct jni_hook_entry *entry = &jni_hook_list[i];
    jclass jc = (*ctx->env)->FindClass(ctx->env, entry->class_name);
    if (jc) {
      if (entry->methods_count > 0 &&
          (*ctx->env)->RegisterNatives(ctx->env, jc, entry->methods, (jint)entry->methods_count) != 0) {
        should_unmap_zygisk = false;
      }
      (*ctx->env)->DeleteLocalRef(ctx->env, jc);
    }

    free(entry->class_name);
    free(entry->methods);
  }

  free(jni_hook_list);
  jni_hook_list = NULL;
  jni_hook_list_count = 0;

  for (size_t i = 0; i < ctx->register_info_count; i++) {
    regfree(&ctx->register_info[i].regex);
    free(ctx->register_info[i].symbol);
  }
  ctx->register_info_count = 0;

  for (size_t i = 0; i < ctx->ignore_info_count; i++) {
    regfree(&ctx->ignore_info[i].regex);
    free(ctx->ignore_info[i].symbol);
  }
  ctx->ignore_info_count = 0;

  if (plt_hook_list) {
    for (size_t i = 0; i < plt_hook_list_count; i++) {
      free((void *)plt_hook_list[i].lib_path);
      free((void *)plt_hook_list[i].symbol);
    }
    free(plt_hook_list);
    plt_hook_list = NULL;
    plt_hook_list_count = 0;
  }

  for (size_t i = 0; i < zygisk_module_length; i++) {
    memset(&zygisk_modules[i], 0, sizeof(zygisk_modules[i]));
  }

  enable_unloader = true;
  pthread_mutex_destroy(&ctx->hook_info_lock);
}

static bool hook_register(const char *lib_name, const char *symbol, bool is_prefix, void *new_func, void **backup) {
  return (is_prefix ? plti_add_hook_by_prefix : plti_add_hook)(&plti_ctx, lib_name, symbol, new_func, backup);
}

static bool hook_unregister(const char *lib_name, const char *symbol, bool is_prefix, void **backup) {
  if (!(is_prefix ? plti_remove_hook_by_prefix : plti_remove_hook)(&plti_ctx, lib_name, symbol, backup)) {
    should_unmap_zygisk = false;
    return false;
  }
  return true;
}

#define PLT_HOOK_REGISTER_SYM(LIB, SYM, NAME, IS_PREFIX) \
  hook_register(LIB, SYM, IS_PREFIX, (void *)new_##NAME, (void **)&old_##NAME)

#define PLT_HOOK_REGISTER(LIB, SYM, IS_PREFIX) \
  PLT_HOOK_REGISTER_SYM(LIB, #SYM, SYM, IS_PREFIX)

#define PLT_HOOK_UNREGISTER_SYM(LIB, SYM, NAME, IS_PREFIX) \
  hook_unregister(LIB, SYM, IS_PREFIX, (void **)&old_##NAME)

#define PLT_HOOK_UNREGISTER(LIB, SYM, IS_PREFIX) \
  PLT_HOOK_UNREGISTER_SYM(LIB, #SYM, SYM, IS_PREFIX)

void hook_functions(void) {
  plti_init(&plti_ctx);
  plti_add_lib(&plti_ctx, "libandroid_runtime.so");

  PLT_HOOK_REGISTER("libandroid_runtime.so", fork, false);
  PLT_HOOK_REGISTER("libandroid_runtime.so", strdup, false);
  PLT_HOOK_REGISTER("libandroid_runtime.so", property_get, false);
  PLT_HOOK_REGISTER_SYM("libandroid_runtime.so", "_ZNK18FileDescriptorInfo14ReopenOrDetach", _ZNK18FileDescriptorInfo14ReopenOrDetach, true);
}

static void hook_unloader(void) {
  if (!plti_add_lib(&plti_ctx, "libart.so")) return;

  PLT_HOOK_REGISTER("libart.so", pthread_attr_setstacksize, false);
  PLT_HOOK_UNREGISTER("libandroid_runtime.so", property_get, false);

  load_modules_only();
}

static void unhook_functions(void) {
  PLT_HOOK_UNREGISTER("libandroid_runtime.so", fork, false);
  PLT_HOOK_UNREGISTER("libandroid_runtime.so", strdup, false);
  PLT_HOOK_UNREGISTER_SYM("libandroid_runtime.so", "_ZNK18FileDescriptorInfo14ReopenOrDetach", _ZNK18FileDescriptorInfo14ReopenOrDetach, true);
  PLT_HOOK_UNREGISTER("libart.so", pthread_attr_setstacksize, false);
}
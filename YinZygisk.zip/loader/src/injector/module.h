#ifndef MODULE_H
#define MODULE_H

#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>

#include <jni.h>
#include <csoloader.h>

#define YINZYGISK_API_VERSION 5

enum yinzygiskd_flags : uint32_t {
  PROCESS_GRANTED_ROOT = (1u << 0),
  PROCESS_ON_DENYLIST = (1u << 1),

  PROCESS_IS_MANAGER = (1u << 27),
  PROCESS_ROOT_IS_KSU = (1u << 29),
  PROCESS_IS_FIRST_STARTED = (1u << 31),

  PRIVATE_MASK = PROCESS_IS_FIRST_STARTED
};

struct app_specialize_args_v1 {
  jint *uid;
  jint *gid;
  jintArray *gids;
  jint *runtime_flags;
  jint *mount_external;
  jstring *se_info;
  jstring *nice_name;
  jstring *instruction_set;
  jstring *app_data_dir;

  jboolean *is_child_zygote;
  jboolean *is_top_app;
  jobjectArray *pkg_data_info_list;
  jobjectArray *whitelisted_data_info_list;
  jboolean *mount_data_dirs;
  jboolean *mount_storage_dirs;
};

struct app_specialize_args_v4 {
  jint *uid;
  jint *gid;
  jintArray *gids;
  jint *runtime_flags;
  jobjectArray *rlimits;
  jint *mount_external;
  jstring *se_info;
  jstring *nice_name;
  jstring *instruction_set;
  jstring *app_data_dir;

  jintArray *fds_to_ignore;
  jboolean *is_child_zygote;
  jboolean *is_top_app;
  jobjectArray *pkg_data_info_list;
  jobjectArray *whitelisted_data_info_list;
  jboolean *mount_data_dirs;
  jboolean *mount_storage_dirs;
};

struct app_specialize_args_v5 {
  jint *uid;
  jint *gid;
  jintArray *gids;
  jint *runtime_flags;
  jobjectArray *rlimits;
  jint *mount_external;
  jstring *se_info;
  jstring *nice_name;
  jstring *instruction_set;
  jstring *app_data_dir;

  jintArray *fds_to_ignore;
  jboolean *is_child_zygote;
  jboolean *is_top_app;
  jobjectArray *pkg_data_info_list;
  jobjectArray *whitelisted_data_info_list;
  jboolean *mount_data_dirs;
  jboolean *mount_storage_dirs;

  jboolean *mount_sysprop_overrides;
};

struct server_specialize_args_v1 {
  jint *uid;
  jint *gid;
  jintArray *gids;
  jint *runtime_flags;
  jlong *permitted_capabilities;
  jlong *effective_capabilities;
};

enum yinzygisk_options {
  FORCE_DENYLIST_UNMOUNT = 0,
  DLCLOSE_MODULE_LIBRARY = 1
};

struct yinzygisk_abi {
  long api_version;
  void *impl;

  void (*pre_app_specialize)(void *, void *);
  void (*post_app_specialize)(void *, const void *);
  void (*pre_server_specialize)(void *, void *);
  void (*post_server_specialize)(void *, const void *);
};

struct yinzygisk_api {
  void *impl;
  bool (*register_module)(struct yinzygisk_api *, struct yinzygisk_abi const *);

  void (*hook_jni_native_methods)(JNIEnv *, const char *, JNINativeMethod *, int);
  union {
    void (*plt_hook_register)(const char *, const char *, void *, void **);
    void (*plt_hook_register_v4)(dev_t, ino_t, const char *, void *, void **);
  };
  union {
    void (*plt_hook_exclude)(const char *, const char *);
    void (*exempt_fd)(int);
  };

  bool (*plt_hook_commit)(void);
  int (*connect_companion)(void *);
  void (*set_option)(void *, enum yinzygisk_options opt);
  int (*get_module_dir)(void *);
  uint32_t (*get_flags)(void);
};

struct yinzygisk_module {
  struct yinzygisk_abi abi;
  struct yinzygisk_api api;

  struct csoloader lib;

  dev_t dev;
  ino_t ino;
  void (*zygisk_module_entry)(void *, void *);

  bool unload;
};

static inline void yz_dispatch_app_specialize(
    void (*fn)(void *, void *), void *impl,
    long api_version, const struct app_specialize_args_v5 *args) {
  switch (api_version) {
    case 1:
    case 2: {
      struct app_specialize_args_v1 versioned_args = {
        .uid = args->uid,
        .gid = args->gid,
        .gids = args->gids,
        .runtime_flags = args->runtime_flags,
        .mount_external = args->mount_external,
        .se_info = args->se_info,
        .nice_name = args->nice_name,
        .instruction_set = args->instruction_set,
        .app_data_dir = args->app_data_dir,
        .is_child_zygote = args->is_child_zygote,
        .is_top_app = args->is_top_app,
        .pkg_data_info_list = args->pkg_data_info_list,
        .whitelisted_data_info_list = args->whitelisted_data_info_list,
        .mount_data_dirs = args->mount_data_dirs,
        .mount_storage_dirs = args->mount_storage_dirs
      };
      fn(impl, &versioned_args);
      break;
    }
    case 3:
    case 4: {
      struct app_specialize_args_v4 versioned_args;
      memcpy(&versioned_args, args, sizeof(struct app_specialize_args_v4));
      fn(impl, &versioned_args);
      break;
    }
    case 5:
      fn(impl, (void *)args);
      break;
    default:
      break;
  }
}

static inline void yz_module_call_on_load(struct yinzygisk_module *m, void *env) {
  m->zygisk_module_entry((void *)&m->api, env);
}

static inline void yz_module_call_pre_app_specialize(struct yinzygisk_module *m, struct app_specialize_args_v5 *args) {
  if (!m->abi.pre_app_specialize) return;
  yz_dispatch_app_specialize(m->abi.pre_app_specialize, m->abi.impl, m->abi.api_version, args);
}

static inline void yz_module_call_post_app_specialize(struct yinzygisk_module *m, const struct app_specialize_args_v5 *args) {
  if (!m->abi.post_app_specialize) return;
  yz_dispatch_app_specialize((void (*)(void *, void *))m->abi.post_app_specialize, m->abi.impl, m->abi.api_version, args);
}

static inline void yz_module_call_pre_server_specialize(struct yinzygisk_module *m, struct server_specialize_args_v1 *args) {
  if (!m->abi.pre_server_specialize) return;
  m->abi.pre_server_specialize(m->abi.impl, args);
}

static inline void yz_module_call_post_server_specialize(struct yinzygisk_module *m, const struct server_specialize_args_v1 *args) {
  if (!m->abi.post_server_specialize) return;
  m->abi.post_server_specialize(m->abi.impl, args);
}

#endif /* MODULE_H */
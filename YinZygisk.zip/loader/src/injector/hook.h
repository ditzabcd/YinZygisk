#ifndef HOOK_H
#define HOOK_H

#include <stddef.h>
#include <sys/types.h>

extern void *start_addr;
extern size_t block_size;

extern dev_t self_dev;
extern ino_t self_ino;

void hook_functions(void);

#endif /* HOOK_H */
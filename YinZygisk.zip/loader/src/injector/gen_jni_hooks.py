#!/usr/bin/env python3

# Ganti ke 'yz' setelah simbol di hook.c / module.h ikut di-rename ke YinZygisk
PREFIX = 'rz'

# True = pangkas signature khusus Samsung & GrapheneOS (hemat ~45% wrapper & string .rodata)
# Aman untuk Infinix (XOS / AOSP-based) dan semua ROM berbasis AOSP Android 5 - 17
DROP_OEM_VARIANTS = True

primitives = ('jint', 'jboolean', 'jlong')


class JType:
    def __init__(self, cpp, jni):
        self.cpp = cpp
        self.jni = jni


class JArray(JType):
    def __init__(self, elem_type):
        name = f'{elem_type.cpp}Array' if elem_type.cpp in primitives else 'jobjectArray'
        super().__init__(name, f'[{elem_type.jni}')


class Argument:
    def __init__(self, name, arg_type, set_arg=False):
        self.name = name
        self.type = arg_type
        self.set_arg = set_arg

    def cpp(self):
        return f'{self.type.cpp} {self.name}'


class Anon(Argument):
    cnt = 0

    def __init__(self, arg_type):
        super().__init__(f'_{Anon.cnt}', arg_type)
        Anon.cnt += 1


class Return:
    def __init__(self, value, ret_type):
        self.value = value
        self.type = ret_type


class Method:
    def __init__(self, name, ret, args):
        self.name = name
        self.ret = ret
        self.args = args

    def cpp(self):
        return ', '.join(x.cpp() for x in self.args)

    def name_list(self):
        return ', '.join(x.name for x in self.args)

    def jni(self):
        args = ''.join(x.type.jni for x in self.args)
        return f'({args}){self.ret.type.jni}'

    def body(self):
        return ''


class JNIHook(Method):
    def __init__(self, ver, ret, args):
        super().__init__(f'{self.base_name()}_{ver}', ret, args)

    def base_name(self):
        return ''

    def func_ptr_type(self):
        return f'{self.base_name()}_fn'

    def orig_method(self):
        return f'(({self.func_ptr_type()}){self.base_name()}_orig)'


def ind(i):
    return '\n' + '  ' * i


jint = JType('jint', 'I')
jintArray = JArray(jint)
jstring = JType('jstring', 'Ljava/lang/String;')
jboolean = JType('jboolean', 'Z')
jlong = JType('jlong', 'J')
jlongArray = JArray(jlong)
void = JType('void', 'V')


class ForkAndSpec(JNIHook):
    def __init__(self, ver, args):
        super().__init__(ver, Return('ctx.pid', jint), args)

    def base_name(self):
        return 'nativeForkAndSpecialize'

    def init_args(self):
        return (
            'struct app_specialize_args_v5 args = { '
            '.uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, '
            '.rlimits = &rlimits, .mount_external = &mount_external, .se_info = &se_info, '
            '.nice_name = &nice_name, .instruction_set = &instruction_set, '
            '.app_data_dir = &app_data_dir };'
        )

    def body(self):
        base = self.base_name()
        lines = [ind(1) + self.init_args()]
        for a in self.args:
            if a.set_arg:
                lines.append(ind(1) + f'args.{a.name} = &{a.name};')
        lines.extend([
            ind(1) + 'struct zygisk_context ctx;',
            ind(1) + f'{PREFIX}_init(&ctx, env, &args);',
            ind(1) + f'{PREFIX}_{base}_pre(&ctx);',
            ind(1) + f'{self.orig_method()}({ind(2)}env, clazz, {self.name_list()}{ind(1)});',
            ind(1) + f'{PREFIX}_{base}_post(&ctx);',
            ind(1) + f'{PREFIX}_cleanup(&ctx);',
        ])
        return ''.join(lines)


class SpecApp(ForkAndSpec):
    def __init__(self, ver, args):
        super().__init__(ver, args)
        self.ret = Return('', void)

    def base_name(self):
        return 'nativeSpecializeAppProcess'


class ForkServer(ForkAndSpec):
    def base_name(self):
        return 'nativeForkSystemServer'

    def init_args(self):
        return (
            'struct server_specialize_args_v1 args = { '
            '.uid = &uid, .gid = &gid, .gids = &gids, .runtime_flags = &runtime_flags, '
            '.permitted_capabilities = &permitted_capabilities, '
            '.effective_capabilities = &effective_capabilities };'
        )


# Common args
uid = Argument('uid', jint)
gid = Argument('gid', jint)
gids = Argument('gids', jintArray)
runtime_flags = Argument('runtime_flags', jint)
rlimits = Argument('rlimits', JArray(jintArray))
mount_external = Argument('mount_external', jint)
se_info = Argument('se_info', jstring)
nice_name = Argument('nice_name', jstring)
fds_to_close = Argument('fds_to_close', jintArray)
instruction_set = Argument('instruction_set', jstring)
app_data_dir = Argument('app_data_dir', jstring)

fds_to_ignore = Argument('fds_to_ignore', jintArray, True)
is_child_zygote = Argument('is_child_zygote', jboolean, True)
is_top_app = Argument('is_top_app', jboolean, True)
pkg_data_info_list = Argument('pkg_data_info_list', JArray(jstring), True)
whitelisted_data_info_list = Argument('whitelisted_data_info_list', JArray(jstring), True)
mount_data_dirs = Argument('mount_data_dirs', jboolean, True)
mount_storage_dirs = Argument('mount_storage_dirs', jboolean, True)
mount_sysprop_overrides = Argument('mount_sysprop_overrides', jboolean, True)
permitted_capabilities = Argument('permitted_capabilities', jlong)
effective_capabilities = Argument('effective_capabilities', jlong)

# AOSP nativeForkAndSpecialize
fas_aosp = [
    ForkAndSpec('l', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, nice_name, fds_to_close, instruction_set, app_data_dir]),
    ForkAndSpec('o', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, nice_name, fds_to_close, fds_to_ignore, instruction_set, app_data_dir]),
    ForkAndSpec('p', [uid, gid, gids, runtime_flags, rlimits, mount_external, se_info,
        nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir]),
    ForkAndSpec('q_alt', [uid, gid, gids, runtime_flags, rlimits, mount_external, se_info,
        nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir, is_top_app]),
    ForkAndSpec('r', [uid, gid, gids, runtime_flags, rlimits, mount_external, se_info,
        nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir, is_top_app,
        pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs]),
    ForkAndSpec('u', [uid, gid, gids, runtime_flags, rlimits, mount_external, se_info,
        nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir, is_top_app,
        pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs, mount_sysprop_overrides]),
    ForkAndSpec('c', [uid, Anon(jint), gid, gids, runtime_flags, rlimits, mount_external,
        se_info, nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir,
        Anon(jboolean), is_top_app, pkg_data_info_list, whitelisted_data_info_list,
        mount_data_dirs, mount_storage_dirs, mount_sysprop_overrides]),
]

fas_oem = [
    ForkAndSpec('samsung_m', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, Anon(jint), Anon(jint), nice_name, fds_to_close, instruction_set, app_data_dir]),
    ForkAndSpec('samsung_n', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, Anon(jint), Anon(jint), nice_name, fds_to_close, instruction_set, app_data_dir, Anon(jint)]),
    ForkAndSpec('samsung_o', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, Anon(jint), Anon(jint), nice_name, fds_to_close, fds_to_ignore, instruction_set, app_data_dir]),
    ForkAndSpec('samsung_p', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, Anon(jint), Anon(jint), nice_name, fds_to_close, fds_to_ignore, is_child_zygote,
        instruction_set, app_data_dir]),
    ForkAndSpec('samsung_b', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir,
        Anon(jboolean), is_top_app, pkg_data_info_list, whitelisted_data_info_list,
        mount_data_dirs, mount_storage_dirs, mount_sysprop_overrides]),
    ForkAndSpec('grapheneos_u', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir,
        is_top_app, pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs,
        mount_sysprop_overrides, Anon(jlongArray)]),
    ForkAndSpec('grapheneos_u_alt', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, nice_name, fds_to_close, fds_to_ignore, is_child_zygote, instruction_set, app_data_dir,
        is_top_app, Anon(jboolean), pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs,
        mount_storage_dirs, mount_sysprop_overrides, Anon(jlongArray)]),
    ForkAndSpec('grapheneos_c', [Anon(jlongArray), uid, gid, gids, runtime_flags,
        rlimits, mount_external, se_info, nice_name, fds_to_close, fds_to_ignore, is_child_zygote,
        instruction_set, app_data_dir, is_top_app, Anon(jboolean), pkg_data_info_list,
        whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs, mount_sysprop_overrides]),
]

# AOSP nativeSpecializeAppProcess
spec_aosp = [
    SpecApp('q', [uid, gid, gids, runtime_flags, rlimits, mount_external, se_info,
        nice_name, is_child_zygote, instruction_set, app_data_dir]),
    SpecApp('q_alt', [uid, gid, gids, runtime_flags, rlimits, mount_external, se_info,
        nice_name, is_child_zygote, instruction_set, app_data_dir, is_top_app]),
    SpecApp('r', [uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name,
        is_child_zygote, instruction_set, app_data_dir, is_top_app, pkg_data_info_list,
        whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs]),
    SpecApp('u', [uid, gid, gids, runtime_flags, rlimits, mount_external, se_info, nice_name,
        is_child_zygote, instruction_set, app_data_dir, is_top_app, pkg_data_info_list,
        whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs, mount_sysprop_overrides]),
    SpecApp('c', [uid, Anon(jint), gid, gids, runtime_flags, rlimits, mount_external,
        se_info, nice_name, is_child_zygote, instruction_set, app_data_dir,
        is_top_app, pkg_data_info_list, whitelisted_data_info_list,
        mount_data_dirs, mount_storage_dirs, mount_sysprop_overrides]),
]

spec_oem = [
    SpecApp('samsung_q', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, Anon(jint), Anon(jint), nice_name, is_child_zygote, instruction_set, app_data_dir]),
    SpecApp('grapheneos_u', [uid, gid, gids, runtime_flags, rlimits, mount_external,
        se_info, nice_name, is_child_zygote, instruction_set, app_data_dir, is_top_app,
        pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs, mount_storage_dirs,
        mount_sysprop_overrides, Anon(jlongArray)]),
    SpecApp('grapheneos_c', [Anon(jlongArray), uid, gid, gids, runtime_flags,
        rlimits, mount_external, se_info, nice_name, is_child_zygote, instruction_set, app_data_dir,
        is_top_app, pkg_data_info_list, whitelisted_data_info_list, mount_data_dirs,
        mount_storage_dirs, mount_sysprop_overrides]),
]

# AOSP & OEM nativeForkSystemServer
server_aosp = [
    ForkServer('l', [uid, gid, gids, runtime_flags, rlimits,
        permitted_capabilities, effective_capabilities]),
]

server_oem = [
    ForkServer('samsung_q', [uid, gid, gids, runtime_flags, Anon(jint), Anon(jint), rlimits,
        permitted_capabilities, effective_capabilities]),
]


def gen_jni_def(methods):
    first_m = methods[0]
    base = first_m.base_name()
    func_ptr_type = f'{base}_fn'

    out = [
        ind(0) + f'static void *{base}_orig = NULL;',
        ind(0) + f'typedef {first_m.ret.type.cpp} (*{func_ptr_type})(JNIEnv *, jclass, ...);',
    ]

    for m in methods:
        out.append(ind(0) + f'__attribute__((no_stack_protector)) static {m.ret.type.cpp} {m.name}(JNIEnv *env, jclass clazz, {m.cpp()}) {{')
        out.append(m.body())
        if m.ret.value:
            out.append(ind(1) + f'return {m.ret.value};')
        out.append(ind(0) + '}')

    out.append(ind(0) + f'static JNINativeMethod {base}_methods[] = {{')
    for m in methods:
        out.extend([
            ind(1) + '{',
            ind(2) + f'"{base}",',
            ind(2) + f'"{m.jni()}",',
            ind(2) + f'(void *)&{m.name}',
            ind(1) + '},',
        ])
    out.append(ind(0) + '};' + ind(0))

    return ''.join(out)


def main():
    fas_methods = fas_aosp if DROP_OEM_VARIANTS else (fas_aosp + fas_oem)
    spec_methods = spec_aosp if DROP_OEM_VARIANTS else (spec_aosp + spec_oem)
    server_methods = server_aosp if DROP_OEM_VARIANTS else (server_aosp + server_oem)

    with open('jni_hooks.h', 'w', encoding='utf-8') as f:
        f.write('#ifndef JNI_HOOKS_H\n#define JNI_HOOKS_H\n')
        f.write(gen_jni_def(fas_methods))
        f.write(gen_jni_def(spec_methods))
        f.write(gen_jni_def(server_methods))
        f.write("""
static inline void resolve_and_push_hook(
    JNIEnv *env, const char *clz,
    JNINativeMethod *methods, size_t count,
    void **orig_out, JNINativeMethod *hooks, int *hooks_count) {
  hook_jni_methods(env, clz, methods, (int)count);
  for (size_t i = 0; i < count; i++) {
    if (!methods[i].fnPtr) continue;
    *orig_out = methods[i].fnPtr;
    hooks[(*hooks_count)++] = methods[i];
    break;
  }
}

static void do_hook_zygote(JNIEnv *env) {
  const char *clz = "com/android/internal/os/Zygote";

  JNINativeMethod hooks[3];
  int hooks_count = 0;

  resolve_and_push_hook(
      env, clz, nativeForkAndSpecialize_methods,
      sizeof(nativeForkAndSpecialize_methods) / sizeof(nativeForkAndSpecialize_methods[0]),
      &nativeForkAndSpecialize_orig, hooks, &hooks_count);

  resolve_and_push_hook(
      env, clz, nativeSpecializeAppProcess_methods,
      sizeof(nativeSpecializeAppProcess_methods) / sizeof(nativeSpecializeAppProcess_methods[0]),
      &nativeSpecializeAppProcess_orig, hooks, &hooks_count);

  resolve_and_push_hook(
      env, clz, nativeForkSystemServer_methods,
      sizeof(nativeForkSystemServer_methods) / sizeof(nativeForkSystemServer_methods[0]),
      &nativeForkSystemServer_orig, hooks, &hooks_count);

  jni_hook_list_add(clz, hooks, hooks_count);
}

#endif /* JNI_HOOKS_H */
""")


if __name__ == '__main__':
    main()
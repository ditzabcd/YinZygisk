#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "daemon.h"
#include "monitor.h"

int main(int argc, char **argv) {
  if (argc < 2) return 1;

  if (strcmp(argv[1], "monitor") == 0) {
    init_monitor();
    return 0;
  }

  if (argc >= 3 && strcmp(argv[1], "trace") == 0) {
    bool is_tango = false;
    bool do_restart = false;

    for (int i = 3; i < argc; i++) {
      if (strcmp(argv[i], "--restart") == 0) do_restart = true;
      else if (strcmp(argv[i], "--tango") == 0) is_tango = true;
    }

    if (do_restart && !is_tango) yinzygiskd_zygote_restart();

    long pid = strtol(argv[2], NULL, 0);
    if (pid <= 0 || !trace_zygote(pid, is_tango)) {
      if (pid > 0) kill((pid_t)pid, SIGKILL);
      return 1;
    }

    if (do_restart && is_tango) yinzygiskd_zygote_restart();
    return 0;
  }

  if (argc >= 3 && strcmp(argv[1], "ctl") == 0) {
    enum yinzygiskd_command command;

    if (strcmp(argv[2], "start") == 0) command = START;
    else if (strcmp(argv[2], "stop") == 0) command = STOP;
    else if (strcmp(argv[2], "exit") == 0) command = EXIT;
    else return 1;

    return send_control_command(command) == -1 ? 1 : 0;
  }

  if (strcmp(argv[1], "version") == 0) {
    return 0;
  }

  if (strcmp(argv[1], "info") == 0) {
    struct yinzygisk_info info;
    yinzygiskd_get_info(&info);

    printf("PID: %d\nRoot: %s\n",
           info.pid,
           info.root_impl == ROOT_IMPL_KERNELSU ? "KernelSU Next" : "none");

    if (info.modules.modules_count != 0) {
      printf("Modules: %zu\n", info.modules.modules_count);
      for (size_t i = 0; i < info.modules.modules_count; i++) {
        printf(" - %s\n", info.modules.modules[i]);
      }
    } else {
      printf("Modules: N/A\n");
    }

    free_yinzygisk_info(&info);
    return 0;
  }

  return 1;
}
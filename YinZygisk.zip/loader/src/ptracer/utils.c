#include <errno.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <fcntl.h>
#include <link.h>
#include <linux/limits.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/ptrace.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <unistd.h>

#include "elf_util.h"
#include "utils.h"

ssize_t write_proc(int pid, uintptr_t remote_addr, const void *buf, size_t len) {
  struct iovec local = {
    .iov_base = (void *)buf,
    .iov_len = len
  };

  struct iovec remote = {
    .iov_base = (void *)remote_addr,
    .iov_len = len
  };

  return process_vm_writev(pid, &local, 1, &remote, 1, 0);
}

ssize_t read_proc(int pid, uintptr_t remote_addr, void *buf, size_t len) {
  struct iovec local = {
    .iov_base = buf,
    .iov_len = len
  };

  struct iovec remote = {
    .iov_base = (void *)remote_addr,
    .iov_len = len
  };

  return process_vm_readv(pid, &local, 1, &remote, 1, 0);
}

bool get_regs(int pid, struct user_regs_struct *regs) {
  #if defined(__x86_64__) || defined(__i386__)
    return ptrace(PTRACE_GETREGS, pid, 0, regs) != -1;
  #elif defined(__aarch64__) || defined(__arm__)
    struct iovec iov = {
      .iov_base = regs,
      .iov_len = sizeof(struct user_regs_struct),
    };

    if (ptrace(PTRACE_GETREGSET, pid, NT_PRSTATUS, &iov) == -1) {
      return ptrace(/* PTRACE_GETREGS */ 12, pid, 0, regs) != -1;
    }
    return true;
  #else
    (void)pid;
    (void)regs;
    return false;
  #endif
}

bool set_regs(int pid, struct user_regs_struct *regs) {
  #if defined(__x86_64__) || defined(__i386__)
    return ptrace(PTRACE_SETREGS, pid, 0, regs) != -1;
  #elif defined(__aarch64__) || defined(__arm__)
    struct iovec iov = {
      .iov_base = regs,
      .iov_len = sizeof(struct user_regs_struct),
    };

    if (ptrace(PTRACE_SETREGSET, pid, NT_PRSTATUS, &iov) == -1) {
      return ptrace(/* PTRACE_SETREGS */ 13, pid, 0, regs) != -1;
    }
    return true;
  #else
    (void)pid;
    (void)regs;
    return false;
  #endif
}

const char *position_after(const char *str, const char needle) {
  const char *positioned = strrchr(str, needle);
  return positioned ? positioned + 1 : str;
}

void *find_module_return_addr(struct maps_info *map, const char *suffix) {
  size_t suffix_len = strlen(suffix);

  for (size_t i = 0; i < map->length; i++) {
    const struct map_entry *m = &map->maps[i];
    if (!m->path || (m->perms & PROT_EXEC)) continue;

    const char *file_name = position_after(m->path, '/');
    if (strncmp(file_name, suffix, suffix_len) == 0) {
      return (void *)m->start;
    }
  }

  return NULL;
}

void *find_module_base(struct maps_info *map, const char *file) {
  for (size_t i = 0; i < map->length; i++) {
    const struct map_entry *m = &map->maps[i];
    if (!m->path || m->offset != 0) continue;
    if (strcmp(m->path, file) == 0) {
      return (void *)m->start;
    }
  }

  return NULL;
}

void *find_func_addr(struct maps_info *local_info, struct maps_info *remote_info, const char *module, const char *func) {
  uint8_t *local_base = (uint8_t *)find_module_base(local_info, module);
  if (!local_base) return NULL;

  uint8_t *remote_base = (uint8_t *)find_module_base(remote_info, module);
  if (!remote_base) return NULL;

  ElfImg *mod = ElfImg_create(module, local_base);
  if (!mod) return NULL;

  uint8_t *sym = (uint8_t *)getSymbAddress(mod, func);
  if (!sym) {
    ElfImg_destroy(mod);
    return NULL;
  }

  uintptr_t addr = (uintptr_t)(sym - local_base) + (uintptr_t)remote_base;
  ElfImg_destroy(mod);

  return (void *)addr;
}

void align_stack(struct user_regs_struct *regs, long preserve) {
  regs->REG_SP = (uintptr_t)((intptr_t)(regs->REG_SP - preserve) & ~0xf);
}

uintptr_t remote_call(int pid, struct user_regs_struct *regs, uintptr_t func_addr, uintptr_t return_addr, long *args, size_t args_size) {
  align_stack(regs, 0);

  #if defined(__x86_64__)
    if (args_size >= 1) regs->rdi = args[0];
    if (args_size >= 2) regs->rsi = args[1];
    if (args_size >= 3) regs->rdx = args[2];
    if (args_size >= 4) regs->rcx = args[3];
    if (args_size >= 5) regs->r8 = args[4];
    if (args_size >= 6) regs->r9 = args[5];
    if (args_size > 6) {
      long remain = (long)((args_size - 6) * sizeof(long));
      align_stack(regs, remain);
      if (write_proc(pid, (uintptr_t)regs->REG_SP, &args[6], (size_t)remain) != remain) return 0;
    }

    regs->REG_SP -= sizeof(long);
    if (write_proc(pid, (uintptr_t)regs->REG_SP, &return_addr, sizeof(return_addr)) != (ssize_t)sizeof(return_addr)) return 0;
    regs->REG_IP = func_addr;
  #elif defined(__i386__)
    if (args_size > 0) {
      long remain = (long)(args_size * sizeof(long));
      align_stack(regs, remain);
      if (write_proc(pid, (uintptr_t)regs->REG_SP, args, (size_t)remain) != remain) return 0;
    }

    regs->REG_SP -= sizeof(long);
    if (write_proc(pid, (uintptr_t)regs->REG_SP, &return_addr, sizeof(return_addr)) != (ssize_t)sizeof(return_addr)) return 0;
    regs->REG_IP = func_addr;
  #elif defined(__aarch64__)
    for (size_t i = 0; i < args_size && i < 8; i++) {
      regs->regs[i] = (uint64_t)args[i];
    }

    if (args_size > 8) {
      long remain = (long)((args_size - 8) * sizeof(long));
      align_stack(regs, remain);
      if (write_proc(pid, (uintptr_t)regs->REG_SP, &args[8], (size_t)remain) != remain) return 0;
    }

    regs->regs[30] = return_addr;
    regs->REG_IP = func_addr;
  #elif defined(__arm__)
    for (size_t i = 0; i < args_size && i < 4; i++) {
      regs->uregs[i] = (unsigned long)args[i];
    }

    if (args_size > 4) {
      long remain = (long)((args_size - 4) * sizeof(long));
      align_stack(regs, remain);
      if (write_proc(pid, (uintptr_t)regs->REG_SP, &args[4], (size_t)remain) != remain) return 0;
    }

    regs->uregs[14] = return_addr;
    regs->REG_IP = func_addr;

    unsigned long CPSR_T_MASK = 1lu << 5;
    if ((regs->REG_IP & 1) != 0) {
      regs->REG_IP &= ~1u;
      regs->uregs[16] |= CPSR_T_MASK;
    } else {
      regs->uregs[16] &= ~CPSR_T_MASK;
    }
  #endif

  if (!set_regs(pid, regs)) return 0;

  ptrace(PTRACE_CONT, pid, 0, 0);

  int status;
  wait_for_trace(pid, &status, __WALL);
  if (!get_regs(pid, regs)) return 0;

  if (WSTOPSIG(status) == SIGSEGV && (uintptr_t)regs->REG_IP == return_addr) {
    return regs->REG_RET;
  }

  return 0;
}

int fork_dont_care(void) {
  pid_t pid = fork();

  if (pid == 0) {
    pid = fork();
    if (pid > 0) _exit(0);
  } else if (pid > 0) {
    int status;
    waitpid(pid, &status, __WALL);
  }

  return pid;
}

uintptr_t find_syscall_gadget(int pid, struct maps_info *remote_map) {
  #if defined(__aarch64__)
    const uint32_t svc_insn = 0xD4000001;
    const size_t insn_size = 4;
  #elif defined(__arm__)
    const uint16_t thumb_svc_insn = 0xDF00;
    const uint32_t arm_svc_insn = 0xEF000000;
  #elif defined(__x86_64__)
    const uint16_t svc_insn = 0x050F;
    const size_t insn_size = 2;
  #elif defined(__i386__)
    const uint16_t svc_insn = 0x80CD;
    const size_t insn_size = 2;
  #endif

  uint8_t buf[16384];

  for (int pass = 0; pass < 2; pass++) {
    bool vdso_only = (pass == 0);

    for (size_t i = 0; i < remote_map->length; i++) {
      const struct map_entry *m = &remote_map->maps[i];
      bool is_vdso = m->path && strstr(m->path, "[vdso]") != NULL;

      if (!(m->perms & PROT_EXEC) || is_vdso != vdso_only) continue;

      size_t region_size = m->end - m->start;
      size_t max_scan = vdso_only ? 0x10000 : 0x100000;
      if (region_size > max_scan) region_size = max_scan;

      for (size_t offset = 0; offset < region_size; offset += sizeof(buf)) {
        size_t chunk = region_size - offset;
        if (chunk > sizeof(buf)) chunk = sizeof(buf);

        if (read_proc(pid, m->start + offset, buf, chunk) != (ssize_t)chunk) break;

        #ifdef __arm__
          for (size_t j = 0; j + sizeof(arm_svc_insn) <= chunk; j += sizeof(uint32_t)) {
            if (memcmp(buf + j, &arm_svc_insn, sizeof(arm_svc_insn)) == 0) {
              return m->start + offset + j;
            }
          }

          for (size_t j = 0; j + sizeof(thumb_svc_insn) <= chunk; j += sizeof(uint16_t)) {
            if (memcmp(buf + j, &thumb_svc_insn, sizeof(thumb_svc_insn)) == 0) {
              return m->start + offset + j + 1;
            }
          }
        #else
          for (size_t j = 0; j + insn_size <= chunk; j += insn_size) {
            if (memcmp(buf + j, &svc_insn, insn_size) == 0) {
              return m->start + offset + j;
            }
          }
        #endif
      }
    }
  }

  return 0;
}

#if defined(__aarch64__)
  #define TARGET_JUMP_SLOT R_AARCH64_JUMP_SLOT
#elif defined(__arm__)
  #define TARGET_JUMP_SLOT R_ARM_JUMP_SLOT
#elif defined(__x86_64__)
  #define TARGET_JUMP_SLOT R_X86_64_JUMP_SLOT
#elif defined(__i386__)
  #define TARGET_JUMP_SLOT R_386_JMP_SLOT
#endif

#if defined(__LP64__)
  #define ELFW_R_TYPE(info) ELF64_R_TYPE(info)
  #define ELFW_R_SYM(info)  ELF64_R_SYM(info)
  #define EXPECTED_ELFCLASS ELFCLASS64
#else
  #define ELFW_R_TYPE(info) ELF32_R_TYPE(info)
  #define ELFW_R_SYM(info)  ELF32_R_SYM(info)
  #define EXPECTED_ELFCLASS ELFCLASS32
#endif

static bool elf_vaddr_to_off(const ElfW(Phdr) *phdr, int phnum, ElfW(Addr) vaddr, off_t *out_off) {
  for (int i = 0; i < phnum; i++) {
    if (phdr[i].p_type != PT_LOAD) continue;

    ElfW(Addr) seg_start = phdr[i].p_vaddr;
    ElfW(Addr) seg_end = phdr[i].p_vaddr + phdr[i].p_filesz;
    if (vaddr < seg_start || vaddr >= seg_end) continue;

    *out_off = (off_t)phdr[i].p_offset + (off_t)(vaddr - seg_start);
    return true;
  }

  return false;
}

bool find_jump_slot_got_offset(const char *elf_path, const char *symbol, uintptr_t *out_bias, uintptr_t *out_got_off) {
  int fd = open(elf_path, O_RDONLY | O_CLOEXEC);
  if (fd < 0) return false;

  struct stat st;
  if (fstat(fd, &st) != 0 || st.st_size < (off_t)sizeof(ElfW(Ehdr))) {
    close(fd);
    return false;
  }

  ElfW(Ehdr) eh;
  if (pread(fd, &eh, sizeof(eh), 0) != (ssize_t)sizeof(eh) ||
      memcmp(eh.e_ident, ELFMAG, SELFMAG) != 0 ||
      eh.e_ident[EI_CLASS] != EXPECTED_ELFCLASS ||
      eh.e_phnum == 0) {
    close(fd);
    return false;
  }

  ElfW(Phdr) *phdr = calloc(eh.e_phnum, sizeof(ElfW(Phdr)));
  if (!phdr) {
    close(fd);
    return false;
  }

  if (pread(fd, phdr, sizeof(ElfW(Phdr)) * eh.e_phnum, (off_t)eh.e_phoff) != (ssize_t)(sizeof(ElfW(Phdr)) * eh.e_phnum)) {
    free(phdr);
    close(fd);
    return false;
  }

  ElfW(Addr) min_vaddr = (ElfW(Addr))-1;
  ElfW(Addr) dyn_vaddr = 0;
  ElfW(Word) dyn_size = 0;
  for (int i = 0; i < eh.e_phnum; i++) {
    if (phdr[i].p_type == PT_LOAD && phdr[i].p_vaddr < min_vaddr) min_vaddr = phdr[i].p_vaddr;
    if (phdr[i].p_type == PT_DYNAMIC) {
      dyn_vaddr = phdr[i].p_vaddr;
      dyn_size = phdr[i].p_filesz;
    }
  }

  if (!dyn_vaddr || !dyn_size || min_vaddr == (ElfW(Addr))-1) {
    free(phdr);
    close(fd);
    return false;
  }

  off_t dyn_off = 0;
  if (!elf_vaddr_to_off(phdr, eh.e_phnum, dyn_vaddr, &dyn_off)) {
    free(phdr);
    close(fd);
    return false;
  }

  size_t dyn_count = dyn_size / sizeof(ElfW(Dyn));
  ElfW(Dyn) *dyn = calloc(dyn_count, sizeof(ElfW(Dyn)));
  if (!dyn) {
    free(phdr);
    close(fd);
    return false;
  }

  if (pread(fd, dyn, dyn_count * sizeof(ElfW(Dyn)), dyn_off) != (ssize_t)(dyn_count * sizeof(ElfW(Dyn)))) {
    free(dyn);
    free(phdr);
    close(fd);
    return false;
  }

  ElfW(Addr) jmprel = 0, symtab = 0, strtab = 0;
  ElfW(Word) pltrelsz = 0, pltrel = 0;
  for (size_t i = 0; i < dyn_count; i++) {
    switch (dyn[i].d_tag) {
      case DT_JMPREL:   jmprel = dyn[i].d_un.d_ptr; break;
      case DT_PLTRELSZ: pltrelsz = dyn[i].d_un.d_val; break;
      case DT_PLTREL:   pltrel = dyn[i].d_un.d_val; break;
      case DT_SYMTAB:   symtab = dyn[i].d_un.d_ptr; break;
      case DT_STRTAB:   strtab = dyn[i].d_un.d_ptr; break;
      default: break;
    }
  }

  if (!jmprel || !pltrelsz || !symtab || !strtab || !(pltrel == DT_REL || pltrel == DT_RELA)) {
    free(dyn);
    free(phdr);
    close(fd);
    return false;
  }

  off_t rel_off = 0, sym_off = 0, str_off = 0;
  if (!elf_vaddr_to_off(phdr, eh.e_phnum, jmprel, &rel_off) ||
      !elf_vaddr_to_off(phdr, eh.e_phnum, symtab, &sym_off) ||
      !elf_vaddr_to_off(phdr, eh.e_phnum, strtab, &str_off)) {
    free(dyn);
    free(phdr);
    close(fd);
    return false;
  }

  bool found = false;
  size_t entsz = (pltrel == DT_REL) ? sizeof(ElfW(Rel)) : sizeof(ElfW(Rela));
  size_t count = pltrelsz / entsz;

  for (size_t i = 0; i < count; i++) {
    ElfW(Addr) r_offset = 0;
    ElfW(Word) r_info_type = 0;
    ElfW(Word) sym_index = 0;

    if (pltrel == DT_REL) {
      ElfW(Rel) rel;
      if (pread(fd, &rel, sizeof(rel), rel_off + (off_t)(i * sizeof(rel))) != (ssize_t)sizeof(rel)) break;
      r_offset = rel.r_offset;
      r_info_type = ELFW_R_TYPE(rel.r_info);
      sym_index = ELFW_R_SYM(rel.r_info);
    } else {
      ElfW(Rela) rela;
      if (pread(fd, &rela, sizeof(rela), rel_off + (off_t)(i * sizeof(rela))) != (ssize_t)sizeof(rela)) break;
      r_offset = rela.r_offset;
      r_info_type = ELFW_R_TYPE(rela.r_info);
      sym_index = ELFW_R_SYM(rela.r_info);
    }

    if (r_info_type != TARGET_JUMP_SLOT) continue;

    ElfW(Sym) sym;
    if (pread(fd, &sym, sizeof(sym), sym_off + (off_t)(sym_index * sizeof(sym))) != (ssize_t)sizeof(sym)) break;
    if (sym.st_name == 0) continue;

    char name[128] = { 0 };
    if (pread(fd, name, sizeof(name) - 1, str_off + (off_t)sym.st_name) <= 0) break;
    if (strcmp(name, symbol) != 0) continue;

    *out_bias = (uintptr_t)min_vaddr;
    *out_got_off = (uintptr_t)r_offset;
    found = true;
    break;
  }

  free(dyn);
  free(phdr);
  close(fd);

  return found;
}

bool wait_linker_ready(int pid, uintptr_t *out_libc_init_resolved, uintptr_t *out_libc_init_got_slot) {
  char pid_str[16];
  snprintf(pid_str, sizeof(pid_str), "%d", pid);

  struct maps_info *remote_map = parse_maps(pid_str);
  if (!remote_map) return false;

  bool found_slot = false;
  for (size_t i = 0; i < remote_map->length; i++) {
    const struct map_entry *m = &remote_map->maps[i];
    if (!m->path || m->offset != 0 || !strstr(m->path, "app_process")) continue;

    uintptr_t bias = 0, got_off = 0;
    if (!find_jump_slot_got_offset(m->path, "__libc_init", &bias, &got_off)) {
      free_maps(remote_map);
      return false;
    }

    *out_libc_init_got_slot = ((uintptr_t)m->start - bias) + got_off;
    found_slot = true;
    break;
  }

  free_maps(remote_map);
  if (!found_slot) return false;

  uintptr_t initial_value = 0;
  if (read_proc(pid, *out_libc_init_got_slot, &initial_value, sizeof(initial_value)) != (ssize_t)sizeof(initial_value)) {
    return false;
  }

  while (1) {
    uintptr_t current_value = 0;
    if (read_proc(pid, *out_libc_init_got_slot, &current_value, sizeof(current_value)) != (ssize_t)sizeof(current_value)) {
      return false;
    }

    if (current_value != initial_value) {
      *out_libc_init_resolved = current_value;
      return true;
    }

    if (ptrace(PTRACE_SYSCALL, pid, 0, 0) == -1) return false;

    int status = 0;
    if (!wait_for_ptrace_syscall_stop(pid, &status)) return false;
  }
}

bool ptrace_poke_uintptr(pid_t pid, uintptr_t addr, uintptr_t value) {
  uintptr_t word_size = sizeof(unsigned long);
  uintptr_t word_mask = word_size - 1;
  uintptr_t aligned = addr & ~word_mask;

  if ((addr & word_mask) == 0) {
    errno = 0;
    return !(ptrace(PTRACE_POKEDATA, pid, (void *)aligned, (void *)value) == -1 && errno != 0);
  }

  uintptr_t shift = (addr & word_mask) * 8;
  errno = 0;
  unsigned long data = (unsigned long)ptrace(PTRACE_PEEKDATA, pid, (void *)aligned, 0);
  if (errno != 0) return false;

  unsigned long mask = ~(((unsigned long)~0ULL >> ((sizeof(unsigned long) - sizeof(uintptr_t)) * 8)) << shift);
  unsigned long patched = (data & mask) | ((unsigned long)value << shift);

  return ptrace(PTRACE_POKEDATA, pid, (void *)aligned, (void *)patched) != -1;
}

#ifdef __aarch64__
  #define AARCH64_PSTATE_BTYPE_MASK (3ull << 10)
#endif

bool wait_for_ptrace_syscall_stop(int pid, int *status) {
  int step_retries = 0;
  while (1) {
    pid_t waited = waitpid(pid, status, __WALL);
    if (waited == -1) {
      if (errno == EINTR) continue;
      return false;
    }

    if (waited != pid) continue;
    if (!WIFSTOPPED(*status)) return false;

    int stop_sig = WSTOPSIG(*status);
    int stop_event = (*status >> 16) & 0xff;
    bool is_syscall_stop = stop_event == 0 && (stop_sig == SIGTRAP || stop_sig == (SIGTRAP | 0x80));

    if ((stop_sig == SIGSTOP || stop_sig == SIGTRAP) && stop_event == PTRACE_EVENT_STOP) {
      if (step_retries++ >= 4) return false;
      if (ptrace(PTRACE_SYSCALL, pid, 0, 0) == -1) return false;
      continue;
    }

    return is_syscall_stop;
  }
}

long remote_syscall(int pid, struct user_regs_struct *regs, uintptr_t syscall_gadget, long sysnr, long *args, size_t args_size) {
  long ret = -1;

  struct user_regs_struct saved_regs;
  if (!get_regs(pid, &saved_regs)) return -1;

  #if defined(__aarch64__)
    regs->regs[8] = (uint64_t)sysnr;
    for (size_t i = 0; i < 6; i++) regs->regs[i] = 0;
    for (size_t i = 0; i < args_size && i < 6; i++) regs->regs[i] = (uint64_t)args[i];
    regs->REG_IP = syscall_gadget;
    regs->pstate &= ~AARCH64_PSTATE_BTYPE_MASK;
  #elif defined(__arm__)
    regs->uregs[7] = (unsigned long)sysnr;
    for (size_t i = 0; i < 6; i++) regs->uregs[i] = 0;
    for (size_t i = 0; i < args_size && i < 6; i++) regs->uregs[i] = (unsigned long)args[i];
    regs->REG_IP = syscall_gadget;

    unsigned long CPSR_T_MASK = 1lu << 5;
    if ((syscall_gadget & 1) != 0) {
      regs->REG_IP = syscall_gadget & ~1u;
      regs->uregs[16] |= CPSR_T_MASK;
    } else {
      regs->uregs[16] &= ~CPSR_T_MASK;
    }
  #elif defined(__x86_64__)
    regs->REG_SYSNR = sysnr;
    regs->rax = sysnr;
    regs->rdi = (args_size >= 1) ? args[0] : 0;
    regs->rsi = (args_size >= 2) ? args[1] : 0;
    regs->rdx = (args_size >= 3) ? args[2] : 0;
    regs->r10 = (args_size >= 4) ? args[3] : 0;
    regs->r8  = (args_size >= 5) ? args[4] : 0;
    regs->r9  = (args_size >= 6) ? args[5] : 0;
    regs->REG_IP = syscall_gadget;
  #elif defined(__i386__)
    regs->REG_SYSNR = sysnr;
    regs->eax = sysnr;
    regs->ebx = (args_size >= 1) ? args[0] : 0;
    regs->ecx = (args_size >= 2) ? args[1] : 0;
    regs->edx = (args_size >= 3) ? args[2] : 0;
    regs->esi = (args_size >= 4) ? args[3] : 0;
    regs->edi = (args_size >= 5) ? args[4] : 0;
    regs->ebp = (args_size >= 6) ? args[5] : 0;
    regs->REG_IP = syscall_gadget;
  #endif

  if (!set_regs(pid, regs)) goto restore_regs;

  for (int i = 0; i < 2; i++) {
    if (ptrace(PTRACE_SYSCALL, pid, 0, 0) == -1) {
      ret = -1;
      goto restore_regs;
    }

    int status;
    if (!wait_for_ptrace_syscall_stop(pid, &status)) goto restore_regs;
  }

  if (!get_regs(pid, regs)) {
    ret = -1;
    goto restore_regs;
  }

  ret = (long)regs->REG_RET;

restore_regs:
  *regs = saved_regs;
  set_regs(pid, regs);
  return ret;
}

void tracee_skip_syscall(int pid) {
  struct user_regs_struct regs;
  if (!get_regs(pid, &regs)) _exit(1);

  regs.REG_SYSNR = -1;
  if (!set_regs(pid, &regs)) _exit(1);

  #if defined(__aarch64__)
    int sysnr = -1;
    struct iovec iov = {
      .iov_base = &sysnr,
      .iov_len = sizeof(int),
    };
    ptrace(PTRACE_SETREGSET, pid, NT_ARM_SYSTEM_CALL, &iov);
  #elif defined(__arm__)
    ptrace(PTRACE_SET_SYSCALL, pid, 0, (void *)-1);
  #endif
}

void wait_for_trace(int pid, int *status, int flags) {
  while (1) {
    pid_t result = waitpid(pid, status, flags);
    if (result == -1) {
      if (errno == EINTR) continue;
      *status = 255 << 8;
      return;
    }

    if (WIFSTOPPED(*status) && WSTOPSIG(*status) == SIGCHLD) {
      ptrace(PTRACE_CONT, pid, 0, 0);
      continue;
    }

    if (*status >> 8 == (SIGTRAP | (PTRACE_EVENT_SECCOMP << 8))) {
      tracee_skip_syscall(pid);
      ptrace(PTRACE_CONT, pid, 0, 0);
      continue;
    }

    return;
  }
}

void parse_status(int status, char *buf, size_t len) {
  if (len == 0) return;

  if (WIFEXITED(status)) {
    snprintf(buf, len, "0x%x exited with %d", status, WEXITSTATUS(status));
  } else if (WIFSIGNALED(status)) {
    snprintf(buf, len, "0x%x signaled with %s(%d)", status, sigabbrev_np(WTERMSIG(status)), WTERMSIG(status));
  } else if (WIFSTOPPED(status)) {
    int stop_sig = WSTOPSIG(status);
    snprintf(buf, len, "0x%x stopped by signal %s (event: %s)", status, sigabbrev_np(stop_sig), parse_ptrace_event(status));
  } else {
    snprintf(buf, len, "0x%x unknown", status);
  }
}

int get_program(int pid, char *buf, size_t size) {
  if (size == 0) return -1;

  char path[64];
  snprintf(path, sizeof(path), "/proc/%d/exe", pid);

  ssize_t sz = readlink(path, buf, size);
  if (sz == -1) return -1;

  if ((size_t)sz >= size) sz = (ssize_t)(size - 1);
  buf[sz] = '\0';

  return 0;
}
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <elf.h>
#include <link.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <unistd.h>

#include "misc.h"
#include "utils.h"
#include "remote_csoloader.h"

bool inject_on_main(int pid, const char *lib_path, uintptr_t libc_init_target, uintptr_t libc_init_got_slot, bool is_tango) {
  uintptr_t break_addr = (uintptr_t)((intptr_t)(-0x0F & ~1) | (intptr_t)(libc_init_target & 1));
  if (!ptrace_poke_uintptr(pid, libc_init_got_slot, break_addr)) {
    return false;
  }

  if (ptrace(PTRACE_CONT, pid, 0, 0) == -1) {
    return false;
  }

  int status = 0;
  wait_for_trace(pid, &status, __WALL);

  if (!WIFSTOPPED(status) || WSTOPSIG(status) != SIGSEGV) {
    return false;
  }

  struct user_regs_struct regs = { 0 };
  if (!get_regs(pid, &regs)) {
    return false;
  }

  if (!ptrace_poke_uintptr(pid, libc_init_got_slot, libc_init_target)) {
    return false;
  }

  struct user_regs_struct backup;
  memcpy(&backup, &regs, sizeof(regs));

  char pid_str[16];
  snprintf(pid_str, sizeof(pid_str), "%d", pid);

  struct maps_info *map = parse_maps(pid_str);
  if (!map) {
    return false;
  }

  struct maps_info *local_map = parse_maps("self");
  if (!local_map) {
    free_maps(map);
    return false;
  }

  void *libc_return_addr = find_module_return_addr(map, "libc.so");
  uintptr_t remote_base = 0, injector_entry = 0;
  size_t remote_size = 0;

  if (!remote_csoloader_load_and_resolve_entry(pid, &regs, map, local_map, lib_path, &remote_base, &remote_size, &injector_entry)) {
    free_maps(local_map);
    free_maps(map);
    return false;
  }

  free_maps(local_map);
  free_maps(map);

  long args[3] = {
    (long)remote_base,
    (long)remote_size,
    is_tango ? 1 : 0
  };
  remote_call(pid, &regs, injector_entry, (uintptr_t)libc_return_addr, args, 3);

  bool injector_ok = false;
  #if defined(__arm__)
    injector_ok = (((uintptr_t)regs.REG_IP & ~1u) == ((uintptr_t)libc_return_addr & ~1u));
  #else
    injector_ok = ((uintptr_t)regs.REG_IP == (uintptr_t)libc_return_addr);
  #endif

  backup.REG_IP = (long)libc_init_target;
  if (!injector_ok) {
    set_regs(pid, &backup);
    return false;
  }

  return set_regs(pid, &backup);
}

#define STOPPED_WITH(sig, event) (WIFSTOPPED(status) && WSTOPSIG(status) == (sig) && (status >> 16) == (event))
#define WAIT_OR_DIE wait_for_trace(pid, &status, __WALL);
#define CONT_OR_DIE \
  if (ptrace(PTRACE_CONT, pid, 0, 0) == -1) return false;

bool trace_zygote(int pid, bool is_tango) {
  int status = 0;

  struct kernel_version version = parse_kversion();
  int seize_opts = (version.major > 3 || (version.major == 3 && version.minor >= 8))
                       ? (PTRACE_O_EXITKILL | PTRACE_O_TRACESECCOMP)
                       : 0;

  if (ptrace(PTRACE_SEIZE, pid, 0, seize_opts) == -1) {
    return false;
  }

  WAIT_OR_DIE;

  kill(pid, SIGCONT);
  ptrace(PTRACE_SYSCALL, pid, 0, 0);

  int dummy;
  wait_for_ptrace_syscall_stop(pid, &dummy);

  uintptr_t libc_init_got_slot = 0, libc_init_resolved = 0;
  if (!wait_linker_ready(pid, &libc_init_resolved, &libc_init_got_slot)) {
    ptrace(PTRACE_DETACH, pid, 0, SIGCONT);
    return false;
  }

  if (!STOPPED_WITH(SIGSTOP, PTRACE_EVENT_STOP)) {
    ptrace(PTRACE_DETACH, pid, 0, 0);
    return false;
  }

  const char *lib_path = "/data/adb/modules/yinzygisk/lib" LP_SELECT("", "64") "/libzygisk.so";
  if (!inject_on_main(pid, lib_path, libc_init_resolved, libc_init_got_slot, is_tango)) {
    return false;
  }

  if (kill(pid, SIGCONT) != 0) {
    return false;
  }

  CONT_OR_DIE
  WAIT_OR_DIE

  if (!STOPPED_WITH(SIGTRAP, PTRACE_EVENT_STOP)) {
    ptrace(PTRACE_DETACH, pid, 0, 0);
    return false;
  }

  CONT_OR_DIE
  WAIT_OR_DIE

  if (STOPPED_WITH(SIGCONT, 0)) {
    ptrace(PTRACE_SYSCALL, pid, 0, 0);
    WAIT_OR_DIE
    ptrace(PTRACE_DETACH, pid, 0, SIGCONT);
  }

  return true;
}
#include <errno.h>
#include <libgen.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <sys/epoll.h>
#include <sys/ptrace.h>
#include <sys/signalfd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <unistd.h>

#include "daemon.h"
#include "socket_utils.h"
#include "utils.h"
#include "monitor.h"

#define SOCKET_NAME "init_monitor"
#define MODULE_PROP_PATH "/data/adb/modules/yinzygisk/module.prop"
#define STATE_JSON_PATH TMP_PATH "/state.json"

#define STOPPED_WITH(sig, event) (WIFSTOPPED(sigchld_status) && (sigchld_status >> 8 == ((sig) | ((event) << 8))))

static bool update_status(const char *message);

const char *monitor_stop_reason = NULL;

struct environment_information {
  char *root_impl;
  char **modules;
  uint32_t modules_len;
};

static struct environment_information environment_information64;

enum ptracer_tracing_state {
  TRACING,
  STOPPING,
  STOPPED,
  EXITING
};

enum ptracer_tracing_state tracing_state = TRACING;

struct yinzygiskd_status {
  bool supported;
  bool zygote_injected;
  bool daemon_running;
  pid_t daemon_pid;
  char *daemon_info;
  char *daemon_error_info;
};

struct yinzygiskd_status status64 = {
  .supported = false,
  .zygote_injected = false,
  .daemon_running = false,
  .daemon_pid = -1,
  .daemon_info = NULL,
  .daemon_error_info = NULL
};

int monitor_epoll_fd = -1;
bool monitor_events_running = true;
typedef void (*monitor_event_callback_t)(void);

bool monitor_events_init(void) {
  monitor_epoll_fd = epoll_create1(EPOLL_CLOEXEC);
  return monitor_epoll_fd != -1;
}

bool monitor_events_register_event(monitor_event_callback_t event_cb, int fd, uint32_t events) {
  struct epoll_event ev = {
    .data.ptr = (void *)event_cb,
    .events = events
  };

  return epoll_ctl(monitor_epoll_fd, EPOLL_CTL_ADD, fd, &ev) != -1;
}

void monitor_events_stop(void) {
  monitor_events_running = false;
}

void monitor_events_loop(void) {
  struct epoll_event events[2];
  while (monitor_events_running) {
    int nfds = epoll_wait(monitor_epoll_fd, events, 2, -1);
    if (nfds == -1 && errno != EINTR) {
      monitor_events_running = false;
      break;
    }

    for (int i = 0; i < nfds; i++) {
      if (events[i].events & (EPOLLERR | EPOLLHUP)) {
        monitor_events_running = false;
        break;
      }

      ((monitor_event_callback_t)events[i].data.ptr)();
      if (!monitor_events_running) break;
    }
  }

  if (monitor_epoll_fd >= 0) close(monitor_epoll_fd);
  monitor_epoll_fd = -1;
}

int monitor_sock_fd = -1;

bool yinzygiskd_listener_init(void) {
  monitor_sock_fd = socket(PF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
  if (monitor_sock_fd == -1) return false;

  struct sockaddr_un addr = {
    .sun_family = AF_UNIX,
    .sun_path = TMP_PATH "/" SOCKET_NAME
  };

  socklen_t socklen = sizeof(sa_family_t) + sizeof(TMP_PATH "/" SOCKET_NAME) - 1;
  return bind(monitor_sock_fd, (struct sockaddr *)&addr, socklen) != -1;
}

struct yzd_msg_header {
  uint8_t cmd;
  uint32_t len;
  char data[0];
} __attribute__((packed));

#define LONGEST_ROOT_IMPL_NAME sizeof("KernelSU Next")

struct yzd_info_payload {
  char impl[LONGEST_ROOT_IMPL_NAME];
  uint32_t modules_count;
  char data[0];
} __attribute__((packed));

void yinzygiskd_listener_callback(void) {
  while (1) {
    ssize_t dlen = recv(monitor_sock_fd, NULL, 0, MSG_PEEK | MSG_TRUNC);
    if (dlen == -1) {
      if (errno == EINTR || errno == EWOULDBLOCK) break;
      continue;
    }

    if ((size_t)dlen < sizeof(struct yzd_msg_header)) {
      char tmp;
      recv(monitor_sock_fd, &tmp, sizeof(tmp), 0);
      continue;
    }

    struct yzd_msg_header *msg = malloc((size_t)dlen);
    if (!msg) {
      char tmp;
      recv(monitor_sock_fd, &tmp, sizeof(tmp), 0);
      continue;
    }

    ssize_t nread = recv(monitor_sock_fd, msg, (size_t)dlen, 0);
    if (nread == -1) {
      free(msg);
      if (errno == EINTR || errno == EWOULDBLOCK) break;
      continue;
    }

    if (nread != dlen) {
      free(msg);
      continue;
    }

    switch (msg->cmd) {
      case START: {
        if (tracing_state == STOPPING) {
          tracing_state = TRACING;
        } else if (tracing_state == STOPPED) {
          ptrace(PTRACE_SEIZE, 1, 0, PTRACE_O_TRACEFORK);
          tracing_state = TRACING;
        }
        update_status(NULL);
        break;
      }
      case STOP: {
        if (tracing_state == TRACING) {
          tracing_state = STOPPING;
          monitor_stop_reason = "user requested";
          ptrace(PTRACE_INTERRUPT, 1, 0, 0);
          update_status(NULL);
        }
        break;
      }
      case EXIT: {
        tracing_state = EXITING;
        monitor_stop_reason = "user requested";
        update_status(NULL);
        monitor_events_stop();
        break;
      }
      case ZYGOTE64_INJECTED: {
        status64.zygote_injected = true;
        update_status(NULL);
        break;
      }
      case DAEMON64_SET_INFO: {
        if (msg->len != (size_t)nread - sizeof(struct yzd_msg_header) ||
            msg->len < sizeof(struct yzd_info_payload)) {
          break;
        }

        struct environment_information *env_info = &environment_information64;

        if (env_info->root_impl) {
          free(env_info->root_impl);
          env_info->root_impl = NULL;
        }

        struct yzd_info_payload *info = (void *)msg->data;
        env_info->root_impl = strndup(info->impl, sizeof(info->impl));
        if (!env_info->root_impl) break;

        if (env_info->modules) {
          for (size_t i = 0; i < env_info->modules_len; i++) {
            free(env_info->modules[i]);
          }
          free(env_info->modules);
          env_info->modules = NULL;
        }

        env_info->modules_len = info->modules_count;
        env_info->modules = info->modules_count > 0 ? malloc(info->modules_count * sizeof(char *)) : NULL;
        if (info->modules_count > 0 && !env_info->modules) {
          free(env_info->root_impl);
          env_info->root_impl = NULL;
          break;
        }

        char *raw_modules = info->data;
        char *end = (char *)msg + nread;

        size_t i;
        for (i = 0; i < env_info->modules_len; i++) {
          if (raw_modules >= end) goto set_info_modules_cleanup;

          env_info->modules[i] = strndup(raw_modules, (size_t)(end - raw_modules));
          if (!env_info->modules[i]) goto set_info_modules_cleanup;

          raw_modules += strlen(env_info->modules[i]) + 1;
        }

        update_status(NULL);
        break;

      set_info_modules_cleanup:
        free(env_info->root_impl);
        env_info->root_impl = NULL;
        for (size_t j = 0; j < i; j++) free(env_info->modules[j]);
        free(env_info->modules);
        env_info->modules = NULL;
        break;
      }
      case DAEMON64_SET_ERROR_INFO: {
        if (msg->len != (size_t)nread - sizeof(struct yzd_msg_header) || msg->len == 0) {
          break;
        }

        if (status64.daemon_error_info) {
          free(status64.daemon_error_info);
          status64.daemon_error_info = NULL;
        }

        status64.daemon_error_info = strndup(msg->data, msg->len);
        if (!status64.daemon_error_info) break;

        update_status(NULL);
        break;
      }
      default:
        break;
    }

    free(msg);
  }
}

void yinzygiskd_listener_stop(void) {
  if (monitor_sock_fd >= 0) close(monitor_sock_fd);
  monitor_sock_fd = -1;
}

#define MAX_RETRY_COUNT 5

struct timespec last_zygote64 = { 0, 0 };
int count_zygote64 = 0;
static bool should_stop_inject64(void) {
  struct timespec now = { 0, 0 };
  clock_gettime(CLOCK_MONOTONIC, &now);
  if (now.tv_sec - last_zygote64.tv_sec < 30)
    count_zygote64++;
  else
    count_zygote64 = 0;
  last_zygote64 = now;
  return count_zygote64 >= MAX_RETRY_COUNT;
}

static bool ensure_daemon_created(void) {
  if (status64.daemon_pid != -1) {
    return status64.daemon_running;
  }

  pid_t pid = fork();
  if (pid < 0) return false;

  if (pid == 0) {
    const char *daemon_name = "./bin/zygiskd64";
    execl(daemon_name, daemon_name, NULL);
    _exit(1);
  }

  status64.supported = true;
  status64.daemon_pid = pid;
  status64.daemon_running = true;

  return true;
}

#define CHECK_DAEMON_EXIT()                                       \
  if (status64.supported && pid == status64.daemon_pid) {         \
    char status_str[64];                                          \
    parse_status(sigchld_status, status_str, sizeof(status_str)); \
    status64.daemon_running = false;                              \
    if (!status64.daemon_error_info) {                            \
      status64.daemon_error_info = strdup(status_str);            \
      if (!status64.daemon_error_info) return;                    \
    }                                                             \
    continue;                                                     \
  }

#define APP_PROCESS "/system/bin/app_process64"

#define PRE_INJECT_64()                               \
  if (strcmp(program, APP_PROCESS) == 0) {            \
    tracer = "./bin/zygisk-ptrace64";                 \
    if (should_stop_inject64()) {                     \
      tracing_state = STOPPING;                       \
      monitor_stop_reason = "Zygote crashed";         \
      ptrace(PTRACE_INTERRUPT, 1, 0, 0);              \
      break;                                          \
    }                                                 \
    if (!ensure_daemon_created()) {                   \
      tracing_state = STOPPING;                       \
      monitor_stop_reason = "YinZygiskd not running"; \
      ptrace(PTRACE_INTERRUPT, 1, 0, 0);              \
      break;                                          \
    }                                                 \
  }

int sigchld_signal_fd = -1;
struct signalfd_siginfo sigchld_fdsi;
int sigchld_status;

pid_t *sigchld_process = NULL;
size_t sigchld_process_count = 0;

static bool claim_init_tracer(void) {
  if (ptrace(PTRACE_SEIZE, 1, 0, PTRACE_O_TRACEFORK) == -1) {
    if (errno == EPERM) {
      update_status("❌ Multiple Zygisks functioning");
    }
    return false;
  }
  return true;
}

bool sigchld_listener_init(void) {
  sigchld_process = NULL;

  sigset_t mask;
  sigemptyset(&mask);
  sigaddset(&mask, SIGCHLD);

  if (sigprocmask(SIG_BLOCK, &mask, NULL) == -1) return false;

  sigchld_signal_fd = signalfd(-1, &mask, SFD_NONBLOCK | SFD_CLOEXEC);
  return sigchld_signal_fd != -1;
}

void sigchld_listener_callback(void) {
  while (1) {
    ssize_t s = read(sigchld_signal_fd, &sigchld_fdsi, sizeof(sigchld_fdsi));
    if (s == -1) {
      if (errno == EAGAIN) break;
      continue;
    }

    if (s != sizeof(sigchld_fdsi) || sigchld_fdsi.ssi_signo != SIGCHLD) {
      continue;
    }

    int pid;
    while ((pid = waitpid(-1, &sigchld_status, __WALL | WNOHANG)) != 0) {
      if (pid == -1) break;

      if (pid == 1) {
        if (STOPPED_WITH(SIGTRAP, PTRACE_EVENT_FORK)) {
          long child_pid;
          ptrace(PTRACE_GETEVENTMSG, pid, 0, &child_pid);
        } else if (STOPPED_WITH(SIGTRAP, PTRACE_EVENT_STOP) && tracing_state == STOPPING) {
          ptrace(PTRACE_DETACH, 1, 0, 0);
          tracing_state = STOPPED;
          continue;
        }

        if (WIFSTOPPED(sigchld_status)) {
          if (WPTEVENT(sigchld_status) == 0) {
            int sig = WSTOPSIG(sigchld_status);
            if (sig != SIGSTOP && sig != SIGTSTP && sig != SIGTTIN && sig != SIGTTOU) {
              ptrace(PTRACE_CONT, pid, 0, sig);
              continue;
            }
          }
          ptrace(PTRACE_CONT, pid, 0, 0);
        }
        continue;
      }

      CHECK_DAEMON_EXIT()

      pid_t state = 0;
      for (size_t i = 0; i < sigchld_process_count; i++) {
        if (sigchld_process[i] == pid) {
          state = pid;
          break;
        }
      }

      if (state == 0) {
        for (size_t i = 0; i < sigchld_process_count; i++) {
          if (sigchld_process[i] == 0) {
            sigchld_process[i] = pid;
            goto ptrace_process;
          }
        }

        pid_t *new_procs = realloc(sigchld_process, sizeof(pid_t) * (sigchld_process_count + 1));
        if (!new_procs) continue;

        sigchld_process = new_procs;
        sigchld_process[sigchld_process_count++] = pid;

      ptrace_process:
        ptrace(PTRACE_SETOPTIONS, pid, 0, PTRACE_O_TRACEEXEC);
        ptrace(PTRACE_CONT, pid, 0, 0);
        continue;
      }

      if (STOPPED_WITH(SIGTRAP, PTRACE_EVENT_EXEC)) {
        char program[PATH_MAX];
        if (get_program(pid, program, sizeof(program)) == -1) continue;

        const char *tracer = NULL;

        do {
          if (tracing_state != TRACING) break;

          PRE_INJECT_64()

          if (tracer != NULL) {
            kill(pid, SIGSTOP);
            ptrace(PTRACE_CONT, pid, 0, 0);
            waitpid(pid, &sigchld_status, __WALL);

            if (!STOPPED_WITH(SIGSTOP, 0)) break;

            ptrace(PTRACE_DETACH, pid, 0, SIGSTOP);

            sigchld_status = 0;
            int p = fork_dont_care();
            if (p == 0) {
              char pid_str[32];
              snprintf(pid_str, sizeof(pid_str), "%d", pid);

              bool do_restart = (strcmp(program, APP_PROCESS) == 0 && count_zygote64 > 1);

              if (do_restart) {
                execl(tracer, basename((char *)tracer), "trace", pid_str, "--restart", NULL);
              } else {
                execl(tracer, basename((char *)tracer), "trace", pid_str, NULL);
              }

              kill(pid, SIGKILL);
              _exit(1);
            } else if (p == -1) {
              kill(pid, SIGKILL);
            }
          }
        } while (false);
      }

      for (size_t i = 0; i < sigchld_process_count; i++) {
        if (sigchld_process[i] == pid) {
          sigchld_process[i] = 0;
          break;
        }
      }

      if (WIFSTOPPED(sigchld_status)) {
        ptrace(PTRACE_DETACH, pid, 0, 0);
      }
    }
  }
}

void sigchld_listener_stop(void) {
  if (sigchld_signal_fd >= 0) close(sigchld_signal_fd);
  sigchld_signal_fd = -1;

  free(sigchld_process);
  sigchld_process = NULL;
  sigchld_process_count = 0;
}

static char pre_section[1024];
static char post_section[1024];

static bool update_status(const char *message) {
  FILE *prop = fopen(MODULE_PROP_PATH, "w");
  if (!prop) return false;

  if (message) {
    fprintf(prop, "%s[%s] %s", pre_section, message, post_section);
    fclose(prop);
    return true;
  }

  char status_text[256];
  const char *mon_icon = (tracing_state == TRACING) ? "✅"
                       : (tracing_state == EXITING) ? "❌" : "⛔";
  size_t pos = (size_t)snprintf(status_text, sizeof(status_text), "Monitor: %s", mon_icon);

  if (status64.supported) {
    const char *icon = (tracing_state != TRACING) ? "❌"
                     : (status64.zygote_injected && status64.daemon_running) ? "✅"
                     : "⚠️";
    pos += (size_t)snprintf(status_text + pos, sizeof(status_text) - pos, ", YinZygisk 64-bit: %s", icon);
    if (!status64.daemon_running && pos < sizeof(status_text)) {
      const char *err = status64.daemon_error_info ? status64.daemon_error_info : "not running";
      pos += (size_t)snprintf(status_text + pos, sizeof(status_text) - pos, "(YinZygiskd: %s)", err);
    }
  }

  fprintf(prop, "%s[%s] %s", pre_section, status_text, post_section);
  fclose(prop);

  if (environment_information64.root_impl) {
    FILE *json = fopen(STATE_JSON_PATH, "w");
    if (!json) return false;

    fprintf(json, "{\n  \"root\": \"%s\",\n  \"monitor\": {\n    \"state\": \"%d\"", environment_information64.root_impl, tracing_state);
    if (monitor_stop_reason) fprintf(json, ",\n    \"reason\": \"%s\"\n", monitor_stop_reason);
    else fprintf(json, "\n");

    if (status64.supported) {
      fprintf(json, "  },\n  \"yinzygiskd\": {\n");
      fprintf(json, "    \"64\": {\n      \"state\": %d,\n", status64.daemon_running);
      if (status64.daemon_error_info) {
        fprintf(json, "      \"reason\": \"%s\",\n", status64.daemon_error_info);
      }
      fprintf(json, "      \"modules\": [");
      if (environment_information64.modules) {
        for (uint32_t i = 0; i < environment_information64.modules_len; i++) {
          fprintf(json, "%s\"%s\"", i > 0 ? ", " : "", environment_information64.modules[i]);
        }
      }
      fprintf(json, "]\n    }\n");

      fprintf(json, "  },\n  \"zygote\": {\n");
      fprintf(json, "    \"64\": %d\n", status64.zygote_injected);
      fprintf(json, "  }\n");
    } else {
      fprintf(json, "  }\n");
    }

    fprintf(json, "}\n");
    fclose(json);
  } else {
    remove(STATE_JSON_PATH);
  }

  return true;
}

static bool prepare_environment(void) {
  FILE *orig_prop = fopen(MODULE_PROP_PATH, "r");
  if (!orig_prop) return false;

  bool after_description = false;
  size_t pre_len = 0;
  size_t post_len = 0;

  char line[1024];
  while (fgets(line, sizeof(line), orig_prop) != NULL) {
    if (!after_description && strncmp(line, "description=", 12) == 0) {
      pre_len += (size_t)snprintf(pre_section + pre_len, sizeof(pre_section) - pre_len, "description=");
      post_len += (size_t)snprintf(post_section + post_len, sizeof(post_section) - post_len, "%s", line + 12);
      after_description = true;
      continue;
    }

    if (after_description) {
      if (post_len < sizeof(post_section)) {
        post_len += (size_t)snprintf(post_section + post_len, sizeof(post_section) - post_len, "%s", line);
      }
    } else if (pre_len < sizeof(pre_section)) {
      pre_len += (size_t)snprintf(pre_section + pre_len, sizeof(pre_section) - pre_len, "%s", line);
    }
  }

  fclose(orig_prop);
  return true;
}

void init_monitor(void) {
  if (!prepare_environment()) exit(1);
  if (!claim_init_tracer()) exit(1);
  if (!monitor_events_init()) exit(1);

  if (!yinzygiskd_listener_init()) {
    close(monitor_epoll_fd);
    exit(1);
  }

  monitor_events_register_event(yinzygiskd_listener_callback, monitor_sock_fd, EPOLLIN | EPOLLET);

  if (!sigchld_listener_init()) {
    yinzygiskd_listener_stop();
    close(monitor_epoll_fd);
    exit(1);
  }

  monitor_events_register_event(sigchld_listener_callback, sigchld_signal_fd, EPOLLIN | EPOLLET);

  monitor_events_loop();

  yinzygiskd_listener_stop();
  sigchld_listener_stop();

  free(status64.daemon_info);
  free(status64.daemon_error_info);

  if (environment_information64.root_impl) free(environment_information64.root_impl);
  if (environment_information64.modules) {
    for (uint32_t i = 0; i < environment_information64.modules_len; i++) {
      free(environment_information64.modules[i]);
    }
    free(environment_information64.modules);
  }
}

int send_control_command(enum yinzygiskd_command cmd) {
  int sockfd = socket(PF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
  if (sockfd == -1) return -1;

  struct sockaddr_un addr = {
    .sun_family = AF_UNIX,
    .sun_path = TMP_PATH "/" SOCKET_NAME
  };

  socklen_t socklen = sizeof(sa_family_t) + sizeof(TMP_PATH "/" SOCKET_NAME) - 1;

  struct yzd_msg_header msg = {
    .cmd = cmd,
    .len = 0
  };
  ssize_t nsend = sendto(sockfd, &msg, sizeof(msg), 0, (struct sockaddr *)&addr, socklen);

  close(sockfd);
  return nsend != (ssize_t)sizeof(msg) ? -1 : 0;
}
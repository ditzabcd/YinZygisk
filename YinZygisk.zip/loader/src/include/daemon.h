#ifndef DAEMON_H
#define DAEMON_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <unistd.h>

enum yinzygiskd_actions {
  ZygoteInjected,
  GetProcessFlags,
  GetInfo,
  ReadModules,
  RequestCompanionSocket,
  GetModuleDir,
  ZygoteRestart,
  UpdateMountNamespace,
  RemoveModule
};

struct zygisk_modules {
  char **modules;
  size_t modules_count;
};

enum root_impl {
  ROOT_IMPL_NONE,
  ROOT_IMPL_KERNELSU
};

struct yinzygisk_info {
  struct zygisk_modules modules;
  enum root_impl root_impl;
  pid_t pid;
  bool running;
};

enum mount_namespace_state {
  Clean,
  Mounted
};

#define TMP_PATH "/data/adb/yinzygisk"

static inline const char *yinzygiskd_get_path(void) {
  return TMP_PATH;
}

bool yinzygiskd_zygote_injected(void);

uint32_t yinzygiskd_get_process_flags(uid_t uid, const char *const process);

void yinzygiskd_get_info(struct yinzygisk_info *info);

void free_yinzygisk_info(struct yinzygisk_info *info);

bool yinzygiskd_read_modules(struct zygisk_modules *modules);

void free_modules(struct zygisk_modules *modules);

int yinzygiskd_connect_companion(size_t index);

int yinzygiskd_get_module_dir(size_t index);

void yinzygiskd_zygote_restart(void);

bool yinzygiskd_update_mns(enum mount_namespace_state nms_state, char *buf, size_t buf_size);

bool yinzygiskd_remove_module(size_t index);

#endif /* DAEMON_H */
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include <fcntl.h>
#include <sys/auxv.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include "elf_util.h"

#ifndef SHT_GNU_HASH
#define SHT_GNU_HASH 0x6ffffff6
#endif

uint32_t ElfHash(const char *name) {
  uint32_t h = 0, g = 0;

  while (*name) {
    h = (h << 4) + (unsigned char)*name++;
    g = h & 0xf0000000U;
    if (g) h ^= g >> 24;
    h &= ~g;
  }

  return h;
}

uint32_t GnuHash(const char *name) {
  uint32_t h = 5381;

  while (*name) {
    h = (h << 5) + h + (unsigned char)(*name++);
  }

  return h;
}

ElfW(Shdr) *offsetOf_Shdr(ElfW(Ehdr) *head, ElfW(Off) off) {
  return (ElfW(Shdr) *)(((uintptr_t)head) + off);
}

char *offsetOf_char(ElfW(Ehdr) *head, ElfW(Off) off) {
  return (char *)(((uintptr_t)head) + off);
}

ElfW(Sym) *offsetOf_Sym(ElfW(Ehdr) *head, ElfW(Off) off) {
  return (ElfW(Sym) *)(((uintptr_t)head) + off);
}

ElfW(Word) *offsetOf_Word(ElfW(Ehdr) *head, ElfW(Off) off) {
  return (ElfW(Word) *)(((uintptr_t)head) + off);
}

int dl_cb(struct dl_phdr_info *info, size_t size, void *data) {
  (void)size;

  if (!info->dlpi_name) return 0;

  ElfImg *img = (ElfImg *)data;
  if (strstr(info->dlpi_name, img->elf)) {
    img->base = (void *)info->dlpi_addr;
    return 1;
  }

  return 0;
}

bool _find_module_base(ElfImg *img) {
  dl_iterate_phdr(dl_cb, img);
  return img->base != NULL;
}

size_t calculate_valid_symtabs_amount(ElfImg *img) {
  if (!img->symtab_start || img->symstr_offset_for_symtab == 0) return 0;

  size_t count = 0;
  ElfW(Xword) max_str_size = 0;
  bool has_str_limit = false;

  if (img->symtab && img->section_header && img->symtab->sh_link < img->header->e_shnum) {
    max_str_size = (img->section_header + img->symtab->sh_link)->sh_size;
    has_str_limit = true;
  }

  for (ElfW(Off) i = 0; i < img->symtab_count; i++) {
    ElfW(Sym) *sym = &img->symtab_start[i];
    if (has_str_limit && sym->st_name >= max_str_size) continue;

    unsigned int st_type = ELF_ST_TYPE(sym->st_info);
    if ((st_type == STT_FUNC || st_type == STT_OBJECT) && sym->st_size > 0 && sym->st_name != 0) {
      count++;
    }
  }

  return count;
}

void ElfImg_destroy(ElfImg *img) {
  if (!img) return;

  if (img->symtabs_) {
    free(img->symtabs_);
    img->symtabs_ = NULL;
  }

  if (img->elf) {
    free(img->elf);
    img->elf = NULL;
  }

  if (img->header) {
    munmap(img->header, img->size);
    img->header = NULL;
  }

  free(img);
}

ElfImg *ElfImg_create(const char *elf, void *base) {
  ElfImg *img = (ElfImg *)calloc(1, sizeof(ElfImg));
  if (!img) return NULL;

  img->elf = strdup(elf);
  if (!img->elf) {
    free(img);
    return NULL;
  }

  if (base) {
    img->base = base;
  } else if (!_find_module_base(img)) {
    ElfImg_destroy(img);
    return NULL;
  }

  int fd = open(elf, O_RDONLY | O_CLOEXEC);
  if (fd < 0) {
    ElfImg_destroy(img);
    return NULL;
  }

  struct stat st;
  if (fstat(fd, &st) != 0) {
    close(fd);
    ElfImg_destroy(img);
    return NULL;
  }

  img->size = st.st_size;
  if (img->size <= sizeof(ElfW(Ehdr))) {
    close(fd);
    ElfImg_destroy(img);
    return NULL;
  }

  img->header = (ElfW(Ehdr) *)mmap(NULL, img->size, PROT_READ, MAP_PRIVATE, fd, 0);
  close(fd);

  if (img->header == MAP_FAILED) {
    img->header = NULL;
    ElfImg_destroy(img);
    return NULL;
  }

  if (memcmp(img->header->e_ident, ELFMAG, SELFMAG) != 0) {
    ElfImg_destroy(img);
    return NULL;
  }

  if (img->header->e_shoff != 0 && img->header->e_shentsize != 0 && img->header->e_shnum != 0) {
    img->section_header = offsetOf_Shdr(img->header, img->header->e_shoff);
  }

  ElfW(Shdr) *dynsym_shdr = NULL;
  ElfW(Shdr) *symtab_shdr = NULL;
  char *section_str = NULL;

  if (img->section_header && img->header->e_shstrndx != SHN_UNDEF &&
      img->header->e_shstrndx < img->header->e_shnum) {
    ElfW(Shdr) *shstrtab_hdr = img->section_header + img->header->e_shstrndx;
    section_str = offsetOf_char(img->header, shstrtab_hdr->sh_offset);
  }

  if (img->section_header) {
    uintptr_t shoff = (uintptr_t)img->section_header;
    for (int i = 0; i < img->header->e_shnum; i++, shoff += img->header->e_shentsize) {
      ElfW(Shdr) *section_h = (ElfW(Shdr) *)shoff;
      size_t entsize = section_h->sh_entsize;

      switch (section_h->sh_type) {
        case SHT_DYNSYM: {
          dynsym_shdr = section_h;
          img->dynsym_offset = section_h->sh_offset;
          img->dynsym_start = offsetOf_Sym(img->header, img->dynsym_offset);
          break;
        }
        case SHT_SYMTAB: {
          if (section_str && strcmp(section_h->sh_name + section_str, ".symtab") == 0) {
            symtab_shdr = section_h;
            img->symtab_offset = section_h->sh_offset;
            img->symtab_size = section_h->sh_size;
            img->symtab_count = (entsize > 0) ? (img->symtab_size / entsize) : 0;
            img->symtab_start = offsetOf_Sym(img->header, img->symtab_offset);
          }
          break;
        }
        case SHT_HASH: {
          ElfW(Word) *d_un = offsetOf_Word(img->header, section_h->sh_offset);
          if (section_h->sh_size >= 2 * sizeof(ElfW(Word))) {
            img->nbucket_ = d_un[0];
            if (img->nbucket_ > 0 &&
                section_h->sh_size >= (2 + img->nbucket_ + d_un[1]) * sizeof(ElfW(Word))) {
              img->bucket_ = d_un + 2;
              img->chain_ = img->bucket_ + img->nbucket_;
            } else {
              img->nbucket_ = 0;
            }
          }
          break;
        }
        case SHT_GNU_HASH: {
          ElfW(Word) *d_buf = offsetOf_Word(img->header, section_h->sh_offset);
          if (section_h->sh_size >= 4 * sizeof(ElfW(Word))) {
            img->gnu_nbucket_ = d_buf[0];
            img->gnu_symndx_ = d_buf[1];
            img->gnu_bloom_size_ = d_buf[2];
            img->gnu_shift2_ = d_buf[3];

            size_t expected_min_size = 4 * sizeof(ElfW(Word)) +
                                       img->gnu_bloom_size_ * sizeof(uintptr_t) +
                                       img->gnu_nbucket_ * sizeof(uint32_t);

            if (img->gnu_nbucket_ > 0 && img->gnu_bloom_size_ > 0 &&
                section_h->sh_size >= expected_min_size) {
              img->gnu_bloom_filter_ = (uintptr_t *)(d_buf + 4);
              img->gnu_bucket_ = (uint32_t *)(img->gnu_bloom_filter_ + img->gnu_bloom_size_);
              img->gnu_chain_ = img->gnu_bucket_ + img->gnu_nbucket_;

              uintptr_t chain_start_offset = (uintptr_t)img->gnu_chain_ - (uintptr_t)img->header;
              if (chain_start_offset < section_h->sh_offset ||
                  chain_start_offset >= section_h->sh_offset + section_h->sh_size) {
                img->gnu_nbucket_ = 0;
              }
            } else {
              img->gnu_nbucket_ = 0;
            }
          }
          break;
        }
        default:
          break;
      }
    }
  }

  ElfW(Shdr) *shdr_base = img->section_header;

  if (dynsym_shdr && shdr_base) {
    img->dynsym = dynsym_shdr;
    if (dynsym_shdr->sh_link < img->header->e_shnum) {
      ElfW(Shdr) *linked_strtab = shdr_base + dynsym_shdr->sh_link;
      if (linked_strtab->sh_type == SHT_STRTAB) {
        img->strtab = linked_strtab;
        img->symstr_offset = linked_strtab->sh_offset;
        img->strtab_start = (void *)offsetOf_char(img->header, img->symstr_offset);
      }
    }
  }

  if (symtab_shdr && shdr_base) {
    img->symtab = symtab_shdr;
    if (symtab_shdr->sh_link < img->header->e_shnum) {
      ElfW(Shdr) *linked_strtab = shdr_base + symtab_shdr->sh_link;
      img->symstr_offset_for_symtab = (linked_strtab->sh_type == SHT_STRTAB) ? linked_strtab->sh_offset : 0;
    } else {
      img->symstr_offset_for_symtab = 0;
    }
  } else {
    img->symtab_start = NULL;
    img->symtab_count = 0;
    img->symstr_offset_for_symtab = 0;
  }

  if (img->header->e_phoff > 0 && img->header->e_phnum > 0) {
    ElfW(Phdr) *phdr = (ElfW(Phdr) *)((uintptr_t)img->header + img->header->e_phoff);
    bool has_fallback = false;

    for (int i = 0; i < img->header->e_phnum; ++i) {
      if (phdr[i].p_type != PT_LOAD) continue;

      if (phdr[i].p_offset == 0) {
        img->bias = phdr[i].p_vaddr;
        break;
      }

      if (!has_fallback) {
        img->bias = phdr[i].p_vaddr - phdr[i].p_offset;
        has_fallback = true;
      }
    }
  }

  return img;
}

bool _load_symtabs(ElfImg *img) {
  if (img->symtabs_) return true;
  if (!img->symtab_start || img->symstr_offset_for_symtab == 0 || img->symtab_count == 0) return false;

  img->symtabs_count_ = calculate_valid_symtabs_amount(img);
  if (img->symtabs_count_ == 0) return false;

  img->symtabs_ = calloc(img->symtabs_count_, sizeof(ElfW(Sym) *));
  if (!img->symtabs_) return false;

  ElfW(Xword) max_str_size = (img->section_header + img->symtab->sh_link)->sh_size;
  size_t current_valid_index = 0;

  for (ElfW(Off) pos = 0; pos < img->symtab_count; pos++) {
    ElfW(Sym) *current_sym = &img->symtab_start[pos];
    unsigned int st_type = ELF_ST_TYPE(current_sym->st_info);

    if ((st_type == STT_FUNC || st_type == STT_OBJECT) &&
        current_sym->st_size > 0 &&
        current_sym->st_name != 0 &&
        current_sym->st_name < max_str_size) {
      img->symtabs_[current_valid_index++] = current_sym;
      if (current_valid_index == img->symtabs_count_) break;
    }
  }

  return true;
}

ElfW(Addr) GnuLookup(ElfImg *restrict img, const char *name, uint32_t hash, unsigned char *sym_type) {
  if (img->gnu_nbucket_ == 0 || img->gnu_bloom_size_ == 0 || !img->gnu_bloom_filter_ ||
      !img->gnu_bucket_ || !img->gnu_chain_ || !img->dynsym_start || !img->strtab_start) {
    return 0;
  }

  static const size_t bloom_mask_bits = sizeof(uintptr_t) * 8;
  size_t bloom_idx = (hash / bloom_mask_bits) % img->gnu_bloom_size_;
  uintptr_t bloom_word = img->gnu_bloom_filter_[bloom_idx];
  uintptr_t mask = ((uintptr_t)1 << (hash % bloom_mask_bits)) |
                   ((uintptr_t)1 << ((hash >> img->gnu_shift2_) % bloom_mask_bits));

  if ((mask & bloom_word) != mask) return 0;

  uint32_t sym_index = img->gnu_bucket_[hash % img->gnu_nbucket_];
  if (sym_index < img->gnu_symndx_) return 0;

  ElfW(Word) dynsym_count = img->dynsym->sh_size / img->dynsym->sh_entsize;
  if (sym_index >= dynsym_count) return 0;

  char *strings = (char *)img->strtab_start;
  ElfW(Xword) strtab_size = img->strtab->sh_size;
  uint32_t chain_val = img->gnu_chain_[sym_index - img->gnu_symndx_];
  ElfW(Sym) *sym = img->dynsym_start + sym_index;

  if (sym->st_name >= strtab_size) return 0;

  if (((chain_val ^ hash) >> 1) == 0 && sym->st_shndx != SHN_UNDEF &&
      strcmp(name, strings + sym->st_name) == 0) {
    if (sym_type) *sym_type = ELF_ST_TYPE(sym->st_info);
    return sym->st_value;
  }

  while ((chain_val & 1) == 0) {
    sym_index++;
    if (sym_index >= dynsym_count) return 0;

    chain_val = img->gnu_chain_[sym_index - img->gnu_symndx_];
    sym = img->dynsym_start + sym_index;

    if (sym->st_name >= strtab_size) break;

    if (((chain_val ^ hash) >> 1) == 0 && sym->st_shndx != SHN_UNDEF &&
        strcmp(name, strings + sym->st_name) == 0) {
      if (sym_type) *sym_type = ELF_ST_TYPE(sym->st_info);
      return sym->st_value;
    }
  }

  return 0;
}

ElfW(Addr) ElfLookup(ElfImg *restrict img, const char *restrict name, uint32_t hash, unsigned char *sym_type) {
  if (img->nbucket_ == 0 || !img->bucket_ || !img->chain_ || !img->dynsym_start || !img->strtab_start) {
    return 0;
  }

  char *strings = (char *)img->strtab_start;

  for (size_t n = img->bucket_[hash % img->nbucket_]; n != STN_UNDEF; n = img->chain_[n]) {
    ElfW(Sym) *sym = img->dynsym_start + n;

    if (sym->st_shndx != SHN_UNDEF && strcmp(name, strings + sym->st_name) == 0) {
      if (sym_type) *sym_type = ELF_ST_TYPE(sym->st_info);
      return sym->st_value;
    }
  }

  return 0;
}

ElfW(Addr) LinearLookup(ElfImg *img, const char *restrict name, unsigned char *sym_type) {
  if (!_load_symtabs(img) || img->symtabs_count_ == 0) return 0;

  char *symtab_strings = offsetOf_char(img->header, img->symstr_offset_for_symtab);

  for (size_t i = 0; i < img->symtabs_count_; i++) {
    ElfW(Sym) *sym = img->symtabs_[i];
    if (sym->st_shndx == SHN_UNDEF || strcmp(name, symtab_strings + sym->st_name) != 0) continue;

    if (sym_type) *sym_type = ELF_ST_TYPE(sym->st_info);
    return sym->st_value;
  }

  return 0;
}

ElfW(Addr) LinearLookupByPrefix(ElfImg *img, const char *prefix, unsigned char *sym_type) {
  if (!_load_symtabs(img) || img->symtabs_count_ == 0) return 0;

  size_t prefix_len = strlen(prefix);
  if (prefix_len == 0) return 0;

  char *symtab_strings = offsetOf_char(img->header, img->symstr_offset_for_symtab);

  for (size_t i = 0; i < img->symtabs_count_; i++) {
    ElfW(Sym) *sym = img->symtabs_[i];
    if (sym->st_shndx == SHN_UNDEF || strncmp(symtab_strings + sym->st_name, prefix, prefix_len) != 0) continue;

    if (sym_type) *sym_type = ELF_ST_TYPE(sym->st_info);
    return sym->st_value;
  }

  return 0;
}

ElfW(Addr) getSymbOffset(ElfImg *img, const char *name, unsigned char *sym_type) {
  ElfW(Addr) offset = GnuLookup(img, name, GnuHash(name), sym_type);
  if (offset != 0) return offset;

  offset = ElfLookup(img, name, ElfHash(name), sym_type);
  if (offset != 0) return offset;

  return LinearLookup(img, name, sym_type);
}

#ifdef __aarch64__
  struct __ifunc_arg_t {
    unsigned long _size;
    unsigned long _hwcap;
    unsigned long _hwcap2;
  };
  #define _IFUNC_ARG_HWCAP (1ULL << 62)
#elif defined(__riscv)
  struct riscv_hwprobe {
    int64_t key;
    uint64_t value;
  };

  int __riscv_hwprobe(struct riscv_hwprobe *pairs, size_t pair_count, size_t cpu_count, unsigned long *cpus, unsigned flags) {
    register long a0 __asm__("a0") = (long)pairs;
    register long a1 __asm__("a1") = pair_count;
    register long a2 __asm__("a2") = cpu_count;
    register long a3 __asm__("a3") = (long)cpus;
    register long a4 __asm__("a4") = flags;
    register long a7 __asm__("a7") = __NR_riscv_hwprobe;

    __asm__ volatile(
      "ecall"
      : "=r"(a0)
      : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4), "r"(a7)
    );

    return -a0;
  }

  typedef int (*__riscv_hwprobe_t)(struct riscv_hwprobe *__pairs, size_t __pair_count, size_t __cpu_count, unsigned long *__cpus, unsigned __flags);
#endif

static ElfW(Addr) handle_indirect_symbol(ElfImg *img, ElfW(Off) offset) {
  ElfW(Addr) resolver_addr = (ElfW(Addr))((uintptr_t)img->base + offset - img->bias);

  #ifdef __aarch64__
    typedef ElfW(Addr) (*ifunc_resolver_t)(uint64_t, struct __ifunc_arg_t *);

    struct __ifunc_arg_t args = {
      ._size = sizeof(struct __ifunc_arg_t),
      ._hwcap = getauxval(AT_HWCAP),
      ._hwcap2 = getauxval(AT_HWCAP2)
    };

    return ((ifunc_resolver_t)resolver_addr)(args._hwcap | _IFUNC_ARG_HWCAP, &args);
  #elif defined(__arm__)
    typedef ElfW(Addr) (*ifunc_resolver_t)(unsigned long);
    return ((ifunc_resolver_t)resolver_addr)(getauxval(AT_HWCAP));
  #elif defined(__riscv)
    typedef ElfW(Addr) (*ifunc_resolver_t)(uint64_t, __riscv_hwprobe_t, void *);
    return ((ifunc_resolver_t)resolver_addr)(getauxval(AT_HWCAP), __riscv_hwprobe, NULL);
  #else
    typedef ElfW(Addr) (*ifunc_resolver_t)(void);
    return ((ifunc_resolver_t)resolver_addr)();
  #endif
}

ElfW(Addr) getSymbAddress(ElfImg *img, const char *name) {
  unsigned char sym_type = 0;
  ElfW(Addr) offset = getSymbOffset(img, name, &sym_type);

  if (offset == 0 || !img->base) return 0;

  if (sym_type == STT_GNU_IFUNC) {
    return handle_indirect_symbol(img, offset);
  }

  return (ElfW(Addr))((uintptr_t)img->base + offset - img->bias);
}

ElfW(Addr) getSymbAddressByPrefix(ElfImg *img, const char *prefix) {
  unsigned char sym_type = 0;
  ElfW(Addr) offset = LinearLookupByPrefix(img, prefix, &sym_type);

  if (offset == 0 || !img->base) return 0;

  if (sym_type == STT_GNU_IFUNC) {
    return handle_indirect_symbol(img, offset);
  }

  return (ElfW(Addr))((uintptr_t)img->base + offset - img->bias);
}

void *getSymbValueByPrefix(ElfImg *img, const char *prefix) {
  ElfW(Addr) address = getSymbAddressByPrefix(img, prefix);
  return address == 0 ? NULL : *((void **)address);
}
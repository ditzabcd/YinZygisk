#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <sys/mman.h>
#include <sys/sysmacros.h>
#include <sys/utsname.h>

#include "misc.h"

int parse_int(const char *str) {
  if (!str) return -1;

  int val = 0;
  const unsigned char *c = (const unsigned char *)str;
  while (*c) {
    if (*c > '9' || *c < '0') return -1;
    val = val * 10 + (*c - '0');
    c++;
  }

  return val;
}

struct kernel_version parse_kversion(void) {
  struct utsname uts;
  if (uname(&uts) == -1) {
    return (struct kernel_version) { 0 };
  }

  const char *p = uts.release;
  char *endp;

  unsigned long maj = strtoul(p, &endp, 10);
  if (endp == p || *endp != '.') return (struct kernel_version) { 0 };
  p = endp + 1;

  unsigned long min = strtoul(p, &endp, 10);
  if (endp == p || *endp != '.') return (struct kernel_version) { 0 };
  p = endp + 1;

  unsigned long pat = strtoul(p, &endp, 10);
  if (endp == p) return (struct kernel_version) { 0 };

  return (struct kernel_version) {
    .major = (uint8_t)maj,
    .minor = (unsigned int)min,
    .patch = (unsigned int)pat
  };
}

struct maps_info *parse_maps(const char *pid) {
  char path[(sizeof("/proc//maps") - 1) + 10 + 1];
  snprintf(path, sizeof(path), "/proc/%s/maps", pid);

  FILE *fp = fopen(path, "r");
  if (!fp) return NULL;

  struct maps_info *info_array = calloc(1, sizeof(struct maps_info));
  if (!info_array) {
    fclose(fp);
    return NULL;
  }

  size_t infos_capacity = 256;
  info_array->maps = malloc(infos_capacity * sizeof(struct map_entry));
  if (!info_array->maps) {
    free(info_array);
    fclose(fp);
    return NULL;
  }
  info_array->length = 0;

  char line[1024];
  while (fgets(line, sizeof(line), fp) != NULL) {
    char *p = line;
    char *endp;

    uintptr_t start = (uintptr_t)strtoull(p, &endp, 16);
    if (endp == p || *endp != '-') continue;
    p = endp + 1;

    uintptr_t end = (uintptr_t)strtoull(p, &endp, 16);
    if (endp == p || *endp != ' ') continue;
    p = endp + 1;

    if (!p[0] || !p[1] || !p[2] || !p[3] || p[4] != ' ') continue;
    uint8_t perms_bit = 0;
    if (p[0] == 'r') perms_bit |= PROT_READ;
    if (p[1] == 'w') perms_bit |= PROT_WRITE;
    if (p[2] == 'x') perms_bit |= PROT_EXEC;
    bool is_priv = (p[3] == 'p');
    p += 5;

    uintptr_t offset = (uintptr_t)strtoull(p, &endp, 16);
    if (endp == p || *endp != ' ') continue;
    p = endp + 1;

    unsigned int dev_major = (unsigned int)strtoul(p, &endp, 16);
    if (endp == p || *endp != ':') continue;
    p = endp + 1;

    unsigned int dev_minor = (unsigned int)strtoul(p, &endp, 16);
    if (endp == p || *endp != ' ') continue;
    p = endp + 1;

    ino_t inode = (ino_t)strtoull(p, &endp, 10);
    if (endp == p) continue;
    p = endp;

    while (*p == ' ' || *p == '\t') p++;

    char *eol = p;
    while (*eol && *eol != '\n' && *eol != '\r') eol++;
    *eol = '\0';

    char *path_str = strdup(p);
    if (!path_str) goto cleanup_maps;

    if (info_array->length >= infos_capacity) {
      infos_capacity *= 2;
      struct map_entry *tmp_maps = realloc(info_array->maps, infos_capacity * sizeof(struct map_entry));
      if (!tmp_maps) {
        free(path_str);
        goto cleanup_maps;
      }
      info_array->maps = tmp_maps;
    }

    info_array->maps[info_array->length++] = (struct map_entry) {
      .start = start,
      .end = end,
      .perms = perms_bit,
      .is_private = is_priv,
      .offset = offset,
      .dev = makedev(dev_major, dev_minor),
      .inode = inode,
      .path = path_str
    };
  }

  fclose(fp);

  if (info_array->length == 0) {
    free(info_array->maps);
    free(info_array);
    return NULL;
  }

  struct map_entry *tmp_maps = realloc(info_array->maps, info_array->length * sizeof(struct map_entry));
  if (tmp_maps) info_array->maps = tmp_maps;

  return info_array;

cleanup_maps:
  for (size_t i = 0; i < info_array->length; i++) {
    free(info_array->maps[i].path);
  }
  free(info_array->maps);
  free(info_array);
  fclose(fp);
  return NULL;
}

void free_maps(struct maps_info *maps) {
  if (!maps) return;

  for (size_t i = 0; i < maps->length; i++) {
    free(maps->maps[i].path);
  }

  free(maps->maps);
  free(maps);
}
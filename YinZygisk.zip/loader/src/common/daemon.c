#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>

#include <linux/un.h>
#include <sys/socket.h>

#include "misc.h"
#include "socket_utils.h"
#include "daemon.h"

#define SOCKET_FILE_NAME LP_SELECT("cp32", "cp64") ".sock"

static int yinzygiskd_connect(uint8_t retry) {
  struct sockaddr_un addr = {
    .sun_family = AF_UNIX,
    .sun_path = TMP_PATH "/" SOCKET_FILE_NAME
  };

  while (retry--) {
    int fd = socket(PF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd == -1) return -1;

    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
      return fd;
    }

    close(fd);
    if (retry) sleep(1);
  }

  return -1;
}

#define safe_write(fn, ret_stmt) \
  do { if ((fn) == -1) { close(fd); ret_stmt; } } while (0)

#define safe_read(fn, ret_stmt) \
  do { if ((fn) == -1) { close(fd); ret_stmt; } } while (0)

bool yinzygiskd_zygote_injected(void) {
  int fd = yinzygiskd_connect(5);
  if (fd == -1) return false;

  safe_write(write_uint8_t(fd, (uint8_t)ZygoteInjected), return false);

  close(fd);
  return true;
}

uint32_t yinzygiskd_get_process_flags(uid_t uid, const char *const process) {
  int fd = yinzygiskd_connect(1);
  if (fd == -1) return 0;

  safe_write(write_uint8_t(fd, (uint8_t)GetProcessFlags), return 0);
  safe_write(write_uint32_t(fd, (uint32_t)uid), return 0);
  safe_write(write_string(fd, process), return 0);

  uint32_t res = 0;
  safe_read(read_uint32_t(fd, &res), return 0);

  close(fd);
  return res;
}

void yinzygiskd_get_info(struct yinzygisk_info *info) {
  int fd = yinzygiskd_connect(1);
  if (fd == -1) {
    info->running = false;
    return;
  }

  info->running = true;

  safe_write(write_uint8_t(fd, (uint8_t)GetInfo), return);

  uint32_t flags = 0;
  safe_read(read_uint32_t(fd, &flags), return);

  info->root_impl = (flags & (1U << 29)) ? ROOT_IMPL_KERNELSU : ROOT_IMPL_NONE;

  safe_read(read_uint32_t(fd, (uint32_t *)&info->pid), return);
  safe_read(read_size_t(fd, &info->modules.modules_count), return);

  if (info->modules.modules_count == 0) {
    info->modules.modules = NULL;
    close(fd);
    return;
  }

  info->modules.modules = (char **)malloc(sizeof(char *) * info->modules.modules_count);
  if (!info->modules.modules) {
    info->modules.modules_count = 0;
    close(fd);
    return;
  }

  for (size_t i = 0; i < info->modules.modules_count; i++) {
    char *module_name = read_string(fd);
    if (!module_name) goto info_cleanup;

    char module_path[PATH_MAX];
    snprintf(module_path, sizeof(module_path), "/data/adb/modules/%s/module.prop", module_name);
    free(module_name);

    FILE *module_prop = fopen(module_path, "r");
    if (!module_prop) goto info_cleanup;

    info->modules.modules[i] = NULL;

    char line[1024];
    while (fgets(line, sizeof(line), module_prop) != NULL) {
      if (strncmp(line, "name=", 5) != 0) continue;

      size_t name_len = strlen(line + 5);
      if (name_len > 0 && line[name_len + 4] == '\n') name_len--;
      if (name_len > 0 && line[name_len + 4] == '\r') name_len--;
      if (name_len == 0) {
        fclose(module_prop);
        goto info_cleanup;
      }

      info->modules.modules[i] = strndup(line + 5, name_len);
      if (!info->modules.modules[i]) {
        fclose(module_prop);
        goto info_cleanup;
      }
      break;
    }

    if (!info->modules.modules[i]) {
      fclose(module_prop);
      goto info_cleanup;
    }

    fclose(module_prop);
    continue;

  info_cleanup:
    info->modules.modules_count = i;
    free_yinzygisk_info(info);
    break;
  }

  close(fd);
}

void free_yinzygisk_info(struct yinzygisk_info *info) {
  for (size_t i = 0; i < info->modules.modules_count; i++) {
    free(info->modules.modules[i]);
  }
  free(info->modules.modules);
  info->modules.modules = NULL;
  info->modules.modules_count = 0;
}

bool yinzygiskd_read_modules(struct zygisk_modules *modules) {
  int fd = yinzygiskd_connect(1);
  if (fd == -1) return false;

  safe_write(write_uint8_t(fd, (uint8_t)ReadModules), return false);

  size_t len = 0;
  safe_read(read_size_t(fd, &len), return false);

  modules->modules = (char **)malloc(len * sizeof(char *));
  if (!modules->modules) {
    close(fd);
    return false;
  }
  modules->modules_count = len;

  for (size_t i = 0; i < len; i++) {
    char *lib_path = read_string(fd);
    if (!lib_path) {
      modules->modules_count = i;
      free_modules(modules);
      close(fd);
      return false;
    }
    modules->modules[i] = lib_path;
  }

  close(fd);
  return true;
}

void free_modules(struct zygisk_modules *modules) {
  for (size_t i = 0; i < modules->modules_count; i++) {
    free(modules->modules[i]);
  }
  free(modules->modules);
  modules->modules = NULL;
  modules->modules_count = 0;
}

int yinzygiskd_connect_companion(size_t index) {
  int fd = yinzygiskd_connect(1);
  if (fd == -1) return -1;

  safe_write(write_uint8_t(fd, (uint8_t)RequestCompanionSocket), return -1);
  safe_write(write_size_t(fd, index), return -1);

  uint8_t res = 0;
  safe_read(read_uint8_t(fd, &res), return -1);

  if (res == 1) return fd;

  close(fd);
  return -1;
}

int yinzygiskd_get_module_dir(size_t index) {
  int fd = yinzygiskd_connect(1);
  if (fd == -1) return -1;

  safe_write(write_uint8_t(fd, (uint8_t)GetModuleDir), return -1);
  safe_write(write_size_t(fd, index), return -1);

  int dirfd = read_fd(fd);
  close(fd);
  return dirfd;
}

void yinzygiskd_zygote_restart(void) {
  int fd = yinzygiskd_connect(1);
  if (fd == -1) return;

  safe_write(write_uint8_t(fd, (uint8_t)ZygoteRestart), return);

  close(fd);
}

bool yinzygiskd_update_mns(enum mount_namespace_state nms_state, char *buf, size_t buf_size) {
  int fd = yinzygiskd_connect(1);
  if (fd == -1) return false;

  safe_write(write_uint8_t(fd, (uint8_t)UpdateMountNamespace), return false);
  safe_write(write_uint32_t(fd, (uint32_t)getpid()), return false);
  safe_write(write_uint8_t(fd, (uint8_t)nms_state), return false);

  uint32_t target_pid = 0;
  safe_read(read_uint32_t(fd, &target_pid), return false);

  uint32_t target_fd = 0;
  safe_read(read_uint32_t(fd, &target_fd), return false);

  if (target_fd == 0) {
    close(fd);
    return false;
  }

  snprintf(buf, buf_size, "/proc/%u/fd/%u", target_pid, target_fd);

  close(fd);
  return true;
}

bool yinzygiskd_remove_module(size_t index) {
  int fd = yinzygiskd_connect(1);
  if (fd == -1) return false;

  safe_write(write_uint8_t(fd, (uint8_t)RemoveModule), return false);
  safe_write(write_size_t(fd, index), return false);

  uint8_t res = 0;
  safe_read(read_uint8_t(fd, &res), return false);

  close(fd);
  return res == 1;
}

#undef safe_read
#undef safe_write
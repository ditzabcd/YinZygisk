#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>

#include "socket_utils.h"

ssize_t write_loop(int fd, const void *buf, size_t count) {
  size_t written = 0;
  while (written < count) {
    ssize_t ret = TEMP_FAILURE_RETRY(write(fd, (const char *)buf + written, count - written));
    if (ret == -1) {
      if (errno == EAGAIN) {
        usleep(1000);
        continue;
      }
      return -1;
    }
    if (ret == 0) return (ssize_t)written;
    written += (size_t)ret;
  }
  return (ssize_t)written;
}

ssize_t read_loop_offset(int fd, void *buf, size_t count, off_t offset) {
  size_t read_bytes = 0;
  while (read_bytes < count) {
    ssize_t ret = (offset == 0)
      ? TEMP_FAILURE_RETRY(read(fd, (char *)buf + read_bytes, count - read_bytes))
      : TEMP_FAILURE_RETRY(pread(fd, (char *)buf + read_bytes, count - read_bytes, offset + (off_t)read_bytes));
    if (ret == -1) {
      if (errno == EAGAIN) {
        usleep(1000);
        continue;
      }
      return -1;
    }
    if (ret == 0) return (ssize_t)read_bytes;
    read_bytes += (size_t)ret;
  }
  return (ssize_t)read_bytes;
}

ssize_t read_loop(int fd, void *buf, size_t count) {
  return read_loop_offset(fd, buf, count, 0);
}

ssize_t write_fd(int fd, int sendfd) {
  char cmsgbuf[CMSG_SPACE(sizeof(int))] = { 0 };
  char buf[1] = { 0 };

  struct iovec iov = {
    .iov_base = buf,
    .iov_len = 1
  };

  struct msghdr msg = {
    .msg_iov = &iov,
    .msg_iovlen = 1,
    .msg_control = cmsgbuf,
    .msg_controllen = sizeof(cmsgbuf)
  };

  struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg);
  cmsg->cmsg_len = CMSG_LEN(sizeof(int));
  cmsg->cmsg_level = SOL_SOCKET;
  cmsg->cmsg_type = SCM_RIGHTS;
  memcpy(CMSG_DATA(cmsg), &sendfd, sizeof(int));

  return sendmsg(fd, &msg, 0);
}

int read_fd(int fd) {
  char cmsgbuf[CMSG_SPACE(sizeof(int))];
  int cnt = 1;

  struct iovec iov = {
    .iov_base = &cnt,
    .iov_len = sizeof(cnt)
  };

  struct msghdr msg = {
    .msg_iov = &iov,
    .msg_iovlen = 1,
    .msg_control = cmsgbuf,
    .msg_controllen = sizeof(cmsgbuf)
  };

  if (TEMP_FAILURE_RETRY(recvmsg(fd, &msg, MSG_WAITALL)) == -1) {
    return -1;
  }

  int sendfd = -1;
  for (struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg); cmsg != NULL; cmsg = CMSG_NXTHDR(&msg, cmsg)) {
    if (cmsg->cmsg_level == SOL_SOCKET &&
        cmsg->cmsg_type == SCM_RIGHTS &&
        cmsg->cmsg_len >= CMSG_LEN(sizeof(int))) {
      memcpy(&sendfd, CMSG_DATA(cmsg), sizeof(int));
      break;
    }
  }

  return sendfd;
}

ssize_t write_string(int fd, const char *str) {
  if (!str) return -1;

  size_t str_len = strlen(str);
  if (write_loop(fd, &str_len, sizeof(size_t)) != (ssize_t)sizeof(size_t)) {
    return -1;
  }

  ssize_t write_bytes = write_loop(fd, str, str_len);
  return (write_bytes == (ssize_t)str_len) ? write_bytes : -1;
}

char *read_string(int fd) {
  size_t str_len = 0;
  if (read_loop(fd, &str_len, sizeof(size_t)) != (ssize_t)sizeof(size_t)) {
    return NULL;
  }

  char *buf = malloc(str_len + 1);
  if (!buf) return NULL;

  if (read_loop(fd, buf, str_len) != (ssize_t)str_len) {
    free(buf);
    return NULL;
  }

  buf[str_len] = '\0';
  return buf;
}

#define write_func(type)                       \
  ssize_t write_##type(int fd, type val) {     \
    return write_loop(fd, &val, sizeof(type)); \
  }

#define read_func(type)                        \
  ssize_t read_##type(int fd, type *val) {     \
    return read_loop(fd, val, sizeof(type));   \
  }

write_func(uint8_t)
read_func(uint8_t)

write_func(uint32_t)
read_func(uint32_t)

write_func(size_t)
read_func(size_t)